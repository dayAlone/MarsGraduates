# ************************************************************
# Sequel Pro SQL dump
# Version 4135
#
# http://www.sequelpro.com/
# http://code.google.com/p/sequel-pro/
#
# Host: 127.0.0.1 (MySQL 5.5.34)
# Database: mars_graduates
# Generation Time: 2014-07-18 11:33:26 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table b_admin_notify
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_admin_notify`;

CREATE TABLE `b_admin_notify` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `MODULE_ID` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TAG` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `MESSAGE` text COLLATE utf8_unicode_ci,
  `ENABLE_CLOSE` char(1) COLLATE utf8_unicode_ci DEFAULT 'Y',
  `PUBLIC_SECTION` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`ID`),
  KEY `IX_AD_TAG` (`TAG`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_admin_notify_lang
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_admin_notify_lang`;

CREATE TABLE `b_admin_notify_lang` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `NOTIFY_ID` int(18) NOT NULL,
  `LID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `MESSAGE` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `IX_ADM_NTFY_LANG` (`NOTIFY_ID`,`LID`),
  KEY `IX_ADM_NTFY_LID` (`LID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_agent
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_agent`;

CREATE TABLE `b_agent` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `MODULE_ID` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SORT` int(18) NOT NULL DEFAULT '100',
  `NAME` text COLLATE utf8_unicode_ci,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `LAST_EXEC` datetime DEFAULT NULL,
  `NEXT_EXEC` datetime NOT NULL,
  `DATE_CHECK` datetime DEFAULT NULL,
  `AGENT_INTERVAL` int(18) DEFAULT '86400',
  `IS_PERIOD` char(1) COLLATE utf8_unicode_ci DEFAULT 'Y',
  `USER_ID` int(18) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ix_act_next_exec` (`ACTIVE`,`NEXT_EXEC`),
  KEY `ix_agent_user_id` (`USER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `b_agent` WRITE;
/*!40000 ALTER TABLE `b_agent` DISABLE KEYS */;

INSERT INTO `b_agent` (`ID`, `MODULE_ID`, `SORT`, `NAME`, `ACTIVE`, `LAST_EXEC`, `NEXT_EXEC`, `DATE_CHECK`, `AGENT_INTERVAL`, `IS_PERIOD`, `USER_ID`)
VALUES
	(1,'main',100,'CEvent::CleanUpAgent();','Y','2014-07-18 00:05:50','2014-07-19 00:00:00',NULL,86400,'Y',NULL),
	(2,'main',100,'CUser::CleanUpHitAuthAgent();','Y','2014-07-18 00:05:50','2014-07-19 00:00:00',NULL,86400,'Y',NULL),
	(3,'main',100,'CCaptchaAgent::DeleteOldCaptcha(3600);','Y','2014-07-18 17:00:37','2014-07-18 18:00:37',NULL,3600,'N',NULL),
	(4,'main',100,'CUndo::CleanUpOld();','Y','2014-07-18 00:05:50','2014-07-19 00:00:00',NULL,86400,'Y',NULL),
	(5,'main',100,'CSiteCheckerTest::CommonTest();','Y','2014-07-17 18:38:35','2014-07-18 18:38:35',NULL,86400,'N',NULL),
	(8,'search',10,'CSearchSuggest::CleanUpAgent();','Y','2014-07-17 18:38:35','2014-07-18 18:38:35',NULL,86400,'N',NULL),
	(9,'search',10,'CSearchStatistic::CleanUpAgent();','Y','2014-07-17 18:38:35','2014-07-18 18:38:35',NULL,86400,'N',NULL),
	(10,'security',100,'CSecuritySession::CleanUpAgent();','Y','2014-07-18 17:30:53','2014-07-18 18:00:53',NULL,1800,'N',NULL),
	(11,'security',100,'CSecurityIPRule::CleanUpAgent();','Y','2014-07-18 17:00:37','2014-07-18 18:00:37',NULL,3600,'N',NULL),
	(12,'subscribe',100,'CSubscription::CleanUp();','Y','2014-07-18 03:00:30','2014-07-19 03:00:00',NULL,86400,'Y',NULL);

/*!40000 ALTER TABLE `b_agent` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table b_bitrixcloud_option
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_bitrixcloud_option`;

CREATE TABLE `b_bitrixcloud_option` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `SORT` int(11) NOT NULL,
  `PARAM_KEY` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PARAM_VALUE` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ix_b_bitrixcloud_option_1` (`NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `b_bitrixcloud_option` WRITE;
/*!40000 ALTER TABLE `b_bitrixcloud_option` DISABLE KEYS */;

INSERT INTO `b_bitrixcloud_option` (`ID`, `NAME`, `SORT`, `PARAM_KEY`, `PARAM_VALUE`)
VALUES
	(1,'backup_quota',0,'0','0'),
	(2,'backup_total_size',0,'0','0'),
	(3,'backup_last_backup_time',0,'0','1404410474'),
	(4,'monitoring_expire_time',0,'0','1405682375');

/*!40000 ALTER TABLE `b_bitrixcloud_option` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table b_cache_tag
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_cache_tag`;

CREATE TABLE `b_cache_tag` (
  `SITE_ID` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CACHE_SALT` char(4) COLLATE utf8_unicode_ci DEFAULT NULL,
  `RELATIVE_PATH` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TAG` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  KEY `ix_b_cache_tag_0` (`SITE_ID`,`CACHE_SALT`,`RELATIVE_PATH`(50)),
  KEY `ix_b_cache_tag_1` (`TAG`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `b_cache_tag` WRITE;
/*!40000 ALTER TABLE `b_cache_tag` DISABLE KEYS */;

INSERT INTO `b_cache_tag` (`SITE_ID`, `CACHE_SALT`, `RELATIVE_PATH`, `TAG`)
VALUES
	(NULL,NULL,'0:1405682637','**'),
	('s1','/e32','/s1/bitrix/news.list/e32','iblock_id_3'),
	('s1','/b08','/s1/bitrix/news.list/cd2','iblock_id_3'),
	('s1','/601','/s1/bitrix/news.list/601','iblock_id_5'),
	('s1','/601','/s1/bitrix/news.list/601','iblock_id_1'),
	('s1','/601','/s1/bitrix/news.list/601','iblock_id_3'),
	('s1','/601','/s1/bitrix/news.list/601','iblock_id_4'),
	('s1','/601','/s1/bitrix/news.list/601','iblock_id_1'),
	('s1','/601','/s1/bitrix/news.list/601','iblock_id_3'),
	('s1','/601','/s1/bitrix/news.list/601','iblock_id_4'),
	('s1','/132','/s1/bitrix/news.list/06f','iblock_id_7'),
	('s1','/132','/s1/bitrix/news.list/132','iblock_id_7'),
	('s1','/132','/s1/bitrix/news.list/132','iblock_id_8'),
	('s1','/132','/s1/bitrix/news.list/132','iblock_id_8');

/*!40000 ALTER TABLE `b_cache_tag` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table b_captcha
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_captcha`;

CREATE TABLE `b_captcha` (
  `ID` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `CODE` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `IP` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `DATE_CREATE` datetime NOT NULL,
  UNIQUE KEY `UX_B_CAPTCHA` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_checklist
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_checklist`;

CREATE TABLE `b_checklist` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `DATE_CREATE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TESTER` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `COMPANY_NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PICTURE` int(11) DEFAULT NULL,
  `TOTAL` int(11) DEFAULT NULL,
  `SUCCESS` int(11) DEFAULT NULL,
  `FAILED` int(11) DEFAULT NULL,
  `PENDING` int(11) DEFAULT NULL,
  `SKIP` int(11) DEFAULT NULL,
  `STATE` longtext COLLATE utf8_unicode_ci,
  `REPORT_COMMENT` text COLLATE utf8_unicode_ci,
  `REPORT` char(1) COLLATE utf8_unicode_ci DEFAULT 'Y',
  `EMAIL` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PHONE` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SENDED_TO_BITRIX` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  `HIDDEN` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_clouds_file_bucket
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_clouds_file_bucket`;

CREATE TABLE `b_clouds_file_bucket` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci DEFAULT 'Y',
  `SORT` int(11) DEFAULT '500',
  `READ_ONLY` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  `SERVICE_ID` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `BUCKET` varchar(63) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LOCATION` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CNAME` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FILE_COUNT` int(11) DEFAULT '0',
  `FILE_SIZE` float DEFAULT '0',
  `LAST_FILE_ID` int(11) DEFAULT NULL,
  `PREFIX` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SETTINGS` text COLLATE utf8_unicode_ci,
  `FILE_RULES` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_clouds_file_resize
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_clouds_file_resize`;

CREATE TABLE `b_clouds_file_resize` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ERROR_CODE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `FILE_ID` int(11) DEFAULT NULL,
  `PARAMS` text COLLATE utf8_unicode_ci,
  `FROM_PATH` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TO_PATH` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ix_b_file_resize_ts` (`TIMESTAMP_X`),
  KEY `ix_b_file_resize_path` (`TO_PATH`(100)),
  KEY `ix_b_file_resize_file` (`FILE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_clouds_file_upload
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_clouds_file_upload`;

CREATE TABLE `b_clouds_file_upload` (
  `ID` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `FILE_PATH` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `TMP_FILE` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `BUCKET_ID` int(11) NOT NULL,
  `PART_SIZE` int(11) NOT NULL,
  `PART_NO` int(11) NOT NULL,
  `PART_FAIL_COUNTER` int(11) NOT NULL,
  `NEXT_STEP` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_component_params
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_component_params`;

CREATE TABLE `b_component_params` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `COMPONENT_NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `TEMPLATE_NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `REAL_PATH` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `SEF_MODE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `SEF_FOLDER` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `START_CHAR` int(11) NOT NULL,
  `END_CHAR` int(11) NOT NULL,
  `PARAMETERS` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `ix_comp_params_name` (`COMPONENT_NAME`),
  KEY `ix_comp_params_path` (`SITE_ID`,`REAL_PATH`),
  KEY `ix_comp_params_sname` (`SITE_ID`,`COMPONENT_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_culture
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_culture`;

CREATE TABLE `b_culture` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `CODE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FORMAT_DATE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FORMAT_DATETIME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FORMAT_NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `WEEK_START` int(1) DEFAULT '1',
  `CHARSET` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DIRECTION` char(1) COLLATE utf8_unicode_ci DEFAULT 'Y',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `b_culture` WRITE;
/*!40000 ALTER TABLE `b_culture` DISABLE KEYS */;

INSERT INTO `b_culture` (`ID`, `CODE`, `NAME`, `FORMAT_DATE`, `FORMAT_DATETIME`, `FORMAT_NAME`, `WEEK_START`, `CHARSET`, `DIRECTION`)
VALUES
	(1,'ru','ru','DD.MM.YYYY','DD.MM.YYYY HH:MI:SS','#NAME# #LAST_NAME#',1,'UTF-8','Y'),
	(2,'en','en','MM/DD/YYYY','MM/DD/YYYY H:MI:SS T','#NAME# #LAST_NAME#',0,'UTF-8','Y');

/*!40000 ALTER TABLE `b_culture` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table b_event
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_event`;

CREATE TABLE `b_event` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `EVENT_NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `MESSAGE_ID` int(18) DEFAULT NULL,
  `LID` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `C_FIELDS` longtext COLLATE utf8_unicode_ci,
  `DATE_INSERT` datetime DEFAULT NULL,
  `DATE_EXEC` datetime DEFAULT NULL,
  `SUCCESS_EXEC` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `DUPLICATE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`ID`),
  KEY `ix_success` (`SUCCESS_EXEC`),
  KEY `ix_b_event_date_exec` (`DATE_EXEC`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_event_log
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_event_log`;

CREATE TABLE `b_event_log` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `SEVERITY` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `AUDIT_TYPE_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `MODULE_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `ITEM_ID` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `REMOTE_ADDR` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `USER_AGENT` text COLLATE utf8_unicode_ci,
  `REQUEST_URI` text COLLATE utf8_unicode_ci,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `USER_ID` int(18) DEFAULT NULL,
  `GUEST_ID` int(18) DEFAULT NULL,
  `DESCRIPTION` mediumtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `ix_b_event_log_time` (`TIMESTAMP_X`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `b_event_log` WRITE;
/*!40000 ALTER TABLE `b_event_log` DISABLE KEYS */;

INSERT INTO `b_event_log` (`ID`, `TIMESTAMP_X`, `SEVERITY`, `AUDIT_TYPE_ID`, `MODULE_ID`, `ITEM_ID`, `REMOTE_ADDR`, `USER_AGENT`, `REQUEST_URI`, `SITE_ID`, `USER_ID`, `GUEST_ID`, `DESCRIPTION`)
VALUES
	(1,'2014-07-08 13:05:39','UNKNOWN','IBLOCK_ADD','iblock','8','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_4) AppleWebKit/537.77.4 (KHTML, like Gecko) Version/7.0.5 Safari/537.77.4','/bitrix/admin/iblock_edit.php?type=content&lang=ru&admin=Y',NULL,1,NULL,'a:1:{s:4:\"NAME\";s:16:\"Вакансии\";}'),
	(2,'2014-07-08 13:42:38','UNKNOWN','MENU_EDIT','fileman','UNKNOWN','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_4) AppleWebKit/537.77.4 (KHTML, like Gecko) Version/7.0.5 Safari/537.77.4','/bitrix/admin/fileman_menu_edit.php?',NULL,1,NULL,'a:2:{s:9:\"menu_name\";s:23:\"Верхнее меню\";s:4:\"path\";b:0;}'),
	(3,'2014-07-08 14:19:43','UNKNOWN','MENU_ADD','fileman','UNKNOWN','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_4) AppleWebKit/537.77.4 (KHTML, like Gecko) Version/7.0.5 Safari/537.77.4','/bitrix/admin/fileman_menu_edit.php?',NULL,1,NULL,'a:2:{s:9:\"menu_name\";s:29:\"Социальные сети\";s:4:\"path\";b:0;}'),
	(4,'2014-07-08 14:21:47','UNKNOWN','MENU_EDIT','fileman','UNKNOWN','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_4) AppleWebKit/537.77.4 (KHTML, like Gecko) Version/7.0.5 Safari/537.77.4','/bitrix/admin/fileman_menu_edit.php?',NULL,1,NULL,'a:2:{s:9:\"menu_name\";s:29:\"Социальные сети\";s:4:\"path\";b:0;}'),
	(5,'2014-07-08 19:19:11','UNKNOWN','IBLOCK_EDIT','iblock','7','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_4) AppleWebKit/537.77.4 (KHTML, like Gecko) Version/7.0.5 Safari/537.77.4','/bitrix/admin/iblock_edit.php?type=content&lang=ru&admin=Y',NULL,1,NULL,'a:1:{s:4:\"NAME\";s:37:\"Направления карьеры\";}'),
	(6,'2014-07-08 19:22:19','UNKNOWN','IBLOCK_EDIT','iblock','7','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_4) AppleWebKit/537.77.4 (KHTML, like Gecko) Version/7.0.5 Safari/537.77.4','/bitrix/admin/iblock_edit.php?type=content&lang=ru&admin=Y',NULL,1,NULL,'a:1:{s:4:\"NAME\";s:37:\"Направления карьеры\";}'),
	(7,'2014-07-11 16:15:46','UNKNOWN','IBLOCK_EDIT','iblock','5','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_4) AppleWebKit/537.77.4 (KHTML, like Gecko) Version/7.0.5 Safari/537.77.4','/bitrix/admin/iblock_edit.php?type=events&lang=ru&admin=Y',NULL,1,NULL,'a:1:{s:4:\"NAME\";s:22:\"Направление\";}'),
	(8,'2014-07-11 16:16:20','UNKNOWN','IBLOCK_EDIT','iblock','5','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_4) AppleWebKit/537.77.4 (KHTML, like Gecko) Version/7.0.5 Safari/537.77.4','/bitrix/admin/iblock_edit.php?type=events&lang=ru&admin=Y',NULL,1,NULL,'a:1:{s:4:\"NAME\";s:22:\"Направление\";}'),
	(9,'2014-07-12 13:34:49','UNKNOWN','IBLOCK_EDIT','iblock','1','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_4) AppleWebKit/537.77.4 (KHTML, like Gecko) Version/7.0.5 Safari/537.77.4','/bitrix/admin/iblock_edit.php?type=events&lang=ru&admin=Y',NULL,1,NULL,'a:1:{s:4:\"NAME\";s:14:\"События\";}'),
	(10,'2014-07-12 13:35:25','UNKNOWN','IBLOCK_EDIT','iblock','1','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_4) AppleWebKit/537.77.4 (KHTML, like Gecko) Version/7.0.5 Safari/537.77.4','/bitrix/admin/iblock_edit.php?type=events&lang=ru&admin=Y',NULL,1,NULL,'a:1:{s:4:\"NAME\";s:14:\"События\";}'),
	(11,'2014-07-12 13:42:12','UNKNOWN','IBLOCK_EDIT','iblock','1','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_4) AppleWebKit/537.77.4 (KHTML, like Gecko) Version/7.0.5 Safari/537.77.4','/bitrix/admin/iblock_edit.php?type=events&lang=ru&admin=Y',NULL,1,NULL,'a:1:{s:4:\"NAME\";s:14:\"События\";}'),
	(12,'2014-07-12 13:42:35','UNKNOWN','IBLOCK_EDIT','iblock','1','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_4) AppleWebKit/537.77.4 (KHTML, like Gecko) Version/7.0.5 Safari/537.77.4','/bitrix/admin/iblock_edit.php?type=events&lang=ru&admin=Y',NULL,1,NULL,'a:1:{s:4:\"NAME\";s:14:\"События\";}'),
	(13,'2014-07-17 21:35:59','UNKNOWN','IBLOCK_EDIT','iblock','8','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_4) AppleWebKit/537.77.4 (KHTML, like Gecko) Version/7.0.5 Safari/537.77.4','/bitrix/admin/iblock_edit.php?type=content&lang=ru&admin=Y',NULL,1,NULL,'a:1:{s:4:\"NAME\";s:16:\"Вакансии\";}'),
	(14,'2014-07-17 21:36:04','UNKNOWN','IBLOCK_EDIT','iblock','7','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_4) AppleWebKit/537.77.4 (KHTML, like Gecko) Version/7.0.5 Safari/537.77.4','/bitrix/admin/iblock_edit.php?type=content&lang=ru&admin=Y',NULL,1,NULL,'a:1:{s:4:\"NAME\";s:37:\"Направления карьеры\";}'),
	(15,'2014-07-17 21:36:11','UNKNOWN','IBLOCK_EDIT','iblock','3','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_4) AppleWebKit/537.77.4 (KHTML, like Gecko) Version/7.0.5 Safari/537.77.4','/bitrix/admin/iblock_edit.php?type=events&lang=ru&admin=Y',NULL,1,NULL,'a:1:{s:4:\"NAME\";s:12:\"Города\";}'),
	(16,'2014-07-17 21:36:17','UNKNOWN','IBLOCK_EDIT','iblock','5','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_4) AppleWebKit/537.77.4 (KHTML, like Gecko) Version/7.0.5 Safari/537.77.4','/bitrix/admin/iblock_edit.php?type=events&lang=ru&admin=Y',NULL,1,NULL,'a:1:{s:4:\"NAME\";s:22:\"Направление\";}'),
	(17,'2014-07-17 21:40:36','UNKNOWN','IBLOCK_EDIT','iblock','6','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_4) AppleWebKit/537.77.4 (KHTML, like Gecko) Version/7.0.5 Safari/537.77.4','/bitrix/admin/iblock_edit.php?type=events&lang=ru&admin=Y',NULL,1,NULL,'a:1:{s:4:\"NAME\";s:16:\"Партнеры\";}'),
	(18,'2014-07-17 21:40:41','UNKNOWN','IBLOCK_EDIT','iblock','1','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_4) AppleWebKit/537.77.4 (KHTML, like Gecko) Version/7.0.5 Safari/537.77.4','/bitrix/admin/iblock_edit.php?type=events&lang=ru&admin=Y',NULL,1,NULL,'a:1:{s:4:\"NAME\";s:14:\"События\";}'),
	(19,'2014-07-17 21:40:48','UNKNOWN','IBLOCK_EDIT','iblock','2','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_4) AppleWebKit/537.77.4 (KHTML, like Gecko) Version/7.0.5 Safari/537.77.4','/bitrix/admin/iblock_edit.php?type=events&lang=ru&admin=Y',NULL,1,NULL,'a:1:{s:4:\"NAME\";s:14:\"Спикеры\";}'),
	(20,'2014-07-17 21:40:56','UNKNOWN','IBLOCK_EDIT','iblock','4','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_4) AppleWebKit/537.77.4 (KHTML, like Gecko) Version/7.0.5 Safari/537.77.4','/bitrix/admin/iblock_edit.php?type=events&lang=ru&admin=Y',NULL,1,NULL,'a:1:{s:4:\"NAME\";s:31:\"Типы мероприятий\";}');

/*!40000 ALTER TABLE `b_event_log` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table b_event_message
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_event_message`;

CREATE TABLE `b_event_message` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `EVENT_NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `LID` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `EMAIL_FROM` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '#EMAIL_FROM#',
  `EMAIL_TO` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '#EMAIL_TO#',
  `SUBJECT` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `MESSAGE` text COLLATE utf8_unicode_ci,
  `BODY_TYPE` varchar(4) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'text',
  `BCC` text COLLATE utf8_unicode_ci,
  `REPLY_TO` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CC` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `IN_REPLY_TO` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PRIORITY` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FIELD1_NAME` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FIELD1_VALUE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FIELD2_NAME` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FIELD2_VALUE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ix_b_event_message_name` (`EVENT_NAME`(50))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `b_event_message` WRITE;
/*!40000 ALTER TABLE `b_event_message` DISABLE KEYS */;

INSERT INTO `b_event_message` (`ID`, `TIMESTAMP_X`, `EVENT_NAME`, `LID`, `ACTIVE`, `EMAIL_FROM`, `EMAIL_TO`, `SUBJECT`, `MESSAGE`, `BODY_TYPE`, `BCC`, `REPLY_TO`, `CC`, `IN_REPLY_TO`, `PRIORITY`, `FIELD1_NAME`, `FIELD1_VALUE`, `FIELD2_NAME`, `FIELD2_VALUE`)
VALUES
	(1,'2014-07-03 23:56:10','NEW_USER','s1','Y','#DEFAULT_EMAIL_FROM#','#DEFAULT_EMAIL_FROM#','#SITE_NAME#: Зарегистрировался новый пользователь','Информационное сообщение сайта #SITE_NAME#\n------------------------------------------\n\nНа сайте #SERVER_NAME# успешно зарегистрирован новый пользователь.\n\nДанные пользователя:\nID пользователя: #USER_ID#\n\nИмя: #NAME#\nФамилия: #LAST_NAME#\nE-Mail: #EMAIL#\n\nLogin: #LOGIN#\n\nПисьмо сгенерировано автоматически.','text',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
	(2,'2014-07-03 23:56:10','USER_INFO','s1','Y','#DEFAULT_EMAIL_FROM#','#EMAIL#','#SITE_NAME#: Регистрационная информация','Информационное сообщение сайта #SITE_NAME#\n------------------------------------------\n#NAME# #LAST_NAME#,\n\n#MESSAGE#\n\nВаша регистрационная информация:\n\nID пользователя: #USER_ID#\nСтатус профиля: #STATUS#\nLogin: #LOGIN#\n\nВы можете изменить пароль, перейдя по следующей ссылке:\nhttp://#SERVER_NAME#/auth/index.php?change_password=yes&lang=ru&USER_CHECKWORD=#CHECKWORD#&USER_LOGIN=#URL_LOGIN#\n\nСообщение сгенерировано автоматически.','text',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
	(3,'2014-07-03 23:56:10','USER_PASS_REQUEST','s1','Y','#DEFAULT_EMAIL_FROM#','#EMAIL#','#SITE_NAME#: Запрос на смену пароля','Информационное сообщение сайта #SITE_NAME#\n------------------------------------------\n#NAME# #LAST_NAME#,\n\n#MESSAGE#\n\nДля смены пароля перейдите по следующей ссылке:\nhttp://#SERVER_NAME#/auth/index.php?change_password=yes&lang=ru&USER_CHECKWORD=#CHECKWORD#&USER_LOGIN=#URL_LOGIN#\n\nВаша регистрационная информация:\n\nID пользователя: #USER_ID#\nСтатус профиля: #STATUS#\nLogin: #LOGIN#\n\nСообщение сгенерировано автоматически.','text',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
	(4,'2014-07-03 23:56:10','USER_PASS_CHANGED','s1','Y','#DEFAULT_EMAIL_FROM#','#EMAIL#','#SITE_NAME#: Подтверждение смены пароля','Информационное сообщение сайта #SITE_NAME#\n------------------------------------------\n#NAME# #LAST_NAME#,\n\n#MESSAGE#\n\nВаша регистрационная информация:\n\nID пользователя: #USER_ID#\nСтатус профиля: #STATUS#\nLogin: #LOGIN#\n\nСообщение сгенерировано автоматически.','text',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
	(5,'2014-07-03 23:56:10','NEW_USER_CONFIRM','s1','Y','#DEFAULT_EMAIL_FROM#','#EMAIL#','#SITE_NAME#: Подтверждение регистрации нового пользователя','Информационное сообщение сайта #SITE_NAME#\n------------------------------------------\n\nЗдравствуйте,\n\nВы получили это сообщение, так как ваш адрес был использован при регистрации нового пользователя на сервере #SERVER_NAME#.\n\nВаш код для подтверждения регистрации: #CONFIRM_CODE#\n\nДля подтверждения регистрации перейдите по следующей ссылке:\nhttp://#SERVER_NAME#/auth/index.php?confirm_registration=yes&confirm_user_id=#USER_ID#&confirm_code=#CONFIRM_CODE#\n\nВы также можете ввести код для подтверждения регистрации на странице:\nhttp://#SERVER_NAME#/auth/index.php?confirm_registration=yes&confirm_user_id=#USER_ID#\n\nВнимание! Ваш профиль не будет активным, пока вы не подтвердите свою регистрацию.\n\n---------------------------------------------------------------------\n\nСообщение сгенерировано автоматически.','text',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
	(6,'2014-07-03 23:56:10','USER_INVITE','s1','Y','#DEFAULT_EMAIL_FROM#','#EMAIL#','#SITE_NAME#: Приглашение на сайт','Информационное сообщение сайта #SITE_NAME#\n------------------------------------------\nЗдравствуйте, #NAME# #LAST_NAME#!\n\nАдминистратором сайта вы добавлены в число зарегистрированных пользователей.\n\nПриглашаем Вас на наш сайт.\n\nВаша регистрационная информация:\n\nID пользователя: #ID#\nLogin: #LOGIN#\n\nРекомендуем вам сменить установленный автоматически пароль.\n\nДля смены пароля перейдите по следующей ссылке:\nhttp://#SERVER_NAME#/auth.php?change_password=yes&USER_LOGIN=#URL_LOGIN#&USER_CHECKWORD=#CHECKWORD#\n','text',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
	(7,'2014-07-03 23:56:10','FEEDBACK_FORM','s1','Y','#DEFAULT_EMAIL_FROM#','#EMAIL_TO#','#SITE_NAME#: Сообщение из формы обратной связи','Информационное сообщение сайта #SITE_NAME#\n------------------------------------------\n\nВам было отправлено сообщение через форму обратной связи\n\nАвтор: #AUTHOR#\nE-mail автора: #AUTHOR_EMAIL#\n\nТекст сообщения:\n#TEXT#\n\nСообщение сгенерировано автоматически.','text',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
	(21,'2014-07-03 23:56:20','FORUM_NEW_MESSAGE_MAIL','s1','Y','#FROM_EMAIL#','#RECIPIENT#','#TOPIC_TITLE#','#MESSAGE_TEXT#\n\n------------------------------------------  \nВы получили это сообщение, так как выподписаны на форум #FORUM_NAME#.\n\nОтветить на сообщение можно по электронной почте или через форму на сайте:\nhttp://#SERVER_NAME##PATH2FORUM#\n\nНаписать новое сообщение: #FORUM_EMAIL#\n\nАвтор сообщения: #AUTHOR#\n\nСообщение сгенерировано автоматически на сайте #SITE_NAME#.\n','text',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
	(22,'2014-07-03 23:56:28','VIRUS_DETECTED','s1','Y','#DEFAULT_EMAIL_FROM#','#EMAIL#','#SITE_NAME#: Обнаружен вирус','Информационное сообщение сайта #SITE_NAME#\n------------------------------------------\n\nЗдравствуйте!\n\nВы получили это сообщение, так как модуль проактивной защиты сервера #SERVER_NAME# обнаружил код, похожий на вирус.\n\n1. Подозрительный код был вырезан из html.\n2. Проверьте журнал вторжений и убедитесь, что код действительно вредоносный, а не является кодом какого-либо счетчика или фреймворка.\n (ссылка: http://#SERVER_NAME#/bitrix/admin/event_log.php?lang=ru&set_filter=Y&find_type=audit_type_id&find_audit_type[]=SECURITY_VIRUS )\n3. В случае, если код не является опасным, добавьте его в исключения на странице настройки антивируса.\n (ссылка: http://#SERVER_NAME#/bitrix/admin/security_antivirus.php?lang=ru&tabControl_active_tab=exceptions )\n4. Если код является вирусным, то необходимо выполнить следующие действия:\n\n а) Смените пароли доступа к сайту у администраторов и ответственных сотрудников.\n б) Смените пароли доступа по ssh и ftp.\n в) Проверьте и вылечите компьютеры администраторов, имевших доступ к сайту по ssh или ftp.\n г) В программах доступа к сайту по ssh и ftp отключите сохранение паролей.\n д) Удалите вредоносный код из зараженных файлов. Например, восстановите поврежденные файлы из самой свежей резервной копии.\n\n---------------------------------------------------------------------\nСообщение сгенерировано автоматически.\n','text','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
	(23,'2014-07-03 23:56:29','SUBSCRIBE_CONFIRM','s1','Y','#DEFAULT_EMAIL_FROM#','#EMAIL#','#SITE_NAME#: Подтверждение подписки','Информационное сообщение сайта #SITE_NAME#\n------------------------------------------\n\nЗдравствуйте,\n\nВы получили это сообщение, так как ваш адрес был подписан\nна список рассылки сервера #SERVER_NAME#.\n\nДополнительная информация о подписке:\n\nАдрес подписки (email) ............ #EMAIL#\nДата добавления/редактирования .... #DATE_SUBSCR#\n\nВаш код для подтверждения подписки: #CONFIRM_CODE#\n\nДля подтверждения подписки перейдите по следующей ссылке:\nhttp://#SERVER_NAME##SUBSCR_SECTION#subscr_edit.php?ID=#ID#&CONFIRM_CODE=#CONFIRM_CODE#\n\nВы также можете ввести код для подтверждения подписки на странице:\nhttp://#SERVER_NAME##SUBSCR_SECTION#subscr_edit.php?ID=#ID#\n\nВнимание! Вы не будете получать сообщения рассылки, пока не подтвердите\nсвою подписку.\n\n---------------------------------------------------------------------\nСохраните это письмо, так как оно содержит информацию для авторизации.\nИспользуя код подтверждения подписки, вы cможете изменить параметры\nподписки или отписаться от рассылки.\n\nИзменить параметры:\nhttp://#SERVER_NAME##SUBSCR_SECTION#subscr_edit.php?ID=#ID#&CONFIRM_CODE=#CONFIRM_CODE#\n\nОтписаться:\nhttp://#SERVER_NAME##SUBSCR_SECTION#subscr_edit.php?ID=#ID#&CONFIRM_CODE=#CONFIRM_CODE#&action=unsubscribe\n---------------------------------------------------------------------\n\nСообщение сгенерировано автоматически.\n','text','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
	(24,'2014-07-03 23:56:30','VOTE_FOR','s1','Y','#DEFAULT_EMAIL_FROM#','#EMAIL_TO#','#SITE_NAME#: [V] #VOTE_TITLE#','#USER_NAME# принял участие в опросе \"#VOTE_TITLE#\":\n#VOTE_STATISTIC#\n\nhttp://#SERVER_NAME##URL#\nСообщение сгенерировано автоматически.','text',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);

/*!40000 ALTER TABLE `b_event_message` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table b_event_message_site
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_event_message_site`;

CREATE TABLE `b_event_message_site` (
  `EVENT_MESSAGE_ID` int(11) NOT NULL,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`EVENT_MESSAGE_ID`,`SITE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `b_event_message_site` WRITE;
/*!40000 ALTER TABLE `b_event_message_site` DISABLE KEYS */;

INSERT INTO `b_event_message_site` (`EVENT_MESSAGE_ID`, `SITE_ID`)
VALUES
	(1,'s1'),
	(2,'s1'),
	(3,'s1'),
	(4,'s1'),
	(5,'s1'),
	(6,'s1'),
	(7,'s1'),
	(8,'s1'),
	(9,'s1'),
	(10,'s1'),
	(11,'s1'),
	(12,'s1'),
	(13,'s1'),
	(14,'s1'),
	(15,'s1'),
	(16,'s1'),
	(17,'s1'),
	(18,'s1'),
	(19,'s1'),
	(20,'s1'),
	(21,'s1'),
	(22,'s1'),
	(23,'s1'),
	(24,'s1');

/*!40000 ALTER TABLE `b_event_message_site` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table b_event_type
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_event_type`;

CREATE TABLE `b_event_type` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `LID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `EVENT_NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `NAME` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DESCRIPTION` text COLLATE utf8_unicode_ci,
  `SORT` int(18) NOT NULL DEFAULT '150',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ux_1` (`EVENT_NAME`,`LID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `b_event_type` WRITE;
/*!40000 ALTER TABLE `b_event_type` DISABLE KEYS */;

INSERT INTO `b_event_type` (`ID`, `LID`, `EVENT_NAME`, `NAME`, `DESCRIPTION`, `SORT`)
VALUES
	(1,'ru','NEW_USER','Зарегистрировался новый пользователь','\n\n#USER_ID# - ID пользователя\n#LOGIN# - Логин\n#EMAIL# - EMail\n#NAME# - Имя\n#LAST_NAME# - Фамилия\n#USER_IP# - IP пользователя\n#USER_HOST# - Хост пользователя\n',1),
	(2,'ru','USER_INFO','Информация о пользователе','\n\n#USER_ID# - ID пользователя\n#STATUS# - Статус логина\n#MESSAGE# - Сообщение пользователю\n#LOGIN# - Логин\n#URL_LOGIN# - Логин, закодированный для использования в URL\n#CHECKWORD# - Контрольная строка для смены пароля\n#NAME# - Имя\n#LAST_NAME# - Фамилия\n#EMAIL# - E-Mail пользователя\n',2),
	(3,'ru','NEW_USER_CONFIRM','Подтверждение регистрации нового пользователя','\n\n\n#USER_ID# - ID пользователя\n#LOGIN# - Логин\n#EMAIL# - EMail\n#NAME# - Имя\n#LAST_NAME# - Фамилия\n#USER_IP# - IP пользователя\n#USER_HOST# - Хост пользователя\n#CONFIRM_CODE# - Код подтверждения\n',3),
	(4,'ru','USER_PASS_REQUEST','Запрос на смену пароля','\n\n#USER_ID# - ID пользователя\n#STATUS# - Статус логина\n#MESSAGE# - Сообщение пользователю\n#LOGIN# - Логин\n#URL_LOGIN# - Логин, закодированный для использования в URL\n#CHECKWORD# - Контрольная строка для смены пароля\n#NAME# - Имя\n#LAST_NAME# - Фамилия\n#EMAIL# - E-Mail пользователя\n',4),
	(5,'ru','USER_PASS_CHANGED','Подтверждение смены пароля','\n\n#USER_ID# - ID пользователя\n#STATUS# - Статус логина\n#MESSAGE# - Сообщение пользователю\n#LOGIN# - Логин\n#URL_LOGIN# - Логин, закодированный для использования в URL\n#CHECKWORD# - Контрольная строка для смены пароля\n#NAME# - Имя\n#LAST_NAME# - Фамилия\n#EMAIL# - E-Mail пользователя\n',5),
	(6,'ru','USER_INVITE','Приглашение на сайт нового пользователя','#ID# - ID пользователя\n#LOGIN# - Логин\n#URL_LOGIN# - Логин, закодированный для использования в URL\n#EMAIL# - EMail\n#NAME# - Имя\n#LAST_NAME# - Фамилия\n#PASSWORD# - пароль пользователя \n#CHECKWORD# - Контрольная строка для смены пароля\n#XML_ID# - ID пользователя для связи с внешними источниками\n',6),
	(7,'ru','FEEDBACK_FORM','Отправка сообщения через форму обратной связи','#AUTHOR# - Автор сообщения\n#AUTHOR_EMAIL# - Email автора сообщения\n#TEXT# - Текст сообщения\n#EMAIL_FROM# - Email отправителя письма\n#EMAIL_TO# - Email получателя письма',7),
	(8,'en','NEW_USER','New user was registered','\n\n#USER_ID# - User ID\n#LOGIN# - Login\n#EMAIL# - EMail\n#NAME# - Name\n#LAST_NAME# - Last Name\n#USER_IP# - User IP\n#USER_HOST# - User Host\n',1),
	(9,'en','USER_INFO','Account Information','\n\n#USER_ID# - User ID\n#STATUS# - Account status\n#MESSAGE# - Message for user\n#LOGIN# - Login\n#URL_LOGIN# - Encoded login for use in URL\n#CHECKWORD# - Check string for password change\n#NAME# - Name\n#LAST_NAME# - Last Name\n#EMAIL# - User E-Mail\n',2),
	(10,'en','NEW_USER_CONFIRM','New user registration confirmation','\n\n#USER_ID# - User ID\n#LOGIN# - Login\n#EMAIL# - E-mail\n#NAME# - First name\n#LAST_NAME# - Last name\n#USER_IP# - User IP\n#USER_HOST# - User host\n#CONFIRM_CODE# - Confirmation code\n',3),
	(11,'en','USER_PASS_REQUEST','Password Change Request','\n\n#USER_ID# - User ID\n#STATUS# - Account status\n#MESSAGE# - Message for user\n#LOGIN# - Login\n#URL_LOGIN# - Encoded login for use in URL\n#CHECKWORD# - Check string for password change\n#NAME# - Name\n#LAST_NAME# - Last Name\n#EMAIL# - User E-Mail\n',4),
	(12,'en','USER_PASS_CHANGED','Password Change Confirmation','\n\n#USER_ID# - User ID\n#STATUS# - Account status\n#MESSAGE# - Message for user\n#LOGIN# - Login\n#URL_LOGIN# - Encoded login for use in URL\n#CHECKWORD# - Check string for password change\n#NAME# - Name\n#LAST_NAME# - Last Name\n#EMAIL# - User E-Mail\n',5),
	(13,'en','USER_INVITE','Invitation of a new site user','#ID# - User ID\n#LOGIN# - Login\n#URL_LOGIN# - Encoded login for use in URL\n#EMAIL# - EMail\n#NAME# - Name\n#LAST_NAME# - Last Name\n#PASSWORD# - User password \n#CHECKWORD# - Password check string\n#XML_ID# - User ID to link with external data sources\n\n',6),
	(14,'en','FEEDBACK_FORM','Sending a message using a feedback form','#AUTHOR# - Message author\n#AUTHOR_EMAIL# - Author\'s e-mail address\n#TEXT# - Message text\n#EMAIL_FROM# - Sender\'s e-mail address\n#EMAIL_TO# - Recipient\'s e-mail address',7),
	(41,'ru','FORUM_NEW_MESSAGE_MAIL','Новое сообщение на форуме в режиме общения по E-Mail','#FORUM_NAME# - Название форума\n#AUTHOR# - Автор сообщения\n#FROM_EMAIL# - E-Mail для поля From письма\n#RECIPIENT# - Получатель сообщения\n#TOPIC_TITLE# - Тема сообщения\n#MESSAGE_TEXT# - Текст сообщения\n#PATH2FORUM# - Адрес сообщения\n#MESSAGE_DATE# - Дата сообщения\n#FORUM_EMAIL# - Е-Mail адрес для добавления сообщений на форум\n#FORUM_ID# - ID форума\n#TOPIC_ID# - ID темы \n#MESSAGE_ID# - ID сообщения\n#TAPPROVED# - Тема опубликована\n#MAPPROVED# - Сообщение опубликовано\n',150),
	(42,'en','FORUM_NEW_MESSAGE_MAIL','New message at the forum (e-mail messaging mode)','#FORUM_NAME# - Forum name\n#AUTHOR# - Message author\n#FROM_EMAIL# - E-Mail in the &amp;From&amp; field\n#RECIPIENT# - Message recipient\n#TOPIC_TITLE# - Message subject\n#MESSAGE_TEXT# - Message text\n#PATH2FORUM# - Message URL\n#MESSAGE_DATE# - Message date\n#FORUM_EMAIL# - E-Mail to add messages to the forum \n#FORUM_ID# - Forum ID\n#TOPIC_ID# - Topic ID \n#MESSAGE_ID# - Message ID\n#TAPPROVED# - Topic approved and published\n#MAPPROVED# - Message approved and published\n',150),
	(43,'ru','VIRUS_DETECTED','Обнаружен вирус','#EMAIL# - E-Mail администратора сайта (из настроек главного модуля)',150),
	(44,'en','VIRUS_DETECTED','Virus detected','#EMAIL# - Site administrator\'s e-mail address (from the Kernel module settings)',150),
	(45,'ru','SUBSCRIBE_CONFIRM','Подтверждение подписки','#ID# - идентификатор подписки\n#EMAIL# - адрес подписки\n#CONFIRM_CODE# - код подтверждения\n#SUBSCR_SECTION# - раздел, где находится страница редактирования подписки (задается в настройках)\n#USER_NAME# - имя подписчика (может отсутствовать)\n#DATE_SUBSCR# - дата добавления/изменения адреса\n',150),
	(46,'en','SUBSCRIBE_CONFIRM','Confirmation of subscription','#ID# - subscription ID\n#EMAIL# - subscription email\n#CONFIRM_CODE# - confirmation code\n#SUBSCR_SECTION# - section with subscription edit page (specifies in the settings)\n#USER_NAME# - subscriber\'s name (optional)\n#DATE_SUBSCR# - date of adding/change of address\n',150),
	(47,'ru','VOTE_FOR','Новый голос','#ID# - ID результата голосования\n#TIME# - время голосования\n#VOTE_TITLE# - наименование опроса\n#VOTE_DESCRIPTION# - описание опроса\n#VOTE_ID# - ID опроса\n#CHANNEL# - наименование группы опроса\n#CHANNEL_ID# - ID группы опроса\n#VOTER_ID# - ID проголосовавшего посетителя\n#USER_NAME# - ФИО пользователя\n#LOGIN# - логин\n#USER_ID# - ID пользователя\n#STAT_GUEST_ID# - ID посетителя модуля статистики\n#SESSION_ID# - ID сессии модуля статистики\n#IP# - IP адрес\n#VOTE_STATISTIC# - Сводная статистика опроса типа ( - Вопрос - Ответ )\n#URL# - Путь к опросу\n',150),
	(48,'en','VOTE_FOR','New vote','#ID# - Vote result ID\n#TIME# - Time of vote\n#VOTE_TITLE# - Poll name\n#VOTE_DESCRIPTION# - Poll description\n#VOTE_ID# - Poll ID\n#CHANNEL# - Poll group name\n#CHANNEL_ID# - Poll group ID\n#VOTER_ID# - Voter\'s user ID\n#USER_NAME# - User full name\n#LOGIN# - login\n#USER_ID# - User ID\n#STAT_GUEST_ID# - Visitor ID in web analytics module\n#SESSION_ID# - Session ID in web analytics module\n#IP# - IP address\n#VOTE_STATISTIC# - Summary statistics of this poll type ( - Question - Answer)\n#URL# - Poll URL',150);

/*!40000 ALTER TABLE `b_event_type` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table b_favorite
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_favorite`;

CREATE TABLE `b_favorite` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `TIMESTAMP_X` datetime DEFAULT NULL,
  `DATE_CREATE` datetime DEFAULT NULL,
  `C_SORT` int(18) NOT NULL DEFAULT '100',
  `MODIFIED_BY` int(18) DEFAULT NULL,
  `CREATED_BY` int(18) DEFAULT NULL,
  `MODULE_ID` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `URL` text COLLATE utf8_unicode_ci,
  `COMMENTS` text COLLATE utf8_unicode_ci,
  `LANGUAGE_ID` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `USER_ID` int(11) DEFAULT NULL,
  `CODE_ID` int(18) DEFAULT NULL,
  `COMMON` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `MENU_ID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_file
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_file`;

CREATE TABLE `b_file` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `MODULE_ID` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `HEIGHT` int(18) DEFAULT NULL,
  `WIDTH` int(18) DEFAULT NULL,
  `FILE_SIZE` int(18) NOT NULL,
  `CONTENT_TYPE` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'IMAGE',
  `SUBDIR` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FILE_NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ORIGINAL_NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DESCRIPTION` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `HANDLER_ID` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `b_file` WRITE;
/*!40000 ALTER TABLE `b_file` DISABLE KEYS */;

INSERT INTO `b_file` (`ID`, `TIMESTAMP_X`, `MODULE_ID`, `HEIGHT`, `WIDTH`, `FILE_SIZE`, `CONTENT_TYPE`, `SUBDIR`, `FILE_NAME`, `ORIGINAL_NAME`, `DESCRIPTION`, `HANDLER_ID`)
VALUES
	(2,'2014-07-08 19:25:35','iblock',0,0,555,'text/html','iblock/4bf','4bf76e173367e001f5e0a2dd0a998ea4.svg','leader1.svg','',NULL),
	(4,'2014-07-10 12:23:42','iblock',0,0,809,'text/html','iblock/f59','f59561af51ea4908b9e3f9edc3ad29ea.svg','intership.svg','',NULL),
	(6,'2014-07-11 16:18:16','iblock',0,0,3522,'text/html','iblock/408','408c73e9acbf391a55217693d1fff8a6.svg','moto.svg','',NULL),
	(8,'2014-07-11 16:24:11','iblock',0,0,4309,'text/html','iblock/453','45310d493db72c6735d65f342e4fe4fd.svg','calc.svg','',NULL),
	(10,'2014-07-11 16:38:01','iblock',0,0,6955,'text/html','iblock/f3b','f3bbd69eff2d33d01703bb24976d0233.svg','tools.svg','',NULL),
	(11,'2014-07-11 17:04:44','iblock',177,290,50858,'image/png','iblock/83d','83d68ff3fedb95ba67a33ffba586098c.png','academy-4.png','',NULL),
	(12,'2014-07-11 17:04:44','iblock',0,0,1556,'text/html','iblock/650','65079a8247013abaf48009f5287c52d5.svg','leader.svg','',NULL),
	(13,'2014-07-18 16:50:53','iblock',430,720,323871,'image/png','iblock/c7c','c7c19705d87bfc64a5b34382f1796c6d.png','academy-1.png','',NULL),
	(14,'2014-07-18 16:54:29','iblock',428,606,226275,'image/png','iblock/bd5','bd5de26cbea116f799152685baf5bb9e.png','academy-2.png','',NULL),
	(15,'2014-07-18 17:01:50','iblock',356,554,152149,'image/png','iblock/b49','b49f451e18d919f0fbc9256ae6881640.png','academy-3.png','',NULL),
	(17,'2014-07-18 17:13:28','iblock',568,622,176244,'image/png','iblock/ec1','ec14a637b7d2096ed287476c30ae9bcd.png','sputnik.png','',NULL),
	(19,'2014-07-18 17:22:48','iblock',648,478,445006,'image/png','iblock/7c6','7c65db714a2da3228d58805c25ae1f77.png','tarelka.png','',NULL);

/*!40000 ALTER TABLE `b_file` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table b_file_search
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_file_search`;

CREATE TABLE `b_file_search` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `SESS_ID` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `F_PATH` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `B_DIR` int(11) NOT NULL DEFAULT '0',
  `F_SIZE` int(11) NOT NULL DEFAULT '0',
  `F_TIME` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_filters
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_filters`;

CREATE TABLE `b_filters` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `USER_ID` int(18) DEFAULT NULL,
  `FILTER_ID` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `FIELDS` text COLLATE utf8_unicode_ci NOT NULL,
  `COMMON` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PRESET` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LANGUAGE_ID` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PRESET_ID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SORT` int(18) DEFAULT NULL,
  `SORT_FIELD` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_form
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_form`;

CREATE TABLE `b_form` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `TIMESTAMP_X` datetime DEFAULT NULL,
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `SID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `BUTTON` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `C_SORT` int(18) DEFAULT '100',
  `FIRST_SITE_ID` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `IMAGE_ID` int(18) DEFAULT NULL,
  `USE_CAPTCHA` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  `DESCRIPTION` text COLLATE utf8_unicode_ci,
  `DESCRIPTION_TYPE` varchar(4) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'html',
  `FORM_TEMPLATE` text COLLATE utf8_unicode_ci,
  `USE_DEFAULT_TEMPLATE` char(1) COLLATE utf8_unicode_ci DEFAULT 'Y',
  `SHOW_TEMPLATE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `MAIL_EVENT_TYPE` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SHOW_RESULT_TEMPLATE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PRINT_RESULT_TEMPLATE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `EDIT_RESULT_TEMPLATE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FILTER_RESULT_TEMPLATE` text COLLATE utf8_unicode_ci,
  `TABLE_RESULT_TEMPLATE` text COLLATE utf8_unicode_ci,
  `USE_RESTRICTIONS` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  `RESTRICT_USER` int(5) DEFAULT '0',
  `RESTRICT_TIME` int(10) DEFAULT '0',
  `RESTRICT_STATUS` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `STAT_EVENT1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `STAT_EVENT2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `STAT_EVENT3` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_SID` (`SID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_form_2_group
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_form_2_group`;

CREATE TABLE `b_form_2_group` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `FORM_ID` int(18) NOT NULL DEFAULT '0',
  `GROUP_ID` int(18) NOT NULL DEFAULT '0',
  `PERMISSION` int(5) NOT NULL DEFAULT '1',
  PRIMARY KEY (`ID`),
  KEY `IX_FORM_ID` (`FORM_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_form_2_mail_template
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_form_2_mail_template`;

CREATE TABLE `b_form_2_mail_template` (
  `FORM_ID` int(18) NOT NULL DEFAULT '0',
  `MAIL_TEMPLATE_ID` int(18) NOT NULL DEFAULT '0',
  PRIMARY KEY (`FORM_ID`,`MAIL_TEMPLATE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_form_2_site
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_form_2_site`;

CREATE TABLE `b_form_2_site` (
  `FORM_ID` int(18) NOT NULL DEFAULT '0',
  `SITE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`FORM_ID`,`SITE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_form_answer
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_form_answer`;

CREATE TABLE `b_form_answer` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `FIELD_ID` int(18) NOT NULL DEFAULT '0',
  `TIMESTAMP_X` datetime DEFAULT NULL,
  `MESSAGE` text COLLATE utf8_unicode_ci,
  `C_SORT` int(18) NOT NULL DEFAULT '100',
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `VALUE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FIELD_TYPE` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'text',
  `FIELD_WIDTH` int(18) DEFAULT NULL,
  `FIELD_HEIGHT` int(18) DEFAULT NULL,
  `FIELD_PARAM` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `IX_FIELD_ID` (`FIELD_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_form_crm
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_form_crm`;

CREATE TABLE `b_form_crm` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `ACTIVE` char(1) COLLATE utf8_unicode_ci DEFAULT 'Y',
  `URL` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `AUTH_HASH` varchar(32) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_form_crm_field
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_form_crm_field`;

CREATE TABLE `b_form_crm_field` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `LINK_ID` int(18) NOT NULL DEFAULT '0',
  `FIELD_ID` int(18) DEFAULT '0',
  `FIELD_ALT` varchar(100) COLLATE utf8_unicode_ci DEFAULT '',
  `CRM_FIELD` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `ix_b_form_crm_field_1` (`LINK_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_form_crm_link
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_form_crm_link`;

CREATE TABLE `b_form_crm_link` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `FORM_ID` int(18) NOT NULL DEFAULT '0',
  `CRM_ID` int(18) NOT NULL DEFAULT '0',
  `LINK_TYPE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'M',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ux_b_form_crm_link_1` (`FORM_ID`,`CRM_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_form_field
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_form_field`;

CREATE TABLE `b_form_field` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `FORM_ID` int(18) NOT NULL DEFAULT '0',
  `TIMESTAMP_X` datetime DEFAULT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `TITLE` text COLLATE utf8_unicode_ci,
  `TITLE_TYPE` varchar(4) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'text',
  `SID` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `C_SORT` int(18) NOT NULL DEFAULT '100',
  `ADDITIONAL` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `REQUIRED` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `IN_FILTER` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `IN_RESULTS_TABLE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `IN_EXCEL_TABLE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `FIELD_TYPE` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `IMAGE_ID` int(18) DEFAULT NULL,
  `COMMENTS` text COLLATE utf8_unicode_ci,
  `FILTER_TITLE` text COLLATE utf8_unicode_ci,
  `RESULTS_TABLE_TITLE` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `IX_FORM_ID` (`FORM_ID`),
  KEY `IX_SID` (`SID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_form_field_filter
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_form_field_filter`;

CREATE TABLE `b_form_field_filter` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `FIELD_ID` int(18) NOT NULL DEFAULT '0',
  `PARAMETER_NAME` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `FILTER_TYPE` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_FIELD_ID` (`FIELD_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_form_field_validator
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_form_field_validator`;

CREATE TABLE `b_form_field_validator` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `FORM_ID` int(18) NOT NULL DEFAULT '0',
  `FIELD_ID` int(18) NOT NULL DEFAULT '0',
  `TIMESTAMP_X` datetime DEFAULT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci DEFAULT 'y',
  `C_SORT` int(18) DEFAULT '100',
  `VALIDATOR_SID` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `PARAMS` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `IX_FORM_ID` (`FORM_ID`),
  KEY `IX_FIELD_ID` (`FIELD_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_form_menu
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_form_menu`;

CREATE TABLE `b_form_menu` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `FORM_ID` int(18) NOT NULL DEFAULT '0',
  `LID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `MENU` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_FORM_ID` (`FORM_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_form_result
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_form_result`;

CREATE TABLE `b_form_result` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `TIMESTAMP_X` datetime DEFAULT NULL,
  `DATE_CREATE` datetime DEFAULT NULL,
  `STATUS_ID` int(18) NOT NULL DEFAULT '0',
  `FORM_ID` int(18) NOT NULL DEFAULT '0',
  `USER_ID` int(18) DEFAULT NULL,
  `USER_AUTH` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `STAT_GUEST_ID` int(18) DEFAULT NULL,
  `STAT_SESSION_ID` int(18) DEFAULT NULL,
  `SENT_TO_CRM` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  PRIMARY KEY (`ID`),
  KEY `IX_FORM_ID` (`FORM_ID`),
  KEY `IX_STATUS_ID` (`STATUS_ID`),
  KEY `IX_SENT_TO_CRM` (`SENT_TO_CRM`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_form_result_answer
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_form_result_answer`;

CREATE TABLE `b_form_result_answer` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `RESULT_ID` int(18) NOT NULL DEFAULT '0',
  `FORM_ID` int(18) NOT NULL DEFAULT '0',
  `FIELD_ID` int(18) NOT NULL DEFAULT '0',
  `ANSWER_ID` int(18) DEFAULT NULL,
  `ANSWER_TEXT` text COLLATE utf8_unicode_ci,
  `ANSWER_TEXT_SEARCH` longtext COLLATE utf8_unicode_ci,
  `ANSWER_VALUE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ANSWER_VALUE_SEARCH` longtext COLLATE utf8_unicode_ci,
  `USER_TEXT` longtext COLLATE utf8_unicode_ci,
  `USER_TEXT_SEARCH` longtext COLLATE utf8_unicode_ci,
  `USER_DATE` datetime DEFAULT NULL,
  `USER_FILE_ID` int(18) DEFAULT NULL,
  `USER_FILE_NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `USER_FILE_IS_IMAGE` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `USER_FILE_HASH` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `USER_FILE_SUFFIX` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `USER_FILE_SIZE` int(18) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_RESULT_ID` (`RESULT_ID`),
  KEY `IX_FIELD_ID` (`FIELD_ID`),
  KEY `IX_ANSWER_ID` (`ANSWER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_form_status
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_form_status`;

CREATE TABLE `b_form_status` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `FORM_ID` int(18) NOT NULL DEFAULT '0',
  `TIMESTAMP_X` datetime DEFAULT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `C_SORT` int(18) NOT NULL DEFAULT '100',
  `TITLE` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `DESCRIPTION` text COLLATE utf8_unicode_ci,
  `DEFAULT_VALUE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `CSS` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'statusgreen',
  `HANDLER_OUT` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `HANDLER_IN` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `MAIL_EVENT_TYPE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_FORM_ID` (`FORM_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_form_status_2_group
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_form_status_2_group`;

CREATE TABLE `b_form_status_2_group` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `STATUS_ID` int(18) NOT NULL DEFAULT '0',
  `GROUP_ID` int(18) NOT NULL DEFAULT '0',
  `PERMISSION` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_FORM_STATUS_GROUP` (`STATUS_ID`,`GROUP_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_form_status_2_mail_template
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_form_status_2_mail_template`;

CREATE TABLE `b_form_status_2_mail_template` (
  `STATUS_ID` int(18) NOT NULL DEFAULT '0',
  `MAIL_TEMPLATE_ID` int(18) NOT NULL DEFAULT '0',
  PRIMARY KEY (`STATUS_ID`,`MAIL_TEMPLATE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_forum
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_forum`;

CREATE TABLE `b_forum` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `FORUM_GROUP_ID` int(11) DEFAULT NULL,
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `DESCRIPTION` text COLLATE utf8_unicode_ci,
  `SORT` int(10) NOT NULL DEFAULT '150',
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `ALLOW_HTML` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ALLOW_ANCHOR` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `ALLOW_BIU` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `ALLOW_IMG` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `ALLOW_VIDEO` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `ALLOW_LIST` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `ALLOW_QUOTE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `ALLOW_CODE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `ALLOW_FONT` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `ALLOW_SMILES` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `ALLOW_UPLOAD` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ALLOW_TABLE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ALLOW_ALIGN` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `ALLOW_UPLOAD_EXT` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ALLOW_MOVE_TOPIC` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `ALLOW_TOPIC_TITLED` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ALLOW_NL2BR` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ALLOW_SIGNATURE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `PATH2FORUM_MESSAGE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ASK_GUEST_EMAIL` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `USE_CAPTCHA` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `INDEXATION` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `DEDUPLICATION` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `MODERATION` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ORDER_BY` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'P',
  `ORDER_DIRECTION` varchar(4) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'DESC',
  `LID` char(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'ru',
  `TOPICS` int(11) NOT NULL DEFAULT '0',
  `POSTS` int(11) NOT NULL DEFAULT '0',
  `LAST_POSTER_ID` int(11) DEFAULT NULL,
  `LAST_POSTER_NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LAST_POST_DATE` datetime DEFAULT NULL,
  `LAST_MESSAGE_ID` bigint(20) DEFAULT NULL,
  `POSTS_UNAPPROVED` int(11) DEFAULT '0',
  `ABS_LAST_POSTER_ID` int(11) DEFAULT NULL,
  `ABS_LAST_POSTER_NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ABS_LAST_POST_DATE` datetime DEFAULT NULL,
  `ABS_LAST_MESSAGE_ID` bigint(20) DEFAULT NULL,
  `EVENT1` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'forum',
  `EVENT2` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'message',
  `EVENT3` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `HTML` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `XML_ID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_FORUM_SORT` (`SORT`),
  KEY `IX_FORUM_ACTIVE` (`ACTIVE`),
  KEY `IX_FORUM_GROUP_ID` (`FORUM_GROUP_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_forum_dictionary
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_forum_dictionary`;

CREATE TABLE `b_forum_dictionary` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `TITLE` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TYPE` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `b_forum_dictionary` WRITE;
/*!40000 ALTER TABLE `b_forum_dictionary` DISABLE KEYS */;

INSERT INTO `b_forum_dictionary` (`ID`, `TITLE`, `TYPE`)
VALUES
	(1,'[ru] Словарь слов','W'),
	(2,'[ru] Словарь транслита','T'),
	(3,'[en] Bad words','W'),
	(4,'[en] Transliteration','T');

/*!40000 ALTER TABLE `b_forum_dictionary` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table b_forum_email
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_forum_email`;

CREATE TABLE `b_forum_email` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `EMAIL_FORUM_ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `FORUM_ID` int(11) NOT NULL,
  `SOCNET_GROUP_ID` int(11) DEFAULT NULL,
  `MAIL_FILTER_ID` int(11) NOT NULL,
  `EMAIL` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `USE_EMAIL` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `EMAIL_GROUP` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SUBJECT_SUF` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `USE_SUBJECT` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `URL_TEMPLATES_MESSAGE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `NOT_MEMBER_POST` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_B_FORUM_EMAIL_FORUM_SOC` (`FORUM_ID`,`SOCNET_GROUP_ID`),
  KEY `IX_B_FORUM_EMAIL_FILTER_ID` (`MAIL_FILTER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_forum_file
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_forum_file`;

CREATE TABLE `b_forum_file` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `FORUM_ID` int(18) DEFAULT NULL,
  `TOPIC_ID` int(20) DEFAULT NULL,
  `MESSAGE_ID` int(20) DEFAULT NULL,
  `FILE_ID` int(18) NOT NULL,
  `USER_ID` int(18) DEFAULT NULL,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `HITS` int(18) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_FORUM_FILE_FILE` (`FILE_ID`),
  KEY `IX_FORUM_FILE_FORUM` (`FORUM_ID`),
  KEY `IX_FORUM_FILE_TOPIC` (`TOPIC_ID`),
  KEY `IX_FORUM_FILE_MESSAGE` (`MESSAGE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_forum_filter
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_forum_filter`;

CREATE TABLE `b_forum_filter` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `DICTIONARY_ID` int(11) DEFAULT NULL,
  `WORDS` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PATTERN` text COLLATE utf8_unicode_ci,
  `REPLACEMENT` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DESCRIPTION` text COLLATE utf8_unicode_ci,
  `USE_IT` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PATTERN_CREATE` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_B_FORUM_FILTER_2` (`USE_IT`),
  KEY `IX_B_FORUM_FILTER_3` (`PATTERN_CREATE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `b_forum_filter` WRITE;
/*!40000 ALTER TABLE `b_forum_filter` DISABLE KEYS */;

INSERT INTO `b_forum_filter` (`ID`, `DICTIONARY_ID`, `WORDS`, `PATTERN`, `REPLACEMENT`, `DESCRIPTION`, `USE_IT`, `PATTERN_CREATE`)
VALUES
	(1,1,'*пизд*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])([^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*([ПпPp]+)([ИиIi]+)([ЗзZz3]+)([ДдDd]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(2,1,'*пизж*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])([^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*([ПпPp]+)([ИиIi]+)([ЗзZz3]+)([ЖжGg]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(3,1,'*сра%','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])([^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*([СсCc]+)([РрPpRr]+)([АаAa]+)([[Цц]+([Аа]+|[Оо]+)]+|[[Тт]+([Ьь]+|)[Сс]+[Яя]+]+))(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(4,1,'анобляд*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([АаAa]+)([НнNn]+)([ОоOo]+)([БбBb]+)([ЛлLl]+)([Яя]+)([ДдDd]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(5,1,'взъеб*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ВвVv]+)([ЗзZz3]+)([ЪъЬь\"\']+|)([ЁёЕеEe]+)([БбBb]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(6,1,'бля','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([БбBb]+)([ЛлLl]+)([Яя]+))(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(7,1,'долбоеб*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ДдDd]+)([ОоOo]+)([ЛлLl]+)([БбBb]+)([ОоOo]+)([ЁёЕеEe]+)([БбBb]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(8,1,'дуроеб*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ДдDd]+)([УуUu]+)([РрPpRr]+)([ОоOo]+)([ЁёЕеEe]+)([БбBb]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(9,1,'еби','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ЁёЕеEe]+)([БбBb]+)([ИиIi]+))(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(10,1,'ебисти*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ЁёЕеEe]+)([БбBb]+)([ИиIi]+)([СсCc]+)([ТтTt]+)([ИиIi]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(11,1,'ебическ*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ЁёЕеEe]+)([БбBb]+)([ИиIi]+)([Чч]+)([ЁёЕеEe]+)([СсCc]+)([КкKk]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(12,1,'еблив*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ЁёЕеEe]+)([БбBb]+)([ЛлLl]+)([ИиIi]+)([ВвVv]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(13,1,'ебло*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ЁёЕеEe]+)([БбBb]+)([ЛлLl]+)([ОоOo]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(14,1,'еблыс*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ЁёЕеEe]+)([БбBb]+)([ЛлLl]+)([Ыы]+)([СсCc]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(15,1,'ебля','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ЁёЕеEe]+)([БбBb]+)([ЛлLl]+)([Яя]+))(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(16,1,'ебс','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ЁёЕеEe]+)([БбBb]+)([СсCc]+))(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(17,1,'ебукент*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ЁёЕеEe]+)([БбBb]+)([УуUu]+)([КкKk]+)([ЁёЕеEe]+)([НнNn]+)([ТтTt]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(18,1,'ебурген*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ЁёЕеEe]+)([БбBb]+)([УуUu]+)([РрPpRr]+)([Гг]+)([ЁёЕеEe]+)([НнNn]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(19,1,'коноебит*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([КкKk]+)([ОоOo]+)([НнNn]+)([ОоOo]+)([ЁёЕеEe]+)([БбBb]+)([ИиIi]+)([ТтTt]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(20,1,'мозгоеб*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([МмMm]+)([ОоOo]+)([ЗзZz3]+)([Гг]+)([ОоOo]+)([ЁёЕеEe]+)([БбBb]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(21,1,'мудоеб*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([МмMm]+)([УуUu]+)([ДдDd]+)([ОоOo]+)([ЁёЕеEe]+)([БбBb]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(22,1,'однохуйствен*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ОоOo]+)([ДдDd]+)([НнNn]+)([ОоOo]+)([ХхXx]+)([УуUu]+)([ЙйИиYy]+)([СсCc]+)([ТтTt]+)([ВвVv]+)([ЁёЕеEe]+)([НнNn]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(23,1,'охуе*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ОоOo]+)([ХхXx]+)([УуUu]+)([ЁёЕеEe]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(24,1,'охуи*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ОоOo]+)([ХхXx]+)([УуUu]+)([ИиIi]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(25,1,'охуя*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ОоOo]+)([ХхXx]+)([УуUu]+)([Яя]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(26,1,'разъеба*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([РрPpRr]+)([АаAa]+)([ЗзZz3]+)([ЪъЬь\"\']+|)([ЁёЕеEe]+)([БбBb]+)([АаAa]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(27,1,'распиздон*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([РрPpRr]+)([АаAa]+)([СсCc]+)([ПпPp]+)([ИиIi]+)([ЗзZz3]+)([ДдDd]+)([ОоOo]+)([НнNn]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(28,1,'расхуюж*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([РрPpRr]+)([АаAa]+)([СсCc]+)([ХхXx]+)([УуUu]+)([Юю]+|[[Йй]+[Оо]+]+)([ЖжGg]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(29,1,'худоебин*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ХхXx]+)([УуUu]+)([ДдDd]+)([ОоOo]+)([ЁёЕеEe]+)([БбBb]+)([ИиIi]+)([НнNn]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(30,1,'хуе','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ХхXx]+)([УуUu]+)([ЁёЕеEe]+))(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(31,1,'хуебрат*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ХхXx]+)([УуUu]+)([ЁёЕеEe]+)([БбBb]+)([РрPpRr]+)([АаAa]+)([ТтTt]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(32,1,'хуеглот*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ХхXx]+)([УуUu]+)([ЁёЕеEe]+)([Гг]+)([ЛлLl]+)([ОоOo]+)([ТтTt]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(33,1,'хуеплёт*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ХхXx]+)([УуUu]+)([ЁёЕеEe]+)([ПпPp]+)([ЛлLl]+)([ЁёЕеEe]+|[[Йй]+[Оо]+]+)([ТтTt]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(34,1,'хует*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ХхXx]+)([УуUu]+)([ЁёЕеEe]+)([ТтTt]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(35,1,'хуила','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ХхXx]+)([УуUu]+)([ИиIi]+)([ЛлLl]+)([АаAa]+))(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(36,1,'хул?','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ХхXx]+)([УуUu]+)([ЛлLl]+).?)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(37,1,'хуя','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ХхXx]+)([УуUu]+)([Яя]+))(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(38,1,'^бляд*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ВвЗзСс]+|[ВвЫы]+|[ДдОо]+|[ЗзАа]+|[ИиЗзСс]+|[НнАа]+|[НнЕе]+|[ОоТт]+|([Пп]*[Ее]+[Рр]+[Ее]+)+|)([БбBb]+)([ЛлLl]+)([Яя]+)([ДдDd]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(39,1,'^пидор*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ВвЗзСс]+|[ВвЫы]+|[ДдОо]+|[ЗзАа]+|[ИиЗзСс]+|[НнАа]+|[НнЕе]+|[ОоТт]+|([Пп]*[Ее]+[Рр]+[Ее]+)+|)([ПпPp]+)([ИиIi]+)([ДдDd]+)([ОоOo]+)([РрPpRr]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(40,1,'^хуев*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ВвЗзСс]+|[ВвЫы]+|[ДдОо]+|[ЗзАа]+|[ИиЗзСс]+|[НнАа]+|[НнЕе]+|[ОоТт]+|([Пп]*[Ее]+[Рр]+[Ее]+)+|)([ХхXx]+)([УуUu]+)([ЁёЕеEe]+)([ВвVv]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(41,1,'^хуем*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ВвЗзСс]+|[ВвЫы]+|[ДдОо]+|[ЗзАа]+|[ИиЗзСс]+|[НнАа]+|[НнЕе]+|[ОоТт]+|([Пп]*[Ее]+[Рр]+[Ее]+)+|)([ХхXx]+)([УуUu]+)([ЁёЕеEe]+)([МмMm]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(42,1,'^хуй*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ВвЗзСс]+|[ВвЫы]+|[ДдОо]+|[ЗзАа]+|[ИиЗзСс]+|[НнАа]+|[НнЕе]+|[ОоТт]+|([Пп]*[Ее]+[Рр]+[Ее]+)+|)([ХхXx]+)([УуUu]+)([ЙйИиYy]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(43,1,'^хуяк*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ВвЗзСс]+|[ВвЫы]+|[ДдОо]+|[ЗзАа]+|[ИиЗзСс]+|[НнАа]+|[НнЕе]+|[ОоТт]+|([Пп]*[Ее]+[Рр]+[Ее]+)+|)([ХхXx]+)([УуUu]+)([Яя]+)([КкKk]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(44,1,'^хуям*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ВвЗзСс]+|[ВвЫы]+|[ДдОо]+|[ЗзАа]+|[ИиЗзСс]+|[НнАа]+|[НнЕе]+|[ОоТт]+|([Пп]*[Ее]+[Рр]+[Ее]+)+|)([ХхXx]+)([УуUu]+)([Яя]+)([МмMm]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(45,1,'^хуяр*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ВвЗзСс]+|[ВвЫы]+|[ДдОо]+|[ЗзАа]+|[ИиЗзСс]+|[НнАа]+|[НнЕе]+|[ОоТт]+|([Пп]*[Ее]+[Рр]+[Ее]+)+|)([ХхXx]+)([УуUu]+)([Яя]+)([РрPpRr]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(46,1,'^хуяч*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ВвЗзСс]+|[ВвЫы]+|[ДдОо]+|[ЗзАа]+|[ИиЗзСс]+|[НнАа]+|[НнЕе]+|[ОоТт]+|([Пп]*[Ее]+[Рр]+[Ее]+)+|)([ХхXx]+)([УуUu]+)([Яя]+)([Чч]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(47,1,'^ъебал*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ВвЗзСс]+|[ВвЫы]+|[ДдОо]+|[ЗзАа]+|[ИиЗзСс]+|[НнАа]+|[НнЕе]+|[ОоТт]+|([Пп]*[Ее]+[Рр]+[Ее]+)+|)([ЪъЬь\"\']+|)([ЁёЕеEe]+)([БбBb]+)([АаAa]+)([ЛлLl]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(48,1,'^ъебан*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ВвЗзСс]+|[ВвЫы]+|[ДдОо]+|[ЗзАа]+|[ИиЗзСс]+|[НнАа]+|[НнЕе]+|[ОоТт]+|([Пп]*[Ее]+[Рр]+[Ее]+)+|)([ЪъЬь\"\']+|)([ЁёЕеEe]+)([БбBb]+)([АаAa]+)([НнNn]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(49,1,'^ъебар*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ВвЗзСс]+|[ВвЫы]+|[ДдОо]+|[ЗзАа]+|[ИиЗзСс]+|[НнАа]+|[НнЕе]+|[ОоТт]+|([Пп]*[Ее]+[Рр]+[Ее]+)+|)([ЪъЬь\"\']+|)([ЁёЕеEe]+)([БбBb]+)([АаAa]+)([РрPpRr]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(50,1,'^ъебат*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ВвЗзСс]+|[ВвЫы]+|[ДдОо]+|[ЗзАа]+|[ИиЗзСс]+|[НнАа]+|[НнЕе]+|[ОоТт]+|([Пп]*[Ее]+[Рр]+[Ее]+)+|)([ЪъЬь\"\']+|)([ЁёЕеEe]+)([БбBb]+)([АаAa]+)([ТтTt]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(51,1,'^ъебен*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ВвЗзСс]+|[ВвЫы]+|[ДдОо]+|[ЗзАа]+|[ИиЗзСс]+|[НнАа]+|[НнЕе]+|[ОоТт]+|([Пп]*[Ее]+[Рр]+[Ее]+)+|)([ЪъЬь\"\']+|)([ЁёЕеEe]+)([БбBb]+)([ЁёЕеEe]+)([НнNn]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(52,1,'^ъеби','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ВвЗзСс]+|[ВвЫы]+|[ДдОо]+|[ЗзАа]+|[ИиЗзСс]+|[НнАа]+|[НнЕе]+|[ОоТт]+|([Пп]*[Ее]+[Рр]+[Ее]+)+|)([ЪъЬь\"\']+|)([ЁёЕеEe]+)([БбBb]+)([ИиIi]+))(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(53,1,'^ъебис*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ВвЗзСс]+|[ВвЫы]+|[ДдОо]+|[ЗзАа]+|[ИиЗзСс]+|[НнАа]+|[НнЕе]+|[ОоТт]+|([Пп]*[Ее]+[Рр]+[Ее]+)+|)([ЪъЬь\"\']+|)([ЁёЕеEe]+)([БбBb]+)([ИиIi]+)([СсCc]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(54,1,'^ъебит*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ВвЗзСс]+|[ВвЫы]+|[ДдОо]+|[ЗзАа]+|[ИиЗзСс]+|[НнАа]+|[НнЕе]+|[ОоТт]+|([Пп]*[Ее]+[Рр]+[Ее]+)+|)([ЪъЬь\"\']+|)([ЁёЕеEe]+)([БбBb]+)([ИиIi]+)([ТтTt]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(55,1,'^ъёбля*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ВвЗзСс]+|[ВвЫы]+|[ДдОо]+|[ЗзАа]+|[ИиЗзСс]+|[НнАа]+|[НнЕе]+|[ОоТт]+|([Пп]*[Ее]+[Рр]+[Ее]+)+|)([ЪъЬь\"\']+|)([ЁёЕеEe]+|[[Йй]+[Оо]+]+)([БбBb]+)([ЛлLl]+)([Яя]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(56,1,'^ъёбну*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ВвЗзСс]+|[ВвЫы]+|[ДдОо]+|[ЗзАа]+|[ИиЗзСс]+|[НнАа]+|[НнЕе]+|[ОоТт]+|([Пп]*[Ее]+[Рр]+[Ее]+)+|)([ЪъЬь\"\']+|)([ЁёЕеEe]+|[[Йй]+[Оо]+]+)([БбBb]+)([НнNn]+)([УуUu]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(57,1,'^ъебу','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ВвЗзСс]+|[ВвЫы]+|[ДдОо]+|[ЗзАа]+|[ИиЗзСс]+|[НнАа]+|[НнЕе]+|[ОоТт]+|([Пп]*[Ее]+[Рр]+[Ее]+)+|)([ЪъЬь\"\']+|)([ЁёЕеEe]+)([БбBb]+)([УуUu]+))(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(58,1,'^ъебуч*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ВвЗзСс]+|[ВвЫы]+|[ДдОо]+|[ЗзАа]+|[ИиЗзСс]+|[НнАа]+|[НнЕе]+|[ОоТт]+|([Пп]*[Ее]+[Рр]+[Ее]+)+|)([ЪъЬь\"\']+|)([ЁёЕеEe]+)([БбBb]+)([УуUu]+)([Чч]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(59,1,'^ъебыв*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(([ВвЗзСс]+|[ВвЫы]+|[ДдОо]+|[ЗзАа]+|[ИиЗзСс]+|[НнАа]+|[НнЕе]+|[ОоТт]+|([Пп]*[Ее]+[Рр]+[Ее]+)+|)([ЪъЬь\"\']+|)([ЁёЕеEe]+)([БбBb]+)([Ыы]+)([ВвVv]+)[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(60,1,'/(?<=[s.,;:!?-#*|[]()])(?![Вв][ЕеЁё][Бб])(([ВвЗзСс]+|[Ввы]+|[ДдОо]+|[ЗзАа]+|[ИиЗзСс]+|[НнАа]+|[НнЕе]+|[ОоТт]+|([Пп]*[Ее]+[Рр]+[Ее]+)|)([ЬьЪъ]+|)([ЁёЕеEe]+|[Йй]+[Оо]+|[Yy]+[Oo]+)([BbБб]+))(?=[s.,;:!?-#*|[]()])/is','','','','Y','PTTRN'),
	(61,3,'angry','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(a+n+g+r+y+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(62,3,'ass','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(a+s+s+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(63,3,'asshole','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(a+s+s+h+o+l+e+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(64,3,'banger','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(b+a+n+g+e+r+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(65,3,'bastard','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(b+a+s+t+a+r+d+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(66,3,'batter','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(b+a+t+t+e+r+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(67,3,'bicho','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(b+i+c+h+o+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(68,3,'bisexual','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(b+i+s+e+x+u+a+l+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(69,3,'bitch','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(b+i+t+c+h+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(70,3,'blumpkin','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(b+l+u+m+p+k+i+n+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(71,3,'booger','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(b+o+o+g+e+r+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(72,3,'bugger*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(b+u+g+g+e+r+[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(73,3,'bukakke','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(b+u+k+a+k+k+e+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(74,3,'bull','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(b+u+l+l+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(75,3,'bulldyke','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(b+u+l+l+d+y+k+e+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(76,3,'bullshit','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(b+u+l+l+s+h+i+t+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(77,3,'bunny','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(b+u+n+n+y+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(78,3,'bunnyfuck','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(b+u+n+n+y+f+u+c+k+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(79,3,'chocha','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(c+h+o+c+h+a+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(80,3,'chode','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(c+h+o+d+e+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(81,3,'clap','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(c+l+a+p+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(82,3,'coconuts','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(c+o+c+o+n+u+t+s+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(83,3,'cohones','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(c+o+h+o+n+e+s+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(84,3,'cojones','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(c+o+j+o+n+e+s+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(85,3,'coon','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(c+o+o+n+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(86,3,'cootch','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(c+o+o+t+c+h+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(87,3,'cooter','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(c+o+o+t+e+r+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(88,3,'cornhole','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(c+o+r+n+h+o+l+e+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(89,3,'cracka','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(c+r+a+c+k+a+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(90,3,'crap','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(c+r+a+p+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(91,3,'cum','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(c+u+m+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(92,3,'cunnilingus','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(c+u+n+n+i+l+i+n+g+u+s+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(93,3,'cunt*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(c+u+n+t+[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(94,3,'damn*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(d+a+m+n+[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(95,3,'dark*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(d+a+r+k+[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(96,3,'dick','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(d+i+c+k+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(97,3,'dickhead','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(d+i+c+k+h+e+a+d+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(98,3,'diddle','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(d+i+d+d+l+e+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(99,3,'dildo','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(d+i+l+d+o+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(100,3,'dilhole','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(d+i+l+h+o+l+e+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(101,3,'dingleberry','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(d+i+n+g+l+e+b+e+r+r+y+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(102,3,'doodle','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(d+o+o+d+l+e+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(103,3,'dork','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(d+o+r+k+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(104,3,'dumpster','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(d+u+m+p+s+t+e+r+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(105,3,'faggot','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(f+a+g+g+o+t+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(106,3,'fart','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(f+a+r+t+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(107,3,'frig','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(f+r+i+g+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(108,3,'fuck*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(f+u+c+k+[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(109,3,'fucker','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(f+u+c+k+e+r+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(110,3,'giz','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(g+i+z+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(111,3,'goatse','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(g+o+a+t+s+e+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(112,3,'gook','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(g+o+o+k+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(113,3,'gringo','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(g+r+i+n+g+o+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(114,3,'hobo','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(h+o+b+o+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(115,3,'honky','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(h+o+n+k+y+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(116,3,'jackass','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(j+a+c+k+a+s+s+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(117,3,'jackoff','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(j+a+c+k+o+f+f+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(118,3,'jerkoff','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(j+e+r+k+o+f+f+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(119,3,'jiggaboo','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(j+i+g+g+a+b+o+o+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(120,3,'jizz','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(j+i+z+z+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(121,3,'kike','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(k+i+k+e+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(122,3,'mayo','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(m+a+y+o+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(123,3,'moose','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(m+o+o+s+e+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(124,3,'nigg*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(n+i+g+g+[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(125,3,'paki','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(p+a+k+i+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(126,3,'pecker','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(p+e+c+k+e+r+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(127,3,'piss','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(p+i+s+s+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(128,3,'poonanni','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(p+o+o+n+a+n+n+i+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(129,3,'poontang','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(p+o+o+n+t+a+n+g+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(130,3,'prick','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(p+r+i+c+k+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(131,3,'punch','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(p+u+n+c+h+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(132,3,'queef','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(q+u+e+e+f+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(133,3,'rogue','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(r+o+g+u+e+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(134,3,'sanchez','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(s+a+n+c+h+e+z+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(135,3,'schlong','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(s+c+h+l+o+n+g+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(136,3,'shit','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(s+h+i+t+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(137,3,'skank','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(s+k+a+n+k+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(138,3,'spaz','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(s+p+a+z+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(139,3,'spic','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(s+p+i+c+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(140,3,'teabag*','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(t+e+a+b+a+g+[^\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)]*)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(141,3,'tits','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(t+i+t+s+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(142,3,'twat','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(t+w+a+t+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(143,3,'twot','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(t+w+o+t+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(144,3,'vart','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(v+a+r+t+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(145,3,'wanker','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(w+a+n+k+e+r+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(146,3,'waste','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(w+a+s+t+e+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(147,3,'wetback','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(w+e+t+b+a+c+k+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(148,3,'whore','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(w+h+o+r+e+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(149,3,'wigger','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(w+i+g+g+e+r+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(150,3,'wog','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(w+o+g+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL'),
	(151,3,'wop','/(?<=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])(w+o+p+)(?=[\\s.,;:!?\\#\\-\\*\\|\\[\\]\\(\\)])/isu','','','Y','TRNSL');

/*!40000 ALTER TABLE `b_forum_filter` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table b_forum_group
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_forum_group`;

CREATE TABLE `b_forum_group` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `SORT` int(11) NOT NULL DEFAULT '150',
  `PARENT_ID` int(11) DEFAULT NULL,
  `LEFT_MARGIN` int(11) DEFAULT NULL,
  `RIGHT_MARGIN` int(11) DEFAULT NULL,
  `DEPTH_LEVEL` int(11) DEFAULT NULL,
  `XML_ID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_forum_group_lang
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_forum_group_lang`;

CREATE TABLE `b_forum_group_lang` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `FORUM_GROUP_ID` int(11) NOT NULL,
  `LID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `DESCRIPTION` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UX_FORUM_GROUP` (`FORUM_GROUP_ID`,`LID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_forum_letter
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_forum_letter`;

CREATE TABLE `b_forum_letter` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `DICTIONARY_ID` int(11) DEFAULT '0',
  `LETTER` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `REPLACEMENT` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `b_forum_letter` WRITE;
/*!40000 ALTER TABLE `b_forum_letter` DISABLE KEYS */;

INSERT INTO `b_forum_letter` (`ID`, `DICTIONARY_ID`, `LETTER`, `REPLACEMENT`)
VALUES
	(1,2,'а','АаAa'),
	(2,2,'б','БбBb'),
	(3,2,'в','ВвVv'),
	(4,2,'г','Гг'),
	(5,2,'д','ДдDd'),
	(6,2,'е','ЁёЕеEe'),
	(7,2,'ё','ЁёЕеEe, [Йй]+[Оо]+'),
	(8,2,'ж','ЖжGg'),
	(9,2,'з','ЗзZz3'),
	(10,2,'и','ИиIi'),
	(11,2,'й','ЙйИиYy'),
	(12,2,'к','КкKk'),
	(13,2,'л','ЛлLl'),
	(14,2,'м','МмMm'),
	(15,2,'н','НнNn'),
	(16,2,'о','ОоOo'),
	(17,2,'п','ПпPp'),
	(18,2,'р','РрPpRr'),
	(19,2,'с','СсCc'),
	(20,2,'т','ТтTt'),
	(21,2,'у','УуUu'),
	(22,2,'ф','ФфFf'),
	(23,2,'х','ХхXx'),
	(24,2,'ц','ЦцCc'),
	(25,2,'ч','Чч'),
	(26,2,'ш','Шш'),
	(27,2,'щ','Щщ'),
	(28,2,'ь','ЪъЬь\"\','),
	(29,2,'ы','Ыы'),
	(30,2,'ъ','ЪъЬь\"\','),
	(31,2,'э','Ээ'),
	(32,2,'ю','Юю, [Йй]+[Оо]+'),
	(33,2,'я','Яя'),
	(34,2,'%','[Цц]+([Аа]+|[Оо]+), [Тт]+([Ьь]+|)[Сс]+[Яя]+'),
	(35,2,'^',',ВвЗзСс,ВвЫы,ДдОо,ЗзАа,ИиЗзСс,НнАа,НнЕе,ОоТт,([Пп]*[Ее]+[Рр]+[Ее]+)'),
	(36,2,'тся','%'),
	(37,2,'ться','%');

/*!40000 ALTER TABLE `b_forum_letter` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table b_forum_message
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_forum_message`;

CREATE TABLE `b_forum_message` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `FORUM_ID` int(10) NOT NULL,
  `TOPIC_ID` bigint(20) NOT NULL,
  `USE_SMILES` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `NEW_TOPIC` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `APPROVED` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `SOURCE_ID` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'WEB',
  `POST_DATE` datetime NOT NULL,
  `POST_MESSAGE` text COLLATE utf8_unicode_ci,
  `POST_MESSAGE_HTML` text COLLATE utf8_unicode_ci,
  `POST_MESSAGE_FILTER` text COLLATE utf8_unicode_ci,
  `POST_MESSAGE_CHECK` char(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ATTACH_IMG` int(11) DEFAULT NULL,
  `PARAM1` varchar(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PARAM2` int(11) DEFAULT NULL,
  `AUTHOR_ID` int(10) DEFAULT NULL,
  `AUTHOR_NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `AUTHOR_EMAIL` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `AUTHOR_IP` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `AUTHOR_REAL_IP` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `GUEST_ID` int(10) DEFAULT NULL,
  `EDITOR_ID` int(10) DEFAULT NULL,
  `EDITOR_NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `EDITOR_EMAIL` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `EDIT_REASON` text COLLATE utf8_unicode_ci,
  `EDIT_DATE` datetime DEFAULT NULL,
  `XML_ID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `HTML` text COLLATE utf8_unicode_ci,
  `MAIL_HEADER` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `IX_FORUM_MESSAGE_FORUM` (`FORUM_ID`,`APPROVED`),
  KEY `IX_FORUM_MESSAGE_TOPIC` (`TOPIC_ID`,`APPROVED`,`ID`),
  KEY `IX_FORUM_MESSAGE_AUTHOR` (`AUTHOR_ID`,`APPROVED`,`FORUM_ID`,`ID`),
  KEY `IX_FORUM_MESSAGE_APPROVED` (`APPROVED`),
  KEY `IX_FORUM_MESSAGE_PARAM2` (`PARAM2`),
  KEY `IX_FORUM_MESSAGE_XML_ID` (`XML_ID`),
  KEY `IX_FORUM_MESSAGE_DATE_AUTHOR_ID` (`POST_DATE`,`AUTHOR_ID`),
  KEY `IX_FORUM_MESSAGE_AUTHOR_TOPIC_ID` (`AUTHOR_ID`,`TOPIC_ID`,`ID`),
  KEY `IX_FORUM_MESSAGE_AUTHOR_FORUM_ID` (`AUTHOR_ID`,`FORUM_ID`,`ID`,`APPROVED`,`TOPIC_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_forum_perms
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_forum_perms`;

CREATE TABLE `b_forum_perms` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `FORUM_ID` int(11) NOT NULL,
  `GROUP_ID` int(11) NOT NULL,
  `PERMISSION` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'M',
  PRIMARY KEY (`ID`),
  KEY `IX_FORUM_PERMS_FORUM` (`FORUM_ID`,`GROUP_ID`),
  KEY `IX_FORUM_PERMS_GROUP` (`GROUP_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_forum_pm_folder
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_forum_pm_folder`;

CREATE TABLE `b_forum_pm_folder` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `TITLE` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `USER_ID` int(11) NOT NULL,
  `SORT` int(11) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_B_FORUM_PM_FOLDER_USER_IST` (`USER_ID`,`ID`,`SORT`,`TITLE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `b_forum_pm_folder` WRITE;
/*!40000 ALTER TABLE `b_forum_pm_folder` DISABLE KEYS */;

INSERT INTO `b_forum_pm_folder` (`ID`, `TITLE`, `USER_ID`, `SORT`)
VALUES
	(1,'SYSTEM_FOLDER_1',0,0),
	(2,'SYSTEM_FOLDER_2',0,0),
	(3,'SYSTEM_FOLDER_3',0,0),
	(4,'SYSTEM_FOLDER_4',0,0);

/*!40000 ALTER TABLE `b_forum_pm_folder` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table b_forum_points
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_forum_points`;

CREATE TABLE `b_forum_points` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `MIN_POINTS` int(11) NOT NULL,
  `CODE` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `VOTES` int(11) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UX_FORUM_P_MP` (`MIN_POINTS`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_forum_points_lang
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_forum_points_lang`;

CREATE TABLE `b_forum_points_lang` (
  `POINTS_ID` int(11) NOT NULL,
  `LID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `NAME` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`POINTS_ID`,`LID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_forum_points2post
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_forum_points2post`;

CREATE TABLE `b_forum_points2post` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `MIN_NUM_POSTS` int(11) NOT NULL,
  `POINTS_PER_POST` decimal(18,4) NOT NULL DEFAULT '0.0000',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UX_FORUM_P2P_MNP` (`MIN_NUM_POSTS`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_forum_private_message
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_forum_private_message`;

CREATE TABLE `b_forum_private_message` (
  `ID` bigint(10) NOT NULL AUTO_INCREMENT,
  `AUTHOR_ID` int(11) DEFAULT '0',
  `RECIPIENT_ID` int(11) DEFAULT '0',
  `POST_DATE` datetime NOT NULL,
  `POST_SUBJ` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `POST_MESSAGE` text COLLATE utf8_unicode_ci NOT NULL,
  `USER_ID` int(11) NOT NULL,
  `FOLDER_ID` int(11) NOT NULL,
  `IS_READ` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `REQUEST_IS_READ` char(1) COLLATE utf8_unicode_ci NOT NULL,
  `USE_SMILES` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_B_FORUM_PM_USER` (`USER_ID`),
  KEY `IX_B_FORUM_PM_AFR` (`AUTHOR_ID`,`FOLDER_ID`,`IS_READ`),
  KEY `IX_B_FORUM_PM_UFP` (`USER_ID`,`FOLDER_ID`,`POST_DATE`),
  KEY `IX_B_FORUM_PM_POST_DATE` (`POST_DATE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_forum_rank
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_forum_rank`;

CREATE TABLE `b_forum_rank` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `CODE` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `MIN_NUM_POSTS` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_forum_rank_lang
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_forum_rank_lang`;

CREATE TABLE `b_forum_rank_lang` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `RANK_ID` int(11) NOT NULL,
  `LID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `NAME` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UX_FORUM_RANK` (`RANK_ID`,`LID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_forum_smile
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_forum_smile`;

CREATE TABLE `b_forum_smile` (
  `ID` smallint(3) NOT NULL AUTO_INCREMENT,
  `TYPE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'S',
  `TYPING` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `IMAGE` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `DESCRIPTION` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CLICKABLE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `SORT` int(10) NOT NULL DEFAULT '150',
  `IMAGE_WIDTH` int(11) NOT NULL DEFAULT '0',
  `IMAGE_HEIGHT` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `b_forum_smile` WRITE;
/*!40000 ALTER TABLE `b_forum_smile` DISABLE KEYS */;

INSERT INTO `b_forum_smile` (`ID`, `TYPE`, `TYPING`, `IMAGE`, `DESCRIPTION`, `CLICKABLE`, `SORT`, `IMAGE_WIDTH`, `IMAGE_HEIGHT`)
VALUES
	(68,'S',':D :-D','icon_biggrin.png','FICON_BIGGRIN','N',30,16,16),
	(69,'S',':) :-)','icon_smile.png','FICON_SMILE','N',10,16,16),
	(70,'S',':( :-(','icon_sad.png','FICON_SAD','N',50,16,16),
	(71,'S',':o :-o :shock:','icon_eek.png','FICON_EEK','N',90,16,16),
	(72,'S','8) 8-)','icon_cool.png','FICON_COOL','N',40,16,16),
	(73,'S',':{} :-{}','icon_kiss.png','FICON_KISS','N',110,16,16),
	(74,'S',':oops:','icon_redface.png','FICON_REDFACE','Y',100,16,16),
	(75,'S',':cry: :~(','icon_cry.png','FICON_CRY','Y',70,16,16),
	(76,'S',':evil: >:-<','icon_evil.png','FICON_EVIL','N',80,16,16),
	(77,'S',';) ;-)','icon_wink.png','FICON_WINK','N',20,16,16),
	(78,'S',':!:','icon_exclaim.png','FICON_EXCLAIM','Y',130,16,16),
	(79,'S',':?:','icon_question.png','FICON_QUESTION','Y',120,16,16),
	(80,'S',':idea:','icon_idea.png','FICON_IDEA','Y',140,16,16),
	(81,'S',':| :-|','icon_neutral.png','FICON_NEUTRAL','N',60,16,16),
	(82,'S',':\\  :-\\  :/ :-/','icon_confuse.png','FICON_CONFUSE','N',60,16,16),
	(83,'I','','icon1.gif','FICON_NOTE','Y',150,15,15),
	(84,'I','','icon2.gif','FICON_DIRRECTION','Y',150,15,15),
	(85,'I','','icon3.gif','FICON_IDEA2','Y',150,15,15),
	(86,'I','','icon4.gif','FICON_ATTANSION','Y',150,15,15),
	(87,'I','','icon5.gif','FICON_QUESTION2','Y',150,15,15),
	(88,'I','','icon6.gif','FICON_BAD','Y',150,15,15),
	(89,'I','','icon7.gif','FICON_GOOD','Y',150,15,15);

/*!40000 ALTER TABLE `b_forum_smile` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table b_forum_smile_lang
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_forum_smile_lang`;

CREATE TABLE `b_forum_smile_lang` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `SMILE_ID` int(11) NOT NULL,
  `LID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UX_FORUM_SMILE_K` (`SMILE_ID`,`LID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `b_forum_smile_lang` WRITE;
/*!40000 ALTER TABLE `b_forum_smile_lang` DISABLE KEYS */;

INSERT INTO `b_forum_smile_lang` (`ID`, `SMILE_ID`, `LID`, `NAME`)
VALUES
	(1,68,'ru','Широкая улыбка'),
	(2,69,'ru','С улыбкой'),
	(3,70,'ru','Печально'),
	(4,71,'ru','Удивленно'),
	(5,72,'ru','Здорово'),
	(6,73,'ru','Поцелуй'),
	(7,74,'ru','Смущенно'),
	(8,75,'ru','Очень грустно'),
	(9,76,'ru','Со злостью'),
	(10,77,'ru','Шутливо'),
	(11,78,'ru','Восклицание'),
	(12,79,'ru','Вопрос'),
	(13,80,'ru','Идея'),
	(14,81,'ru','Нет слов'),
	(15,82,'ru','Озадаченно'),
	(16,83,'ru','Заметка'),
	(17,84,'ru','Направление'),
	(18,85,'ru','Идея'),
	(19,86,'ru','Внимание'),
	(20,87,'ru','Вопрос'),
	(21,88,'ru','Плохо'),
	(22,89,'ru','Хорошо'),
	(23,68,'en','Big grin'),
	(24,69,'en','Smile'),
	(25,70,'en','Sad'),
	(26,71,'en','Surprised'),
	(27,72,'en','Cool'),
	(28,73,'en','Kiss'),
	(29,74,'en','Embaressed'),
	(30,75,'en','Crying'),
	(31,79,'en','Question'),
	(32,78,'en','Exclamation'),
	(33,77,'en','Wink'),
	(34,76,'en','Angry'),
	(35,80,'en','Idea'),
	(36,81,'en','Speechless'),
	(37,82,'en','Skeptical'),
	(38,83,'en','Note'),
	(39,84,'en','Direction'),
	(40,85,'en','Idea'),
	(41,86,'en','Attention'),
	(42,87,'en','Question'),
	(43,88,'en','Thumbs Down'),
	(44,89,'en','Thumbs Up');

/*!40000 ALTER TABLE `b_forum_smile_lang` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table b_forum_stat
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_forum_stat`;

CREATE TABLE `b_forum_stat` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `USER_ID` int(10) DEFAULT NULL,
  `IP_ADDRESS` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PHPSESSID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LAST_VISIT` datetime DEFAULT NULL,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FORUM_ID` smallint(5) NOT NULL DEFAULT '0',
  `TOPIC_ID` int(10) DEFAULT NULL,
  `SHOW_NAME` varchar(101) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_B_FORUM_STAT_SITE_ID` (`SITE_ID`,`LAST_VISIT`),
  KEY `IX_B_FORUM_STAT_TOPIC_ID` (`TOPIC_ID`,`LAST_VISIT`),
  KEY `IX_B_FORUM_STAT_FORUM_ID` (`FORUM_ID`,`LAST_VISIT`),
  KEY `IX_B_FORUM_STAT_PHPSESSID` (`PHPSESSID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_forum_subscribe
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_forum_subscribe`;

CREATE TABLE `b_forum_subscribe` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `USER_ID` int(10) NOT NULL,
  `FORUM_ID` int(10) NOT NULL,
  `TOPIC_ID` int(10) DEFAULT NULL,
  `START_DATE` datetime NOT NULL,
  `LAST_SEND` int(10) DEFAULT NULL,
  `NEW_TOPIC_ONLY` char(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `SITE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'ru',
  `SOCNET_GROUP_ID` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UX_FORUM_SUBSCRIBE_USER` (`USER_ID`,`FORUM_ID`,`TOPIC_ID`,`SOCNET_GROUP_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_forum_topic
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_forum_topic`;

CREATE TABLE `b_forum_topic` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `FORUM_ID` int(10) NOT NULL,
  `TOPIC_ID` bigint(20) DEFAULT NULL,
  `TITLE` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `TITLE_SEO` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TAGS` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DESCRIPTION` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ICON_ID` tinyint(2) DEFAULT NULL,
  `STATE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `APPROVED` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `SORT` int(10) NOT NULL DEFAULT '150',
  `VIEWS` int(10) NOT NULL DEFAULT '0',
  `USER_START_ID` int(10) DEFAULT NULL,
  `USER_START_NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `START_DATE` datetime NOT NULL,
  `POSTS` int(10) NOT NULL DEFAULT '0',
  `LAST_POSTER_ID` int(10) DEFAULT NULL,
  `LAST_POSTER_NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `LAST_POST_DATE` datetime NOT NULL,
  `LAST_MESSAGE_ID` bigint(20) DEFAULT NULL,
  `POSTS_UNAPPROVED` int(11) DEFAULT '0',
  `ABS_LAST_POSTER_ID` int(10) DEFAULT NULL,
  `ABS_LAST_POSTER_NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ABS_LAST_POST_DATE` datetime DEFAULT NULL,
  `ABS_LAST_MESSAGE_ID` bigint(20) DEFAULT NULL,
  `XML_ID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `HTML` text COLLATE utf8_unicode_ci,
  `SOCNET_GROUP_ID` int(10) DEFAULT NULL,
  `OWNER_ID` int(10) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_FORUM_TOPIC_FORUM` (`FORUM_ID`,`APPROVED`),
  KEY `IX_FORUM_TOPIC_APPROVED` (`APPROVED`),
  KEY `IX_FORUM_TOPIC_ABS_L_POST_DATE` (`ABS_LAST_POST_DATE`),
  KEY `IX_FORUM_TOPIC_LAST_POST_DATE` (`LAST_POST_DATE`),
  KEY `IX_FORUM_TOPIC_USER_START_ID` (`USER_START_ID`),
  KEY `IX_FORUM_TOPIC_DATE_USER_START_ID` (`START_DATE`,`USER_START_ID`),
  KEY `IX_FORUM_TOPIC_XML_ID` (`XML_ID`),
  KEY `IX_FORUM_TOPIC_TITLE_SEO` (`FORUM_ID`,`TITLE_SEO`),
  KEY `IX_FORUM_TOPIC_TITLE_SEO2` (`TITLE_SEO`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_forum_user
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_forum_user`;

CREATE TABLE `b_forum_user` (
  `ID` bigint(10) NOT NULL AUTO_INCREMENT,
  `USER_ID` int(10) NOT NULL,
  `ALIAS` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DESCRIPTION` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `IP_ADDRESS` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `AVATAR` int(10) DEFAULT NULL,
  `NUM_POSTS` int(10) DEFAULT '0',
  `INTERESTS` text COLLATE utf8_unicode_ci,
  `LAST_POST` int(10) DEFAULT NULL,
  `ALLOW_POST` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `LAST_VISIT` datetime NOT NULL,
  `DATE_REG` date NOT NULL,
  `REAL_IP_ADDRESS` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SIGNATURE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SHOW_NAME` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `RANK_ID` int(11) DEFAULT NULL,
  `POINTS` int(11) NOT NULL DEFAULT '0',
  `HIDE_FROM_ONLINE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `SUBSC_GROUP_MESSAGE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `SUBSC_GET_MY_MESSAGE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `IX_FORUM_USER_USER6` (`USER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_forum_user_forum
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_forum_user_forum`;

CREATE TABLE `b_forum_user_forum` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `USER_ID` int(11) DEFAULT NULL,
  `FORUM_ID` int(11) DEFAULT NULL,
  `LAST_VISIT` datetime DEFAULT NULL,
  `MAIN_LAST_VISIT` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_B_FORUM_USER_FORUM_ID1` (`USER_ID`,`FORUM_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_forum_user_points
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_forum_user_points`;

CREATE TABLE `b_forum_user_points` (
  `FROM_USER_ID` int(11) NOT NULL,
  `TO_USER_ID` int(11) NOT NULL,
  `POINTS` int(11) NOT NULL DEFAULT '0',
  `DATE_UPDATE` datetime DEFAULT NULL,
  PRIMARY KEY (`FROM_USER_ID`,`TO_USER_ID`),
  KEY `IX_B_FORUM_USER_POINTS_TO_USER` (`TO_USER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_forum_user_topic
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_forum_user_topic`;

CREATE TABLE `b_forum_user_topic` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `TOPIC_ID` int(11) NOT NULL DEFAULT '0',
  `USER_ID` int(11) NOT NULL DEFAULT '0',
  `FORUM_ID` int(11) DEFAULT NULL,
  `LAST_VISIT` datetime DEFAULT NULL,
  PRIMARY KEY (`TOPIC_ID`,`USER_ID`),
  KEY `ID` (`ID`),
  KEY `IX_B_FORUM_USER_FORUM_ID2` (`USER_ID`,`FORUM_ID`,`TOPIC_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_forum2site
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_forum2site`;

CREATE TABLE `b_forum2site` (
  `FORUM_ID` int(11) NOT NULL,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `PATH2FORUM_MESSAGE` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`FORUM_ID`,`SITE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_group
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_group`;

CREATE TABLE `b_group` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `C_SORT` int(18) NOT NULL DEFAULT '100',
  `ANONYMOUS` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `DESCRIPTION` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SECURITY_POLICY` text COLLATE utf8_unicode_ci,
  `STRING_ID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `b_group` WRITE;
/*!40000 ALTER TABLE `b_group` DISABLE KEYS */;

INSERT INTO `b_group` (`ID`, `TIMESTAMP_X`, `ACTIVE`, `C_SORT`, `ANONYMOUS`, `NAME`, `DESCRIPTION`, `SECURITY_POLICY`, `STRING_ID`)
VALUES
	(1,'2014-07-03 23:56:09','Y',1,'N','Администраторы','Полный доступ к управлению сайтом.',NULL,NULL),
	(2,'2014-07-03 23:56:09','Y',2,'Y','Все пользователи (в том числе неавторизованные)','Все пользователи, включая неавторизованных.',NULL,NULL),
	(3,'2014-07-03 23:56:09','Y',3,'N','Пользователи, имеющие право голосовать за рейтинг','В эту группу пользователи добавляются автоматически.',NULL,'RATING_VOTE'),
	(4,'2014-07-03 23:56:09','Y',4,'N','Пользователи имеющие право голосовать за авторитет','В эту группу пользователи добавляются автоматически.',NULL,'RATING_VOTE_AUTHORITY');

/*!40000 ALTER TABLE `b_group` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table b_group_collection_task
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_group_collection_task`;

CREATE TABLE `b_group_collection_task` (
  `GROUP_ID` int(11) NOT NULL,
  `TASK_ID` int(11) NOT NULL,
  `COLLECTION_ID` int(11) NOT NULL,
  PRIMARY KEY (`GROUP_ID`,`TASK_ID`,`COLLECTION_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_group_subordinate
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_group_subordinate`;

CREATE TABLE `b_group_subordinate` (
  `ID` int(18) NOT NULL,
  `AR_SUBGROUP_ID` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_group_task
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_group_task`;

CREATE TABLE `b_group_task` (
  `GROUP_ID` int(18) NOT NULL,
  `TASK_ID` int(18) NOT NULL,
  `EXTERNAL_ID` varchar(50) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`GROUP_ID`,`TASK_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_hlblock_entity
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_hlblock_entity`;

CREATE TABLE `b_hlblock_entity` (
  `ID` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `NAME` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `TABLE_NAME` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_hot_keys
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_hot_keys`;

CREATE TABLE `b_hot_keys` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `KEYS_STRING` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `CODE_ID` int(18) NOT NULL,
  `USER_ID` int(18) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ix_b_hot_keys_co_u` (`CODE_ID`,`USER_ID`),
  KEY `ix_hot_keys_code` (`CODE_ID`),
  KEY `ix_hot_keys_user` (`USER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `b_hot_keys` WRITE;
/*!40000 ALTER TABLE `b_hot_keys` DISABLE KEYS */;

INSERT INTO `b_hot_keys` (`ID`, `KEYS_STRING`, `CODE_ID`, `USER_ID`)
VALUES
	(1,'Ctrl+Alt+85',139,0),
	(2,'Ctrl+Alt+80',17,0),
	(3,'Ctrl+Alt+70',120,0),
	(4,'Ctrl+Alt+68',117,0),
	(5,'Ctrl+Alt+81',3,0),
	(6,'Ctrl+Alt+75',106,0),
	(7,'Ctrl+Alt+79',133,0),
	(8,'Ctrl+Alt+70',121,0),
	(9,'Ctrl+Alt+69',118,0),
	(10,'Ctrl+Shift+83',87,0),
	(11,'Ctrl+Shift+88',88,0),
	(12,'Ctrl+Shift+76',89,0),
	(13,'Ctrl+Alt+85',139,1),
	(14,'Ctrl+Alt+80',17,1),
	(15,'Ctrl+Alt+70',120,1),
	(16,'Ctrl+Alt+68',117,1),
	(17,'Ctrl+Alt+81',3,1),
	(18,'Ctrl+Alt+75',106,1),
	(19,'Ctrl+Alt+79',133,1),
	(20,'Ctrl+Alt+70',121,1),
	(21,'Ctrl+Alt+69',118,1),
	(22,'Ctrl+Shift+83',87,1),
	(23,'Ctrl+Shift+88',88,1),
	(24,'Ctrl+Shift+76',89,1);

/*!40000 ALTER TABLE `b_hot_keys` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table b_hot_keys_code
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_hot_keys_code`;

CREATE TABLE `b_hot_keys_code` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `CLASS_NAME` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CODE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `COMMENTS` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TITLE_OBJ` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `URL` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `IS_CUSTOM` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`ID`),
  KEY `ix_hot_keys_code_cn` (`CLASS_NAME`),
  KEY `ix_hot_keys_code_url` (`URL`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `b_hot_keys_code` WRITE;
/*!40000 ALTER TABLE `b_hot_keys_code` DISABLE KEYS */;

INSERT INTO `b_hot_keys_code` (`ID`, `CLASS_NAME`, `CODE`, `NAME`, `COMMENTS`, `TITLE_OBJ`, `URL`, `IS_CUSTOM`)
VALUES
	(3,'CAdminTabControl','NextTab();','HK_DB_CADMINTC','HK_DB_CADMINTC_C','tab-container','',0),
	(5,'btn_new','var d=BX (\'btn_new\'); if (d) location.href = d.href;','HK_DB_BUT_ADD','HK_DB_BUT_ADD_C','btn_new','',0),
	(6,'btn_excel','var d=BX(\'btn_excel\'); if (d) location.href = d.href;','HK_DB_BUT_EXL','HK_DB_BUT_EXL_C','btn_excel','',0),
	(7,'btn_settings','var d=BX(\'btn_settings\'); if (d) location.href = d.href;','HK_DB_BUT_OPT','HK_DB_BUT_OPT_C','btn_settings','',0),
	(8,'btn_list','var d=BX(\'btn_list\'); if (d) location.href = d.href;','HK_DB_BUT_LST','HK_DB_BUT_LST_C','btn_list','',0),
	(9,'Edit_Save_Button','var d=BX .findChild(document, {attribute: {\'name\': \'save\'}}, true );  if (d) d.click();','HK_DB_BUT_SAVE','HK_DB_BUT_SAVE_C','Edit_Save_Button','',0),
	(10,'btn_delete','var d=BX(\'btn_delete\'); if (d) location.href = d.href;','HK_DB_BUT_DEL','HK_DB_BUT_DEL_C','btn_delete','',0),
	(12,'CAdminFilter','var d=BX .findChild(document, {attribute: {\'name\': \'find\'}}, true ); if (d) d.focus();','HK_DB_FLT_FND','HK_DB_FLT_FND_C','find','',0),
	(13,'CAdminFilter','var d=BX .findChild(document, {attribute: {\'name\': \'set_filter\'}}, true );  if (d) d.click();','HK_DB_FLT_BUT_F','HK_DB_FLT_BUT_F_C','set_filter','',0),
	(14,'CAdminFilter','var d=BX .findChild(document, {attribute: {\'name\': \'del_filter\'}}, true );  if (d) d.click();','HK_DB_FLT_BUT_CNL','HK_DB_FLT_BUT_CNL_C','del_filter','',0),
	(15,'bx-panel-admin-button-help-icon-id','var d=BX(\'bx-panel-admin-button-help-icon-id\'); if (d) location.href = d.href;','HK_DB_BUT_HLP','HK_DB_BUT_HLP_C','bx-panel-admin-button-help-icon-id','',0),
	(17,'Global','BXHotKeys.ShowSettings();','HK_DB_SHW_L','HK_DB_SHW_L_C','bx-panel-hotkeys','',0),
	(19,'Edit_Apply_Button','var d=BX .findChild(document, {attribute: {\'name\': \'apply\'}}, true );  if (d) d.click();','HK_DB_BUT_APPL','HK_DB_BUT_APPL_C','Edit_Apply_Button','',0),
	(20,'Edit_Cancel_Button','var d=BX .findChild(document, {attribute: {\'name\': \'cancel\'}}, true );  if (d) d.click();','HK_DB_BUT_CANCEL','HK_DB_BUT_CANCEL_C','Edit_Cancel_Button','',0),
	(54,'top_panel_org_fav','','-=AUTONAME=-',NULL,'top_panel_org_fav',NULL,0),
	(55,'top_panel_module_settings','','-=AUTONAME=-',NULL,'top_panel_module_settings','',0),
	(56,'top_panel_interface_settings','','-=AUTONAME=-',NULL,'top_panel_interface_settings','',0),
	(57,'top_panel_help','','-=AUTONAME=-',NULL,'top_panel_help','',0),
	(58,'top_panel_bizproc_tasks','','-=AUTONAME=-',NULL,'top_panel_bizproc_tasks','',0),
	(59,'top_panel_add_fav','','-=AUTONAME=-',NULL,'top_panel_add_fav',NULL,0),
	(60,'top_panel_create_page','','-=AUTONAME=-',NULL,'top_panel_create_page','',0),
	(62,'top_panel_create_folder','','-=AUTONAME=-',NULL,'top_panel_create_folder','',0),
	(63,'top_panel_edit_page','','-=AUTONAME=-',NULL,'top_panel_edit_page','',0),
	(64,'top_panel_page_prop','','-=AUTONAME=-',NULL,'top_panel_page_prop','',0),
	(65,'top_panel_edit_page_html','','-=AUTONAME=-',NULL,'top_panel_edit_page_html','',0),
	(67,'top_panel_edit_page_php','','-=AUTONAME=-',NULL,'top_panel_edit_page_php','',0),
	(68,'top_panel_del_page','','-=AUTONAME=-',NULL,'top_panel_del_page','',0),
	(69,'top_panel_folder_prop','','-=AUTONAME=-',NULL,'top_panel_folder_prop','',0),
	(70,'top_panel_access_folder_new','','-=AUTONAME=-',NULL,'top_panel_access_folder_new','',0),
	(71,'main_top_panel_struct_panel','','-=AUTONAME=-',NULL,'main_top_panel_struct_panel','',0),
	(72,'top_panel_cache_page','','-=AUTONAME=-',NULL,'top_panel_cache_page','',0),
	(73,'top_panel_cache_comp','','-=AUTONAME=-',NULL,'top_panel_cache_comp','',0),
	(74,'top_panel_cache_not','','-=AUTONAME=-',NULL,'top_panel_cache_not','',0),
	(75,'top_panel_edit_mode','','-=AUTONAME=-',NULL,'top_panel_edit_mode','',0),
	(76,'top_panel_templ_site_css','','-=AUTONAME=-',NULL,'top_panel_templ_site_css','',0),
	(77,'top_panel_templ_templ_css','','-=AUTONAME=-',NULL,'top_panel_templ_templ_css','',0),
	(78,'top_panel_templ_site','','-=AUTONAME=-',NULL,'top_panel_templ_site','',0),
	(81,'top_panel_debug_time','','-=AUTONAME=-',NULL,'top_panel_debug_time','',0),
	(82,'top_panel_debug_incl','','-=AUTONAME=-',NULL,'top_panel_debug_incl','',0),
	(83,'top_panel_debug_sql','','-=AUTONAME=-',NULL,'top_panel_debug_sql',NULL,0),
	(84,'top_panel_debug_compr','','-=AUTONAME=-',NULL,'top_panel_debug_compr','',0),
	(85,'MTP_SHORT_URI1','','-=AUTONAME=-',NULL,'MTP_SHORT_URI1','',0),
	(86,'MTP_SHORT_URI_LIST','','-=AUTONAME=-',NULL,'MTP_SHORT_URI_LIST','',0),
	(87,'FMST_PANEL_STICKER_ADD','','-=AUTONAME=-',NULL,'FMST_PANEL_STICKER_ADD','',0),
	(88,'FMST_PANEL_STICKERS_SHOW','','-=AUTONAME=-',NULL,'FMST_PANEL_STICKERS_SHOW','',0),
	(89,'FMST_PANEL_CUR_STICKER_LIST','','-=AUTONAME=-',NULL,'FMST_PANEL_CUR_STICKER_LIST','',0),
	(90,'FMST_PANEL_ALL_STICKER_LIST','','-=AUTONAME=-',NULL,'FMST_PANEL_ALL_STICKER_LIST','',0),
	(91,'top_panel_menu','var d=BX(\"bx-panel-menu\"); if (d) d.click();','-=AUTONAME=-',NULL,'bx-panel-menu','',0),
	(92,'top_panel_admin','var d=BX(\'bx-panel-admin-tab\'); if (d) location.href = d.href;','-=AUTONAME=-',NULL,'bx-panel-admin-tab','',0),
	(93,'admin_panel_site','var d=BX(\'bx-panel-view-tab\'); if (d) location.href = d.href;','-=AUTONAME=-',NULL,'bx-panel-view-tab','',0),
	(94,'admin_panel_admin','var d=BX(\'bx-panel-admin-tab\'); if (d) location.href = d.href;','-=AUTONAME=-',NULL,'bx-panel-admin-tab','',0),
	(96,'top_panel_folder_prop_new','','-=AUTONAME=-',NULL,'top_panel_folder_prop_new','',0),
	(97,'main_top_panel_structure','','-=AUTONAME=-',NULL,'main_top_panel_structure','',0),
	(98,'top_panel_clear_cache','','-=AUTONAME=-',NULL,'top_panel_clear_cache','',0),
	(99,'top_panel_templ','','-=AUTONAME=-',NULL,'top_panel_templ','',0),
	(100,'top_panel_debug','','-=AUTONAME=-',NULL,'top_panel_debug','',0),
	(101,'MTP_SHORT_URI','','-=AUTONAME=-',NULL,'MTP_SHORT_URI','',0),
	(102,'FMST_PANEL_STICKERS','','-=AUTONAME=-',NULL,'FMST_PANEL_STICKERS','',0),
	(103,'top_panel_settings','','-=AUTONAME=-',NULL,'top_panel_settings','',0),
	(104,'top_panel_fav','','-=AUTONAME=-',NULL,'top_panel_fav','',0),
	(106,'Global','location.href=\'/bitrix/admin/hot_keys_list.php?lang=ru\';','HK_DB_SHW_HK','','','',0),
	(107,'top_panel_edit_new','','-=AUTONAME=-',NULL,'top_panel_edit_new','',0),
	(108,'FLOW_PANEL_CREATE_WITH_WF','','-=AUTONAME=-',NULL,'FLOW_PANEL_CREATE_WITH_WF','',0),
	(109,'FLOW_PANEL_EDIT_WITH_WF','','-=AUTONAME=-',NULL,'FLOW_PANEL_EDIT_WITH_WF','',0),
	(110,'FLOW_PANEL_HISTORY','','-=AUTONAME=-',NULL,'FLOW_PANEL_HISTORY','',0),
	(111,'top_panel_create_new','','-=AUTONAME=-',NULL,'top_panel_create_new','',0),
	(112,'top_panel_create_folder_new','','-=AUTONAME=-',NULL,'top_panel_create_folder_new','',0),
	(116,'bx-panel-toggle','','-=AUTONAME=-',NULL,'bx-panel-toggle','',0),
	(117,'bx-panel-small-toggle','','-=AUTONAME=-',NULL,'bx-panel-small-toggle','',0),
	(118,'bx-panel-expander','var d=BX(\'bx-panel-expander\'); if (d) BX.fireEvent(d, \'click\');','-=AUTONAME=-',NULL,'bx-panel-expander','',0),
	(119,'bx-panel-hider','var d=BX(\'bx-panel-hider\'); if (d) d.click();','-=AUTONAME=-',NULL,'bx-panel-hider','',0),
	(120,'search-textbox-input','var d=BX(\'search-textbox-input\'); if (d) { d.click(); d.focus();}','-=AUTONAME=-','','search','',0),
	(121,'bx-search-input','var d=BX(\'bx-search-input\'); if (d) { d.click(); d.focus(); }','-=AUTONAME=-','','bx-search-input','',0),
	(133,'bx-panel-logout','var d=BX(\'bx-panel-logout\'); if (d) location.href = d.href;','-=AUTONAME=-','','bx-panel-logout','',0),
	(135,'CDialog','var d=BX(\'cancel\'); if (d) d.click();','HK_DB_D_CANCEL','','cancel','',0),
	(136,'CDialog','var d=BX(\'close\'); if (d) d.click();','HK_DB_D_CLOSE','','close','',0),
	(137,'CDialog','var d=BX(\'savebtn\'); if (d) d.click();','HK_DB_D_SAVE','','savebtn','',0),
	(138,'CDialog','var d=BX(\'btn_popup_save\'); if (d) d.click();','HK_DB_D_EDIT_SAVE','','btn_popup_save','',0),
	(139,'Global','location.href=\'/bitrix/admin/user_admin.php?lang=\'+phpVars.LANGUAGE_ID;','HK_DB_SHW_U','','','',0);

/*!40000 ALTER TABLE `b_hot_keys_code` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table b_iblock
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_iblock`;

CREATE TABLE `b_iblock` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `IBLOCK_TYPE_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `LID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `CODE` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `SORT` int(11) NOT NULL DEFAULT '500',
  `LIST_PAGE_URL` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DETAIL_PAGE_URL` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SECTION_PAGE_URL` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PICTURE` int(18) DEFAULT NULL,
  `DESCRIPTION` text COLLATE utf8_unicode_ci,
  `DESCRIPTION_TYPE` char(4) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'text',
  `RSS_TTL` int(11) NOT NULL DEFAULT '24',
  `RSS_ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `RSS_FILE_ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `RSS_FILE_LIMIT` int(11) DEFAULT NULL,
  `RSS_FILE_DAYS` int(11) DEFAULT NULL,
  `RSS_YANDEX_ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `XML_ID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TMP_ID` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `INDEX_ELEMENT` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `INDEX_SECTION` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `WORKFLOW` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `BIZPROC` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `SECTION_CHOOSER` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LIST_MODE` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `RIGHTS_MODE` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SECTION_PROPERTY` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `VERSION` int(11) NOT NULL DEFAULT '1',
  `LAST_CONV_ELEMENT` int(11) NOT NULL DEFAULT '0',
  `SOCNET_GROUP_ID` int(18) DEFAULT NULL,
  `EDIT_FILE_BEFORE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `EDIT_FILE_AFTER` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SECTIONS_NAME` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SECTION_NAME` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ELEMENTS_NAME` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ELEMENT_NAME` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ix_iblock` (`IBLOCK_TYPE_ID`,`LID`,`ACTIVE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `b_iblock` WRITE;
/*!40000 ALTER TABLE `b_iblock` DISABLE KEYS */;

INSERT INTO `b_iblock` (`ID`, `TIMESTAMP_X`, `IBLOCK_TYPE_ID`, `LID`, `CODE`, `NAME`, `ACTIVE`, `SORT`, `LIST_PAGE_URL`, `DETAIL_PAGE_URL`, `SECTION_PAGE_URL`, `PICTURE`, `DESCRIPTION`, `DESCRIPTION_TYPE`, `RSS_TTL`, `RSS_ACTIVE`, `RSS_FILE_ACTIVE`, `RSS_FILE_LIMIT`, `RSS_FILE_DAYS`, `RSS_YANDEX_ACTIVE`, `XML_ID`, `TMP_ID`, `INDEX_ELEMENT`, `INDEX_SECTION`, `WORKFLOW`, `BIZPROC`, `SECTION_CHOOSER`, `LIST_MODE`, `RIGHTS_MODE`, `SECTION_PROPERTY`, `VERSION`, `LAST_CONV_ELEMENT`, `SOCNET_GROUP_ID`, `EDIT_FILE_BEFORE`, `EDIT_FILE_AFTER`, `SECTIONS_NAME`, `SECTION_NAME`, `ELEMENTS_NAME`, `ELEMENT_NAME`)
VALUES
	(1,'2014-07-04 00:28:18','events','s1','events','События','Y',500,'#SITE_DIR#/events/index.php?ID=#IBLOCK_ID#','#SITE_DIR#/events/detail.php?ID=#ELEMENT_ID#','#SITE_DIR#/events/list.php?SECTION_ID=#SECTION_ID#',NULL,'','text',24,'Y','N',NULL,NULL,'N',NULL,NULL,'Y','Y','N','N','L','C','S','N',1,0,NULL,'','','Разделы','Раздел','Элементы','Элемент'),
	(2,'2014-07-04 00:28:59','events','s1','speakers','Спикеры','Y',500,'#SITE_DIR#/events/index.php?ID=#IBLOCK_ID#','#SITE_DIR#/events/detail.php?ID=#ELEMENT_ID#','#SITE_DIR#/events/list.php?SECTION_ID=#SECTION_ID#',NULL,'','text',24,'Y','N',NULL,NULL,'N',NULL,NULL,'Y','Y','N','N','L','C','S','N',1,0,NULL,'','','Разделы','Раздел','Элементы','Элемент'),
	(3,'2014-07-04 00:31:09','events','s1','citys','Города','Y',500,'#SITE_DIR#/events/index.php?ID=#IBLOCK_ID#','#SITE_DIR#/events/detail.php?ID=#ELEMENT_ID#','#SITE_DIR#/events/list.php?SECTION_ID=#SECTION_ID#',NULL,'','text',24,'Y','N',NULL,NULL,'N',NULL,NULL,'Y','Y','N','N','L','C','S','N',1,0,NULL,'','','Разделы','Раздел','Элементы','Элемент'),
	(4,'2014-07-04 00:39:28','events','s1','types','Типы мероприятий','Y',500,'#SITE_DIR#/events/index.php?ID=#IBLOCK_ID#','#SITE_DIR#/events/detail.php?ID=#ELEMENT_ID#','#SITE_DIR#/events/list.php?SECTION_ID=#SECTION_ID#',NULL,'','text',24,'Y','N',NULL,NULL,'N',NULL,NULL,'Y','Y','N','N','L','C','S','N',1,0,NULL,'','','Разделы','Раздел','Элементы','Элемент'),
	(5,'2014-07-04 00:56:28','events','s1','direction','Направление','Y',500,'#SITE_DIR#/events/index.php?ID=#IBLOCK_ID#','#SITE_DIR#/events/detail.php?ID=#ELEMENT_ID#','#SITE_DIR#/events/list.php?SECTION_ID=#SECTION_ID#',NULL,'','text',24,'Y','N',NULL,NULL,'N',NULL,NULL,'Y','Y','N','N','L','C','S','N',1,0,NULL,'','','Разделы','Раздел','Элементы','Элемент'),
	(6,'2014-07-04 01:39:18','events','s1','partners','Партнеры','Y',500,'#SITE_DIR#/events/index.php?ID=#IBLOCK_ID#','#SITE_DIR#/events/detail.php?ID=#ELEMENT_ID#','#SITE_DIR#/events/list.php?SECTION_ID=#SECTION_ID#',NULL,'','text',24,'Y','N',NULL,NULL,'N',NULL,NULL,'Y','Y','N','N','L','C','S',NULL,1,0,NULL,'','','Разделы','Раздел','Элементы','Элемент'),
	(7,'2014-07-07 02:35:52','content','s1','career','Направления карьеры','Y',500,'#SITE_DIR#/content/index.php?ID=#IBLOCK_ID#','#SITE_DIR#/content/detail.php?ID=#ELEMENT_ID#','#SITE_DIR#/content/list.php?SECTION_ID=#SECTION_ID#',NULL,'','text',24,'Y','N',NULL,NULL,'N',NULL,NULL,'Y','Y','N','N','L','','S',NULL,1,0,NULL,'','','Разделы','Раздел','Элементы','Элемент'),
	(8,'2014-07-08 13:05:38','content','s1','vacancy','Вакансии','Y',500,'#SITE_DIR#/content/index.php?ID=#IBLOCK_ID#','#SITE_DIR#/content/detail.php?ID=#ELEMENT_ID#','#SITE_DIR#/content/list.php?SECTION_ID=#SECTION_ID#',NULL,'','text',24,'Y','N',NULL,NULL,'N',NULL,NULL,'Y','Y','N','N','L','','S',NULL,1,0,NULL,'','','Разделы','Раздел','Элементы','Элемент');

/*!40000 ALTER TABLE `b_iblock` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table b_iblock_cache
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_iblock_cache`;

CREATE TABLE `b_iblock_cache` (
  `CACHE_KEY` varchar(35) COLLATE utf8_unicode_ci NOT NULL,
  `CACHE` longtext COLLATE utf8_unicode_ci NOT NULL,
  `CACHE_DATE` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`CACHE_KEY`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_iblock_element
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_iblock_element`;

CREATE TABLE `b_iblock_element` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `TIMESTAMP_X` datetime DEFAULT NULL,
  `MODIFIED_BY` int(18) DEFAULT NULL,
  `DATE_CREATE` datetime DEFAULT NULL,
  `CREATED_BY` int(18) DEFAULT NULL,
  `IBLOCK_ID` int(11) NOT NULL DEFAULT '0',
  `IBLOCK_SECTION_ID` int(11) DEFAULT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `ACTIVE_FROM` datetime DEFAULT NULL,
  `ACTIVE_TO` datetime DEFAULT NULL,
  `SORT` int(11) NOT NULL DEFAULT '500',
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `PREVIEW_PICTURE` int(18) DEFAULT NULL,
  `PREVIEW_TEXT` text COLLATE utf8_unicode_ci,
  `PREVIEW_TEXT_TYPE` varchar(4) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'text',
  `DETAIL_PICTURE` int(18) DEFAULT NULL,
  `DETAIL_TEXT` longtext COLLATE utf8_unicode_ci,
  `DETAIL_TEXT_TYPE` varchar(4) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'text',
  `SEARCHABLE_CONTENT` text COLLATE utf8_unicode_ci,
  `WF_STATUS_ID` int(18) DEFAULT '1',
  `WF_PARENT_ELEMENT_ID` int(11) DEFAULT NULL,
  `WF_NEW` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `WF_LOCKED_BY` int(18) DEFAULT NULL,
  `WF_DATE_LOCK` datetime DEFAULT NULL,
  `WF_COMMENTS` text COLLATE utf8_unicode_ci,
  `IN_SECTIONS` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `XML_ID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CODE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TAGS` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TMP_ID` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `WF_LAST_HISTORY_ID` int(11) DEFAULT NULL,
  `SHOW_COUNTER` int(18) DEFAULT NULL,
  `SHOW_COUNTER_START` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ix_iblock_element_1` (`IBLOCK_ID`,`IBLOCK_SECTION_ID`),
  KEY `ix_iblock_element_4` (`IBLOCK_ID`,`XML_ID`,`WF_PARENT_ELEMENT_ID`),
  KEY `ix_iblock_element_3` (`WF_PARENT_ELEMENT_ID`),
  KEY `ix_iblock_element_code` (`IBLOCK_ID`,`CODE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `b_iblock_element` WRITE;
/*!40000 ALTER TABLE `b_iblock_element` DISABLE KEYS */;

INSERT INTO `b_iblock_element` (`ID`, `TIMESTAMP_X`, `MODIFIED_BY`, `DATE_CREATE`, `CREATED_BY`, `IBLOCK_ID`, `IBLOCK_SECTION_ID`, `ACTIVE`, `ACTIVE_FROM`, `ACTIVE_TO`, `SORT`, `NAME`, `PREVIEW_PICTURE`, `PREVIEW_TEXT`, `PREVIEW_TEXT_TYPE`, `DETAIL_PICTURE`, `DETAIL_TEXT`, `DETAIL_TEXT_TYPE`, `SEARCHABLE_CONTENT`, `WF_STATUS_ID`, `WF_PARENT_ELEMENT_ID`, `WF_NEW`, `WF_LOCKED_BY`, `WF_DATE_LOCK`, `WF_COMMENTS`, `IN_SECTIONS`, `XML_ID`, `CODE`, `TAGS`, `TMP_ID`, `WF_LAST_HISTORY_ID`, `SHOW_COUNTER`, `SHOW_COUNTER_START`)
VALUES
	(1,'2014-07-04 01:33:57',1,'2014-07-04 01:33:57',1,4,NULL,'Y',NULL,NULL,500,'Мастер-класс',NULL,'','text',NULL,'','text','МАСТЕР-КЛАСС\r\n\r\n',1,NULL,NULL,NULL,NULL,NULL,'N','1','master-сlass','','0',NULL,NULL,NULL),
	(2,'2014-07-04 01:34:25',1,'2014-07-04 01:34:25',1,4,NULL,'Y',NULL,NULL,500,'Семинар',NULL,'','text',NULL,'','text','СЕМИНАР\r\n\r\n',1,NULL,NULL,NULL,NULL,NULL,'N','2','seminar','','0',NULL,NULL,NULL),
	(3,'2014-07-04 01:34:52',1,'2014-07-04 01:34:52',1,4,NULL,'Y',NULL,NULL,500,'Курс тренингов',NULL,'','text',NULL,'','text','КУРС ТРЕНИНГОВ\r\n\r\n',1,NULL,NULL,NULL,NULL,NULL,'N','3','training-course','','0',NULL,NULL,NULL),
	(4,'2014-07-04 01:35:29',1,'2014-07-04 01:35:29',1,4,NULL,'Y',NULL,NULL,500,'Вебинар',NULL,'','text',NULL,'','text','ВЕБИНАР\r\n\r\n',1,NULL,NULL,NULL,NULL,NULL,'N','4','webinar','','0',NULL,NULL,NULL),
	(5,'2014-07-04 01:35:54',1,'2014-07-04 01:35:54',1,4,NULL,'Y',NULL,NULL,500,'Третинг',NULL,'','text',NULL,'','text','ТРЕТИНГ\r\n\r\n',1,NULL,NULL,NULL,NULL,NULL,'N','5','training','','0',NULL,NULL,NULL),
	(6,'2014-07-04 01:36:39',1,'2014-07-04 01:36:39',1,4,NULL,'Y',NULL,NULL,500,'Конференция',NULL,'','text',NULL,'','text','КОНФЕРЕНЦИЯ\r\n\r\n',1,NULL,NULL,NULL,NULL,NULL,'N','6','conference','','0',NULL,NULL,NULL),
	(7,'2014-07-18 17:13:28',1,'2014-07-08 19:24:02',1,7,NULL,'Y',NULL,NULL,500,'Leadreship Development Program',17,'Leadership Development Program - программа развития, которая помогает талантливым сотрудникам становиться настоящими лидерами бизнеса. Программа длится от 2 до 4 лет. Вас ждет уникальный опыт работы в международных проектах, командировки и тренинги, общение с топ-менеджерами компании. Раскройте свой потенциал и станьте руководителем в Mars!','text',NULL,'','text','LEADRESHIP DEVELOPMENT PROGRAM\r\nLEADERSHIP DEVELOPMENT PROGRAM - ПРОГРАММА РАЗВИТИЯ, КОТОРАЯ ПОМОГАЕТ ТАЛАНТЛИВЫМ СОТРУДНИКАМ СТАНОВИТЬСЯ НАСТОЯЩИМИ ЛИДЕРАМИ БИЗНЕСА. ПРОГРАММА ДЛИТСЯ ОТ 2 ДО 4 ЛЕТ. ВАС ЖДЕТ УНИКАЛЬНЫЙ ОПЫТ РАБОТЫ В МЕЖДУНАРОДНЫХ ПРОЕКТАХ, КОМАНДИРОВКИ И ТРЕНИНГИ, ОБЩЕНИЕ С ТОП-МЕНЕДЖЕРАМИ КОМПАНИИ. РАСКРОЙТЕ СВОЙ ПОТЕНЦИАЛ И СТАНЬТЕ РУКОВОДИТЕЛЕМ В MARS!\r\n',1,NULL,NULL,NULL,NULL,NULL,'N','7','leadership','','0',NULL,NULL,NULL),
	(8,'2014-07-18 17:22:48',1,'2014-07-10 12:23:42',1,7,NULL,'Y',NULL,NULL,500,'Mars internship program',19,'Mars Internship Program – это не просто возможность испытать на практике полученные во время учебы знания, это шанс стать частью легендарной команды профессионалов Mars. Хотите глубже познакомиться с выбранной профессией, попробовать себя в решении реальных бизнес-задач и получить массу полезных практических навыков за одно лето? В Mars ваши возможности почти безграничны.','text',NULL,'','text','MARS INTERNSHIP PROGRAM\r\nMARS INTERNSHIP PROGRAM – ЭТО НЕ ПРОСТО ВОЗМОЖНОСТЬ ИСПЫТАТЬ НА ПРАКТИКЕ ПОЛУЧЕННЫЕ ВО ВРЕМЯ УЧЕБЫ ЗНАНИЯ, ЭТО ШАНС СТАТЬ ЧАСТЬЮ ЛЕГЕНДАРНОЙ КОМАНДЫ ПРОФЕССИОНАЛОВ MARS. ХОТИТЕ ГЛУБЖЕ ПОЗНАКОМИТЬСЯ С ВЫБРАННОЙ ПРОФЕССИЕЙ, ПОПРОБОВАТЬ СЕБЯ В РЕШЕНИИ РЕАЛЬНЫХ БИЗНЕС-ЗАДАЧ И ПОЛУЧИТЬ МАССУ ПОЛЕЗНЫХ ПРАКТИЧЕСКИХ НАВЫКОВ ЗА ОДНО ЛЕТО? В MARS ВАШИ ВОЗМОЖНОСТИ ПОЧТИ БЕЗГРАНИЧНЫ.\r\n',1,NULL,NULL,NULL,NULL,NULL,'N','8','internship','','0',NULL,NULL,NULL),
	(10,'2014-07-11 10:55:39',1,'2014-07-11 10:55:39',1,8,NULL,'Y',NULL,NULL,500,'Стажер в отдел товарного обеспечения (Ульяновск)',NULL,'','text',NULL,'','text','СТАЖЕР В ОТДЕЛ ТОВАРНОГО ОБЕСПЕЧЕНИЯ (УЛЬЯНОВСК)\r\n\r\n',1,NULL,NULL,NULL,NULL,NULL,'N','10','','','0',NULL,NULL,NULL),
	(11,'2014-07-18 16:50:53',1,'2014-07-11 16:14:24',1,5,NULL,'Y',NULL,NULL,500,'Маркетинг и продажи',13,'Тебя интересует, как запустить новый продукт и организовать его движение от фабрики до полок магазинов? Как построить правильную коммуникацию с потребителем и сделать бренд сильным и уникальным? Секретами маркетинга и продаж с тобой поделятся профессионалы Mars, работающие с такими звёздами как SNICKERS®, M&M’S®, PEDIGREE®, ORBIT®. Не упусти шанс узнать подробности на лекциях и мастер-классах направления «Маркетинг и Продажи».','text',NULL,'','text','МАРКЕТИНГ И ПРОДАЖИ\r\nТЕБЯ ИНТЕРЕСУЕТ, КАК ЗАПУСТИТЬ НОВЫЙ ПРОДУКТ И ОРГАНИЗОВАТЬ ЕГО ДВИЖЕНИЕ ОТ ФАБРИКИ ДО ПОЛОК МАГАЗИНОВ? КАК ПОСТРОИТЬ ПРАВИЛЬНУЮ КОММУНИКАЦИЮ С ПОТРЕБИТЕЛЕМ И СДЕЛАТЬ БРЕНД СИЛЬНЫМ И УНИКАЛЬНЫМ? СЕКРЕТАМИ МАРКЕТИНГА И ПРОДАЖ С ТОБОЙ ПОДЕЛЯТСЯ ПРОФЕССИОНАЛЫ MARS, РАБОТАЮЩИЕ С ТАКИМИ ЗВЁЗДАМИ КАК SNICKERS®, M&M’S®, PEDIGREE®, ORBIT®. НЕ УПУСТИ ШАНС УЗНАТЬ ПОДРОБНОСТИ НА ЛЕКЦИЯХ И МАСТЕР-КЛАССАХ НАПРАВЛЕНИЯ «МАРКЕТИНГ И ПРОДАЖИ».\r\n',1,NULL,NULL,NULL,NULL,NULL,'N','11','marketing','','0',NULL,NULL,NULL),
	(12,'2014-07-18 16:54:29',1,'2014-07-11 16:24:11',1,5,NULL,'Y',NULL,NULL,500,'Финансы и закупки',14,'Все, что ты хотел знать о финансах и закупках, но не знал, у кого спросить! Как организованы финансовые потоки в международной корпорации и как устроена система закупок? Как Mars адаптируется к финансовым особенностям локальных рынков? За что любят и ненавидят финансистов, уважают и боятся специалистов отдела закупок? Самое увлекательное и полезное о столпах FMCG-индустрии — из первых рук!','text',NULL,'','text','ФИНАНСЫ И ЗАКУПКИ\r\nВСЕ, ЧТО ТЫ ХОТЕЛ ЗНАТЬ О ФИНАНСАХ И ЗАКУПКАХ, НО НЕ ЗНАЛ, У КОГО СПРОСИТЬ! КАК ОРГАНИЗОВАНЫ ФИНАНСОВЫЕ ПОТОКИ В МЕЖДУНАРОДНОЙ КОРПОРАЦИИ И КАК УСТРОЕНА СИСТЕМА ЗАКУПОК? КАК MARS АДАПТИРУЕТСЯ К ФИНАНСОВЫМ ОСОБЕННОСТЯМ ЛОКАЛЬНЫХ РЫНКОВ? ЗА ЧТО ЛЮБЯТ И НЕНАВИДЯТ ФИНАНСИСТОВ, УВАЖАЮТ И БОЯТСЯ СПЕЦИАЛИСТОВ ОТДЕЛА ЗАКУПОК? САМОЕ УВЛЕКАТЕЛЬНОЕ И ПОЛЕЗНОЕ О СТОЛПАХ FMCG-ИНДУСТРИИ — ИЗ ПЕРВЫХ РУК!\r\n',1,NULL,NULL,NULL,NULL,NULL,'N','12','finans','','0',NULL,NULL,NULL),
	(13,'2014-07-18 17:01:50',1,'2014-07-11 16:38:01',1,5,NULL,'Y',NULL,NULL,500,'Технологии и производство',15,'Ты узнаешь, как устроено эффективное производство и как глобальные стандарты работают на локальных рынках. Какие технологии использует Mars и почему так много внимания уделяется научным разработкам. Все этапы технологического процесса, от исследований до готового продукта — ни один нюанс не укроется от тебя благодаря захватывающим лекциям и мастер-классам специалистов Mars.','text',NULL,'','text','ТЕХНОЛОГИИ И ПРОИЗВОДСТВО\r\nТЫ УЗНАЕШЬ, КАК УСТРОЕНО ЭФФЕКТИВНОЕ ПРОИЗВОДСТВО И КАК ГЛОБАЛЬНЫЕ СТАНДАРТЫ РАБОТАЮТ НА ЛОКАЛЬНЫХ РЫНКАХ. КАКИЕ ТЕХНОЛОГИИ ИСПОЛЬЗУЕТ MARS И ПОЧЕМУ ТАК МНОГО ВНИМАНИЯ УДЕЛЯЕТСЯ НАУЧНЫМ РАЗРАБОТКАМ. ВСЕ ЭТАПЫ ТЕХНОЛОГИЧЕСКОГО ПРОЦЕССА, ОТ ИССЛЕДОВАНИЙ ДО ГОТОВОГО ПРОДУКТА — НИ ОДИН НЮАНС НЕ УКРОЕТСЯ ОТ ТЕБЯ БЛАГОДАРЯ ЗАХВАТЫВАЮЩИМ ЛЕКЦИЯМ И МАСТЕР-КЛАССАМ СПЕЦИАЛИСТОВ MARS.\r\n',1,NULL,NULL,NULL,NULL,NULL,'N','13','tech','','0',NULL,NULL,NULL),
	(14,'2014-07-12 15:38:13',1,'2014-07-11 17:04:44',1,5,NULL,'Y',NULL,NULL,500,'Развитие лидерства',11,'Компания Mars стала одним из гигантов глобального FMCG-рынка во многом благодаря своим лидерам, которых готовит не первое десятилетие. Как ставить прорывные цели, которые органично вплетаются в жизнь компании? Как создать эффективную команду, живущую одним делом?\r\nБыть лидером — это искусство и опыт, которым мы готовы поделиться на лекциях в рамках направления «Развитие лидерства».','text',NULL,'','text','РАЗВИТИЕ ЛИДЕРСТВА\r\nКОМПАНИЯ MARS СТАЛА ОДНИМ ИЗ ГИГАНТОВ ГЛОБАЛЬНОГО FMCG-РЫНКА ВО МНОГОМ БЛАГОДАРЯ СВОИМ ЛИДЕРАМ, КОТОРЫХ ГОТОВИТ НЕ ПЕРВОЕ ДЕСЯТИЛЕТИЕ. КАК СТАВИТЬ ПРОРЫВНЫЕ ЦЕЛИ, КОТОРЫЕ ОРГАНИЧНО ВПЛЕТАЮТСЯ В ЖИЗНЬ КОМПАНИИ? КАК СОЗДАТЬ ЭФФЕКТИВНУЮ КОМАНДУ, ЖИВУЩУЮ ОДНИМ ДЕЛОМ?\r\nБЫТЬ ЛИДЕРОМ — ЭТО ИСКУССТВО И ОПЫТ, КОТОРЫМ МЫ ГОТОВЫ ПОДЕЛИТЬСЯ НА ЛЕКЦИЯХ В РАМКАХ НАПРАВЛЕНИЯ «РАЗВИТИЕ ЛИДЕРСТВА».\r\n',1,NULL,NULL,NULL,NULL,NULL,'N','14','razvitie-liderstva','','0',NULL,NULL,NULL),
	(15,'2014-07-12 13:36:24',1,'2014-07-12 13:36:24',1,3,NULL,'Y',NULL,NULL,500,'Онлайн',NULL,'','text',NULL,'','text','ОНЛАЙН\r\n\r\n',1,NULL,NULL,NULL,NULL,NULL,'N','15','online','','0',NULL,NULL,NULL),
	(16,'2014-07-12 13:36:39',1,'2014-07-12 13:36:39',1,3,NULL,'Y',NULL,NULL,500,'Москва',NULL,'','text',NULL,'','text','МОСКВА\r\n\r\n',1,NULL,NULL,NULL,NULL,NULL,'N','16','moscow','','0',NULL,NULL,NULL),
	(17,'2014-07-12 13:37:15',1,'2014-07-12 13:37:15',1,3,NULL,'Y',NULL,NULL,500,'Санкт-Петербург',NULL,'','text',NULL,'','text','САНКТ-ПЕТЕРБУРГ\r\n\r\n',1,NULL,NULL,NULL,NULL,NULL,'N','17','petersburg','','0',NULL,NULL,NULL),
	(18,'2014-07-12 13:38:02',1,'2014-07-12 13:38:02',1,3,NULL,'Y',NULL,NULL,500,'Иркутск',NULL,'','text',NULL,'','text','ИРКУТСК\r\n\r\n',1,NULL,NULL,NULL,NULL,NULL,'N','18','irkutsk','','0',NULL,NULL,NULL),
	(19,'2014-07-12 13:38:38',1,'2014-07-12 13:38:38',1,3,NULL,'Y',NULL,NULL,500,'Краснодар',NULL,'','text',NULL,'','text','КРАСНОДАР\r\n\r\n',1,NULL,NULL,NULL,NULL,NULL,'N','19','krasnodar','','0',NULL,NULL,NULL),
	(20,'2014-07-12 13:38:58',1,'2014-07-12 13:38:58',1,3,NULL,'Y',NULL,NULL,500,'Новосибирск',NULL,'','text',NULL,'','text','НОВОСИБИРСК\r\n\r\n',1,NULL,NULL,NULL,NULL,NULL,'N','20','novosibirsk','','0',NULL,NULL,NULL),
	(21,'2014-07-12 13:39:24',1,'2014-07-12 13:39:24',1,3,NULL,'Y',NULL,NULL,500,'Омск',NULL,'','text',NULL,'','text','ОМСК\r\n\r\n',1,NULL,NULL,NULL,NULL,NULL,'N','21','omsk','','0',NULL,NULL,NULL),
	(22,'2014-07-12 13:39:45',1,'2014-07-12 13:39:45',1,3,NULL,'Y',NULL,NULL,500,'Ростов-на-дому',NULL,'','text',NULL,'','text','РОСТОВ-НА-ДОМУ\r\n\r\n',1,NULL,NULL,NULL,NULL,NULL,'N','22','rostov','','0',NULL,NULL,NULL),
	(23,'2014-07-12 13:40:00',1,'2014-07-12 13:40:00',1,3,NULL,'Y',NULL,NULL,500,'Самара',NULL,'','text',NULL,'','text','САМАРА\r\n\r\n',1,NULL,NULL,NULL,NULL,NULL,'N','23','samara','','0',NULL,NULL,NULL),
	(24,'2014-07-12 13:40:18',1,'2014-07-12 13:40:18',1,3,NULL,'Y',NULL,NULL,500,'Томск',NULL,'','text',NULL,'','text','ТОМСК\r\n\r\n',1,NULL,NULL,NULL,NULL,NULL,'N','24','tomsk','','0',NULL,NULL,NULL),
	(25,'2014-07-12 13:40:38',1,'2014-07-12 13:40:38',1,3,NULL,'Y',NULL,NULL,500,'Ульяновск',NULL,'','text',NULL,'','text','УЛЬЯНОВСК\r\n\r\n',1,NULL,NULL,NULL,NULL,NULL,'N','25','ulyanovsk','','0',NULL,NULL,NULL),
	(26,'2014-07-12 13:40:50',1,'2014-07-12 13:40:50',1,3,NULL,'Y',NULL,NULL,500,'Челябинск',NULL,'','text',NULL,'','text','ЧЕЛЯБИНСК\r\n\r\n',1,NULL,NULL,NULL,NULL,NULL,'N','26','chelyabinsk','','0',NULL,NULL,NULL),
	(27,'2014-07-18 12:41:27',1,'2014-07-12 14:55:40',1,1,NULL,'Y',NULL,NULL,500,'Роль отдела R&D в FMCG: наука и инновации в комании MARS',NULL,'','text',NULL,'','text','РОЛЬ ОТДЕЛА R&D В FMCG: НАУКА И ИННОВАЦИИ В КОМАНИИ MARS\r\n\r\n',1,NULL,NULL,NULL,NULL,NULL,'N','27','rol-otdela-r-d-v-fmcg-nauka-i-innovatsii-v-komanii-mars','','0',NULL,NULL,NULL),
	(28,'2014-07-18 12:41:21',1,'2014-07-12 15:38:52',1,1,NULL,'Y',NULL,NULL,500,'Роль отдела финансов в FMCG. Market Finance',NULL,'','text',NULL,'','text','РОЛЬ ОТДЕЛА ФИНАНСОВ В FMCG. MARKET FINANCE\r\n\r\n',1,NULL,NULL,NULL,NULL,NULL,'N','28','rol-otdela-finansov-v-fmcg-market-finance','','0',NULL,NULL,NULL);

/*!40000 ALTER TABLE `b_iblock_element` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table b_iblock_element_iprop
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_iblock_element_iprop`;

CREATE TABLE `b_iblock_element_iprop` (
  `IBLOCK_ID` int(11) NOT NULL,
  `SECTION_ID` int(11) NOT NULL,
  `ELEMENT_ID` int(11) NOT NULL,
  `IPROP_ID` int(11) NOT NULL,
  `VALUE` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ELEMENT_ID`,`IPROP_ID`),
  KEY `ix_b_iblock_element_iprop_0` (`IPROP_ID`),
  KEY `ix_b_iblock_element_iprop_1` (`IBLOCK_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_iblock_element_lock
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_iblock_element_lock`;

CREATE TABLE `b_iblock_element_lock` (
  `IBLOCK_ELEMENT_ID` int(11) NOT NULL,
  `DATE_LOCK` datetime DEFAULT NULL,
  `LOCKED_BY` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`IBLOCK_ELEMENT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_iblock_element_property
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_iblock_element_property`;

CREATE TABLE `b_iblock_element_property` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `IBLOCK_PROPERTY_ID` int(11) NOT NULL,
  `IBLOCK_ELEMENT_ID` int(11) NOT NULL,
  `VALUE` text COLLATE utf8_unicode_ci NOT NULL,
  `VALUE_TYPE` char(4) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'text',
  `VALUE_ENUM` int(11) DEFAULT NULL,
  `VALUE_NUM` decimal(18,4) DEFAULT NULL,
  `DESCRIPTION` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ix_iblock_element_property_1` (`IBLOCK_ELEMENT_ID`,`IBLOCK_PROPERTY_ID`),
  KEY `ix_iblock_element_property_2` (`IBLOCK_PROPERTY_ID`),
  KEY `ix_iblock_element_prop_enum` (`VALUE_ENUM`,`IBLOCK_PROPERTY_ID`),
  KEY `ix_iblock_element_prop_num` (`VALUE_NUM`,`IBLOCK_PROPERTY_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `b_iblock_element_property` WRITE;
/*!40000 ALTER TABLE `b_iblock_element_property` DISABLE KEYS */;

INSERT INTO `b_iblock_element_property` (`ID`, `IBLOCK_PROPERTY_ID`, `IBLOCK_ELEMENT_ID`, `VALUE`, `VALUE_TYPE`, `VALUE_ENUM`, `VALUE_NUM`, `DESCRIPTION`)
VALUES
	(3,6,7,'2','text',NULL,2.0000,''),
	(4,6,8,'4','text',NULL,4.0000,''),
	(9,4,10,'Mars Petcare Russia','text',NULL,0.0000,''),
	(10,5,10,'http://www.mars.com/global/careers/job-search/job-details.aspx?JobReferenceNo=ULY00471&SelectedLanguageID=15&CareerSite=10000','text',NULL,0.0000,''),
	(12,7,11,'Уроки профессионалов','text',NULL,0.0000,''),
	(14,9,11,'6','text',NULL,6.0000,''),
	(15,7,12,'Уроки эффективности','text',NULL,0.0000,''),
	(17,9,12,'8','text',NULL,8.0000,''),
	(18,7,13,'От исследования до упаковки','text',NULL,0.0000,''),
	(20,9,13,'10','text',NULL,10.0000,''),
	(22,7,14,'Стратегия и тактика роста','text',NULL,0.0000,''),
	(24,9,14,'12','text',NULL,12.0000,''),
	(25,1,15,'ON','text',NULL,0.0000,''),
	(26,1,16,'МСК','text',NULL,0.0000,''),
	(27,1,17,'СПБ','text',NULL,0.0000,''),
	(28,1,18,'ИРК','text',NULL,0.0000,''),
	(29,1,19,'КРД','text',NULL,0.0000,''),
	(30,1,20,'НВС','text',NULL,0.0000,''),
	(31,1,21,'ОМ','text',NULL,0.0000,''),
	(32,1,22,'РНД','text',NULL,0.0000,''),
	(33,1,23,'СМР','text',NULL,0.0000,''),
	(34,1,24,'ТМК','text',NULL,0.0000,''),
	(35,1,25,'УЛН','text',NULL,0.0000,''),
	(36,1,26,'ЧЛБ','text',NULL,0.0000,''),
	(37,10,27,'16','text',NULL,16.0000,''),
	(38,11,27,'2014-07-20 14:55:00','text',NULL,2014.0000,''),
	(39,12,27,'14','text',NULL,14.0000,''),
	(40,14,27,'1','text',NULL,1.0000,''),
	(42,8,14,'5','text',5,NULL,NULL),
	(43,10,28,'21','text',NULL,21.0000,''),
	(44,11,28,'2014-07-20 14:55:00','text',NULL,2014.0000,''),
	(45,12,28,'12','text',NULL,12.0000,''),
	(46,14,28,'5','text',NULL,5.0000,''),
	(48,8,11,'2','text',2,NULL,NULL),
	(49,8,12,'3','text',3,NULL,NULL),
	(50,8,13,'4','text',4,NULL,NULL),
	(51,3,7,'1','text',1,NULL,NULL);

/*!40000 ALTER TABLE `b_iblock_element_property` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table b_iblock_element_right
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_iblock_element_right`;

CREATE TABLE `b_iblock_element_right` (
  `IBLOCK_ID` int(11) NOT NULL,
  `SECTION_ID` int(11) NOT NULL,
  `ELEMENT_ID` int(11) NOT NULL,
  `RIGHT_ID` int(11) NOT NULL,
  `IS_INHERITED` char(1) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`RIGHT_ID`,`ELEMENT_ID`,`SECTION_ID`),
  KEY `ix_b_iblock_element_right_1` (`ELEMENT_ID`,`IBLOCK_ID`),
  KEY `ix_b_iblock_element_right_2` (`IBLOCK_ID`,`RIGHT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_iblock_fields
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_iblock_fields`;

CREATE TABLE `b_iblock_fields` (
  `IBLOCK_ID` int(18) NOT NULL,
  `FIELD_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `IS_REQUIRED` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DEFAULT_VALUE` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`IBLOCK_ID`,`FIELD_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `b_iblock_fields` WRITE;
/*!40000 ALTER TABLE `b_iblock_fields` DISABLE KEYS */;

INSERT INTO `b_iblock_fields` (`IBLOCK_ID`, `FIELD_ID`, `IS_REQUIRED`, `DEFAULT_VALUE`)
VALUES
	(1,'ACTIVE','Y','Y'),
	(1,'ACTIVE_FROM','N',''),
	(1,'ACTIVE_TO','N',''),
	(1,'CODE','Y','a:8:{s:6:\"UNIQUE\";s:1:\"Y\";s:15:\"TRANSLITERATION\";s:1:\"Y\";s:9:\"TRANS_LEN\";i:100;s:10:\"TRANS_CASE\";s:1:\"L\";s:11:\"TRANS_SPACE\";s:1:\"-\";s:11:\"TRANS_OTHER\";s:1:\"-\";s:9:\"TRANS_EAT\";s:1:\"Y\";s:10:\"USE_GOOGLE\";s:1:\"N\";}'),
	(1,'DETAIL_PICTURE','N','a:17:{s:5:\"SCALE\";s:1:\"N\";s:5:\"WIDTH\";s:0:\"\";s:6:\"HEIGHT\";s:0:\"\";s:13:\"IGNORE_ERRORS\";s:1:\"N\";s:6:\"METHOD\";s:8:\"resample\";s:11:\"COMPRESSION\";i:95;s:18:\"USE_WATERMARK_TEXT\";s:1:\"N\";s:14:\"WATERMARK_TEXT\";s:0:\"\";s:19:\"WATERMARK_TEXT_FONT\";s:0:\"\";s:20:\"WATERMARK_TEXT_COLOR\";s:0:\"\";s:19:\"WATERMARK_TEXT_SIZE\";s:0:\"\";s:23:\"WATERMARK_TEXT_POSITION\";s:2:\"tl\";s:18:\"USE_WATERMARK_FILE\";s:1:\"N\";s:14:\"WATERMARK_FILE\";s:0:\"\";s:20:\"WATERMARK_FILE_ALPHA\";s:0:\"\";s:23:\"WATERMARK_FILE_POSITION\";s:2:\"tl\";s:20:\"WATERMARK_FILE_ORDER\";N;}'),
	(1,'DETAIL_TEXT','N',''),
	(1,'DETAIL_TEXT_TYPE','Y','text'),
	(1,'IBLOCK_SECTION','N',''),
	(1,'LOG_ELEMENT_ADD','N',NULL),
	(1,'LOG_ELEMENT_DELETE','N',NULL),
	(1,'LOG_ELEMENT_EDIT','N',NULL),
	(1,'LOG_SECTION_ADD','N',NULL),
	(1,'LOG_SECTION_DELETE','N',NULL),
	(1,'LOG_SECTION_EDIT','N',NULL),
	(1,'NAME','Y',''),
	(1,'PREVIEW_PICTURE','N','a:20:{s:11:\"FROM_DETAIL\";s:1:\"N\";s:5:\"SCALE\";s:1:\"N\";s:5:\"WIDTH\";s:0:\"\";s:6:\"HEIGHT\";s:0:\"\";s:13:\"IGNORE_ERRORS\";s:1:\"N\";s:6:\"METHOD\";s:8:\"resample\";s:11:\"COMPRESSION\";i:95;s:18:\"DELETE_WITH_DETAIL\";s:1:\"N\";s:18:\"UPDATE_WITH_DETAIL\";s:1:\"N\";s:18:\"USE_WATERMARK_TEXT\";s:1:\"N\";s:14:\"WATERMARK_TEXT\";s:0:\"\";s:19:\"WATERMARK_TEXT_FONT\";s:0:\"\";s:20:\"WATERMARK_TEXT_COLOR\";s:0:\"\";s:19:\"WATERMARK_TEXT_SIZE\";s:0:\"\";s:23:\"WATERMARK_TEXT_POSITION\";s:2:\"tl\";s:18:\"USE_WATERMARK_FILE\";s:1:\"N\";s:14:\"WATERMARK_FILE\";s:0:\"\";s:20:\"WATERMARK_FILE_ALPHA\";s:0:\"\";s:23:\"WATERMARK_FILE_POSITION\";s:2:\"tl\";s:20:\"WATERMARK_FILE_ORDER\";N;}'),
	(1,'PREVIEW_TEXT','N',''),
	(1,'PREVIEW_TEXT_TYPE','Y','text'),
	(1,'SECTION_CODE','N','a:8:{s:6:\"UNIQUE\";s:1:\"N\";s:15:\"TRANSLITERATION\";s:1:\"N\";s:9:\"TRANS_LEN\";i:100;s:10:\"TRANS_CASE\";s:1:\"L\";s:11:\"TRANS_SPACE\";s:1:\"-\";s:11:\"TRANS_OTHER\";s:1:\"-\";s:9:\"TRANS_EAT\";s:1:\"Y\";s:10:\"USE_GOOGLE\";s:1:\"N\";}'),
	(1,'SECTION_DESCRIPTION','N',''),
	(1,'SECTION_DESCRIPTION_TYPE','Y','text'),
	(1,'SECTION_DETAIL_PICTURE','N','a:17:{s:5:\"SCALE\";s:1:\"N\";s:5:\"WIDTH\";s:0:\"\";s:6:\"HEIGHT\";s:0:\"\";s:13:\"IGNORE_ERRORS\";s:1:\"N\";s:6:\"METHOD\";s:8:\"resample\";s:11:\"COMPRESSION\";i:95;s:18:\"USE_WATERMARK_TEXT\";s:1:\"N\";s:14:\"WATERMARK_TEXT\";s:0:\"\";s:19:\"WATERMARK_TEXT_FONT\";s:0:\"\";s:20:\"WATERMARK_TEXT_COLOR\";s:0:\"\";s:19:\"WATERMARK_TEXT_SIZE\";s:0:\"\";s:23:\"WATERMARK_TEXT_POSITION\";s:2:\"tl\";s:18:\"USE_WATERMARK_FILE\";s:1:\"N\";s:14:\"WATERMARK_FILE\";s:0:\"\";s:20:\"WATERMARK_FILE_ALPHA\";s:0:\"\";s:23:\"WATERMARK_FILE_POSITION\";s:2:\"tl\";s:20:\"WATERMARK_FILE_ORDER\";N;}'),
	(1,'SECTION_NAME','Y',''),
	(1,'SECTION_PICTURE','N','a:20:{s:11:\"FROM_DETAIL\";s:1:\"N\";s:5:\"SCALE\";s:1:\"N\";s:5:\"WIDTH\";s:0:\"\";s:6:\"HEIGHT\";s:0:\"\";s:13:\"IGNORE_ERRORS\";s:1:\"N\";s:6:\"METHOD\";s:8:\"resample\";s:11:\"COMPRESSION\";i:95;s:18:\"DELETE_WITH_DETAIL\";s:1:\"N\";s:18:\"UPDATE_WITH_DETAIL\";s:1:\"N\";s:18:\"USE_WATERMARK_TEXT\";s:1:\"N\";s:14:\"WATERMARK_TEXT\";s:0:\"\";s:19:\"WATERMARK_TEXT_FONT\";s:0:\"\";s:20:\"WATERMARK_TEXT_COLOR\";s:0:\"\";s:19:\"WATERMARK_TEXT_SIZE\";s:0:\"\";s:23:\"WATERMARK_TEXT_POSITION\";s:2:\"tl\";s:18:\"USE_WATERMARK_FILE\";s:1:\"N\";s:14:\"WATERMARK_FILE\";s:0:\"\";s:20:\"WATERMARK_FILE_ALPHA\";s:0:\"\";s:23:\"WATERMARK_FILE_POSITION\";s:2:\"tl\";s:20:\"WATERMARK_FILE_ORDER\";N;}'),
	(1,'SECTION_XML_ID','N',''),
	(1,'SORT','N','0'),
	(1,'TAGS','N',''),
	(1,'XML_ID','N',''),
	(1,'XML_IMPORT_START_TIME','N',NULL),
	(2,'ACTIVE','Y','Y'),
	(2,'ACTIVE_FROM','N',''),
	(2,'ACTIVE_TO','N',''),
	(2,'CODE','N','a:8:{s:6:\"UNIQUE\";s:1:\"N\";s:15:\"TRANSLITERATION\";s:1:\"N\";s:9:\"TRANS_LEN\";i:100;s:10:\"TRANS_CASE\";s:1:\"L\";s:11:\"TRANS_SPACE\";s:1:\"-\";s:11:\"TRANS_OTHER\";s:1:\"-\";s:9:\"TRANS_EAT\";s:1:\"Y\";s:10:\"USE_GOOGLE\";s:1:\"N\";}'),
	(2,'DETAIL_PICTURE','N','a:17:{s:5:\"SCALE\";s:1:\"N\";s:5:\"WIDTH\";s:0:\"\";s:6:\"HEIGHT\";s:0:\"\";s:13:\"IGNORE_ERRORS\";s:1:\"N\";s:6:\"METHOD\";s:8:\"resample\";s:11:\"COMPRESSION\";i:95;s:18:\"USE_WATERMARK_TEXT\";s:1:\"N\";s:14:\"WATERMARK_TEXT\";s:0:\"\";s:19:\"WATERMARK_TEXT_FONT\";s:0:\"\";s:20:\"WATERMARK_TEXT_COLOR\";s:0:\"\";s:19:\"WATERMARK_TEXT_SIZE\";s:0:\"\";s:23:\"WATERMARK_TEXT_POSITION\";s:2:\"tl\";s:18:\"USE_WATERMARK_FILE\";s:1:\"N\";s:14:\"WATERMARK_FILE\";s:0:\"\";s:20:\"WATERMARK_FILE_ALPHA\";s:0:\"\";s:23:\"WATERMARK_FILE_POSITION\";s:2:\"tl\";s:20:\"WATERMARK_FILE_ORDER\";N;}'),
	(2,'DETAIL_TEXT','N',''),
	(2,'DETAIL_TEXT_TYPE','Y','text'),
	(2,'IBLOCK_SECTION','N',''),
	(2,'LOG_ELEMENT_ADD','N',NULL),
	(2,'LOG_ELEMENT_DELETE','N',NULL),
	(2,'LOG_ELEMENT_EDIT','N',NULL),
	(2,'LOG_SECTION_ADD','N',NULL),
	(2,'LOG_SECTION_DELETE','N',NULL),
	(2,'LOG_SECTION_EDIT','N',NULL),
	(2,'NAME','Y',''),
	(2,'PREVIEW_PICTURE','N','a:20:{s:11:\"FROM_DETAIL\";s:1:\"N\";s:5:\"SCALE\";s:1:\"N\";s:5:\"WIDTH\";s:0:\"\";s:6:\"HEIGHT\";s:0:\"\";s:13:\"IGNORE_ERRORS\";s:1:\"N\";s:6:\"METHOD\";s:8:\"resample\";s:11:\"COMPRESSION\";i:95;s:18:\"DELETE_WITH_DETAIL\";s:1:\"N\";s:18:\"UPDATE_WITH_DETAIL\";s:1:\"N\";s:18:\"USE_WATERMARK_TEXT\";s:1:\"N\";s:14:\"WATERMARK_TEXT\";s:0:\"\";s:19:\"WATERMARK_TEXT_FONT\";s:0:\"\";s:20:\"WATERMARK_TEXT_COLOR\";s:0:\"\";s:19:\"WATERMARK_TEXT_SIZE\";s:0:\"\";s:23:\"WATERMARK_TEXT_POSITION\";s:2:\"tl\";s:18:\"USE_WATERMARK_FILE\";s:1:\"N\";s:14:\"WATERMARK_FILE\";s:0:\"\";s:20:\"WATERMARK_FILE_ALPHA\";s:0:\"\";s:23:\"WATERMARK_FILE_POSITION\";s:2:\"tl\";s:20:\"WATERMARK_FILE_ORDER\";N;}'),
	(2,'PREVIEW_TEXT','N',''),
	(2,'PREVIEW_TEXT_TYPE','Y','text'),
	(2,'SECTION_CODE','N','a:8:{s:6:\"UNIQUE\";s:1:\"N\";s:15:\"TRANSLITERATION\";s:1:\"N\";s:9:\"TRANS_LEN\";i:100;s:10:\"TRANS_CASE\";s:1:\"L\";s:11:\"TRANS_SPACE\";s:1:\"-\";s:11:\"TRANS_OTHER\";s:1:\"-\";s:9:\"TRANS_EAT\";s:1:\"Y\";s:10:\"USE_GOOGLE\";s:1:\"N\";}'),
	(2,'SECTION_DESCRIPTION','N',''),
	(2,'SECTION_DESCRIPTION_TYPE','Y','text'),
	(2,'SECTION_DETAIL_PICTURE','N','a:17:{s:5:\"SCALE\";s:1:\"N\";s:5:\"WIDTH\";s:0:\"\";s:6:\"HEIGHT\";s:0:\"\";s:13:\"IGNORE_ERRORS\";s:1:\"N\";s:6:\"METHOD\";s:8:\"resample\";s:11:\"COMPRESSION\";i:95;s:18:\"USE_WATERMARK_TEXT\";s:1:\"N\";s:14:\"WATERMARK_TEXT\";s:0:\"\";s:19:\"WATERMARK_TEXT_FONT\";s:0:\"\";s:20:\"WATERMARK_TEXT_COLOR\";s:0:\"\";s:19:\"WATERMARK_TEXT_SIZE\";s:0:\"\";s:23:\"WATERMARK_TEXT_POSITION\";s:2:\"tl\";s:18:\"USE_WATERMARK_FILE\";s:1:\"N\";s:14:\"WATERMARK_FILE\";s:0:\"\";s:20:\"WATERMARK_FILE_ALPHA\";s:0:\"\";s:23:\"WATERMARK_FILE_POSITION\";s:2:\"tl\";s:20:\"WATERMARK_FILE_ORDER\";N;}'),
	(2,'SECTION_NAME','Y',''),
	(2,'SECTION_PICTURE','N','a:20:{s:11:\"FROM_DETAIL\";s:1:\"N\";s:5:\"SCALE\";s:1:\"N\";s:5:\"WIDTH\";s:0:\"\";s:6:\"HEIGHT\";s:0:\"\";s:13:\"IGNORE_ERRORS\";s:1:\"N\";s:6:\"METHOD\";s:8:\"resample\";s:11:\"COMPRESSION\";i:95;s:18:\"DELETE_WITH_DETAIL\";s:1:\"N\";s:18:\"UPDATE_WITH_DETAIL\";s:1:\"N\";s:18:\"USE_WATERMARK_TEXT\";s:1:\"N\";s:14:\"WATERMARK_TEXT\";s:0:\"\";s:19:\"WATERMARK_TEXT_FONT\";s:0:\"\";s:20:\"WATERMARK_TEXT_COLOR\";s:0:\"\";s:19:\"WATERMARK_TEXT_SIZE\";s:0:\"\";s:23:\"WATERMARK_TEXT_POSITION\";s:2:\"tl\";s:18:\"USE_WATERMARK_FILE\";s:1:\"N\";s:14:\"WATERMARK_FILE\";s:0:\"\";s:20:\"WATERMARK_FILE_ALPHA\";s:0:\"\";s:23:\"WATERMARK_FILE_POSITION\";s:2:\"tl\";s:20:\"WATERMARK_FILE_ORDER\";N;}'),
	(2,'SECTION_XML_ID','N',''),
	(2,'SORT','N','0'),
	(2,'TAGS','N',''),
	(2,'XML_ID','N',''),
	(2,'XML_IMPORT_START_TIME','N',NULL),
	(3,'ACTIVE','Y','Y'),
	(3,'ACTIVE_FROM','N',''),
	(3,'ACTIVE_TO','N',''),
	(3,'CODE','Y','a:8:{s:6:\"UNIQUE\";s:1:\"Y\";s:15:\"TRANSLITERATION\";s:1:\"Y\";s:9:\"TRANS_LEN\";i:100;s:10:\"TRANS_CASE\";s:1:\"L\";s:11:\"TRANS_SPACE\";s:1:\"-\";s:11:\"TRANS_OTHER\";s:1:\"-\";s:9:\"TRANS_EAT\";s:1:\"Y\";s:10:\"USE_GOOGLE\";s:1:\"N\";}'),
	(3,'DETAIL_PICTURE','N','a:17:{s:5:\"SCALE\";s:1:\"N\";s:5:\"WIDTH\";s:0:\"\";s:6:\"HEIGHT\";s:0:\"\";s:13:\"IGNORE_ERRORS\";s:1:\"N\";s:6:\"METHOD\";s:8:\"resample\";s:11:\"COMPRESSION\";i:95;s:18:\"USE_WATERMARK_TEXT\";s:1:\"N\";s:14:\"WATERMARK_TEXT\";s:0:\"\";s:19:\"WATERMARK_TEXT_FONT\";s:0:\"\";s:20:\"WATERMARK_TEXT_COLOR\";s:0:\"\";s:19:\"WATERMARK_TEXT_SIZE\";s:0:\"\";s:23:\"WATERMARK_TEXT_POSITION\";s:2:\"tl\";s:18:\"USE_WATERMARK_FILE\";s:1:\"N\";s:14:\"WATERMARK_FILE\";s:0:\"\";s:20:\"WATERMARK_FILE_ALPHA\";s:0:\"\";s:23:\"WATERMARK_FILE_POSITION\";s:2:\"tl\";s:20:\"WATERMARK_FILE_ORDER\";N;}'),
	(3,'DETAIL_TEXT','N',''),
	(3,'DETAIL_TEXT_TYPE','Y','text'),
	(3,'IBLOCK_SECTION','N',''),
	(3,'LOG_ELEMENT_ADD','N',NULL),
	(3,'LOG_ELEMENT_DELETE','N',NULL),
	(3,'LOG_ELEMENT_EDIT','N',NULL),
	(3,'LOG_SECTION_ADD','N',NULL),
	(3,'LOG_SECTION_DELETE','N',NULL),
	(3,'LOG_SECTION_EDIT','N',NULL),
	(3,'NAME','Y',''),
	(3,'PREVIEW_PICTURE','N','a:20:{s:11:\"FROM_DETAIL\";s:1:\"N\";s:5:\"SCALE\";s:1:\"N\";s:5:\"WIDTH\";s:0:\"\";s:6:\"HEIGHT\";s:0:\"\";s:13:\"IGNORE_ERRORS\";s:1:\"N\";s:6:\"METHOD\";s:8:\"resample\";s:11:\"COMPRESSION\";i:95;s:18:\"DELETE_WITH_DETAIL\";s:1:\"N\";s:18:\"UPDATE_WITH_DETAIL\";s:1:\"N\";s:18:\"USE_WATERMARK_TEXT\";s:1:\"N\";s:14:\"WATERMARK_TEXT\";s:0:\"\";s:19:\"WATERMARK_TEXT_FONT\";s:0:\"\";s:20:\"WATERMARK_TEXT_COLOR\";s:0:\"\";s:19:\"WATERMARK_TEXT_SIZE\";s:0:\"\";s:23:\"WATERMARK_TEXT_POSITION\";s:2:\"tl\";s:18:\"USE_WATERMARK_FILE\";s:1:\"N\";s:14:\"WATERMARK_FILE\";s:0:\"\";s:20:\"WATERMARK_FILE_ALPHA\";s:0:\"\";s:23:\"WATERMARK_FILE_POSITION\";s:2:\"tl\";s:20:\"WATERMARK_FILE_ORDER\";N;}'),
	(3,'PREVIEW_TEXT','N',''),
	(3,'PREVIEW_TEXT_TYPE','Y','text'),
	(3,'SECTION_CODE','N','a:8:{s:6:\"UNIQUE\";s:1:\"N\";s:15:\"TRANSLITERATION\";s:1:\"N\";s:9:\"TRANS_LEN\";i:100;s:10:\"TRANS_CASE\";s:1:\"L\";s:11:\"TRANS_SPACE\";s:1:\"-\";s:11:\"TRANS_OTHER\";s:1:\"-\";s:9:\"TRANS_EAT\";s:1:\"Y\";s:10:\"USE_GOOGLE\";s:1:\"N\";}'),
	(3,'SECTION_DESCRIPTION','N',''),
	(3,'SECTION_DESCRIPTION_TYPE','Y','text'),
	(3,'SECTION_DETAIL_PICTURE','N','a:17:{s:5:\"SCALE\";s:1:\"N\";s:5:\"WIDTH\";s:0:\"\";s:6:\"HEIGHT\";s:0:\"\";s:13:\"IGNORE_ERRORS\";s:1:\"N\";s:6:\"METHOD\";s:8:\"resample\";s:11:\"COMPRESSION\";i:95;s:18:\"USE_WATERMARK_TEXT\";s:1:\"N\";s:14:\"WATERMARK_TEXT\";s:0:\"\";s:19:\"WATERMARK_TEXT_FONT\";s:0:\"\";s:20:\"WATERMARK_TEXT_COLOR\";s:0:\"\";s:19:\"WATERMARK_TEXT_SIZE\";s:0:\"\";s:23:\"WATERMARK_TEXT_POSITION\";s:2:\"tl\";s:18:\"USE_WATERMARK_FILE\";s:1:\"N\";s:14:\"WATERMARK_FILE\";s:0:\"\";s:20:\"WATERMARK_FILE_ALPHA\";s:0:\"\";s:23:\"WATERMARK_FILE_POSITION\";s:2:\"tl\";s:20:\"WATERMARK_FILE_ORDER\";N;}'),
	(3,'SECTION_NAME','Y',''),
	(3,'SECTION_PICTURE','N','a:20:{s:11:\"FROM_DETAIL\";s:1:\"N\";s:5:\"SCALE\";s:1:\"N\";s:5:\"WIDTH\";s:0:\"\";s:6:\"HEIGHT\";s:0:\"\";s:13:\"IGNORE_ERRORS\";s:1:\"N\";s:6:\"METHOD\";s:8:\"resample\";s:11:\"COMPRESSION\";i:95;s:18:\"DELETE_WITH_DETAIL\";s:1:\"N\";s:18:\"UPDATE_WITH_DETAIL\";s:1:\"N\";s:18:\"USE_WATERMARK_TEXT\";s:1:\"N\";s:14:\"WATERMARK_TEXT\";s:0:\"\";s:19:\"WATERMARK_TEXT_FONT\";s:0:\"\";s:20:\"WATERMARK_TEXT_COLOR\";s:0:\"\";s:19:\"WATERMARK_TEXT_SIZE\";s:0:\"\";s:23:\"WATERMARK_TEXT_POSITION\";s:2:\"tl\";s:18:\"USE_WATERMARK_FILE\";s:1:\"N\";s:14:\"WATERMARK_FILE\";s:0:\"\";s:20:\"WATERMARK_FILE_ALPHA\";s:0:\"\";s:23:\"WATERMARK_FILE_POSITION\";s:2:\"tl\";s:20:\"WATERMARK_FILE_ORDER\";N;}'),
	(3,'SECTION_XML_ID','N',''),
	(3,'SORT','N','0'),
	(3,'TAGS','N',''),
	(3,'XML_ID','N',''),
	(3,'XML_IMPORT_START_TIME','N',NULL),
	(4,'ACTIVE','Y','Y'),
	(4,'ACTIVE_FROM','N',''),
	(4,'ACTIVE_TO','N',''),
	(4,'CODE','Y','a:8:{s:6:\"UNIQUE\";s:1:\"Y\";s:15:\"TRANSLITERATION\";s:1:\"Y\";s:9:\"TRANS_LEN\";i:100;s:10:\"TRANS_CASE\";s:1:\"L\";s:11:\"TRANS_SPACE\";s:1:\"-\";s:11:\"TRANS_OTHER\";s:1:\"-\";s:9:\"TRANS_EAT\";s:1:\"Y\";s:10:\"USE_GOOGLE\";s:1:\"N\";}'),
	(4,'DETAIL_PICTURE','N','a:17:{s:5:\"SCALE\";s:1:\"N\";s:5:\"WIDTH\";s:0:\"\";s:6:\"HEIGHT\";s:0:\"\";s:13:\"IGNORE_ERRORS\";s:1:\"N\";s:6:\"METHOD\";s:8:\"resample\";s:11:\"COMPRESSION\";i:95;s:18:\"USE_WATERMARK_TEXT\";s:1:\"N\";s:14:\"WATERMARK_TEXT\";s:0:\"\";s:19:\"WATERMARK_TEXT_FONT\";s:0:\"\";s:20:\"WATERMARK_TEXT_COLOR\";s:0:\"\";s:19:\"WATERMARK_TEXT_SIZE\";s:0:\"\";s:23:\"WATERMARK_TEXT_POSITION\";s:2:\"tl\";s:18:\"USE_WATERMARK_FILE\";s:1:\"N\";s:14:\"WATERMARK_FILE\";s:0:\"\";s:20:\"WATERMARK_FILE_ALPHA\";s:0:\"\";s:23:\"WATERMARK_FILE_POSITION\";s:2:\"tl\";s:20:\"WATERMARK_FILE_ORDER\";N;}'),
	(4,'DETAIL_TEXT','N',''),
	(4,'DETAIL_TEXT_TYPE','Y','text'),
	(4,'IBLOCK_SECTION','N',''),
	(4,'LOG_ELEMENT_ADD','N',NULL),
	(4,'LOG_ELEMENT_DELETE','N',NULL),
	(4,'LOG_ELEMENT_EDIT','N',NULL),
	(4,'LOG_SECTION_ADD','N',NULL),
	(4,'LOG_SECTION_DELETE','N',NULL),
	(4,'LOG_SECTION_EDIT','N',NULL),
	(4,'NAME','Y',''),
	(4,'PREVIEW_PICTURE','N','a:20:{s:11:\"FROM_DETAIL\";s:1:\"N\";s:5:\"SCALE\";s:1:\"N\";s:5:\"WIDTH\";s:0:\"\";s:6:\"HEIGHT\";s:0:\"\";s:13:\"IGNORE_ERRORS\";s:1:\"N\";s:6:\"METHOD\";s:8:\"resample\";s:11:\"COMPRESSION\";i:95;s:18:\"DELETE_WITH_DETAIL\";s:1:\"N\";s:18:\"UPDATE_WITH_DETAIL\";s:1:\"N\";s:18:\"USE_WATERMARK_TEXT\";s:1:\"N\";s:14:\"WATERMARK_TEXT\";s:0:\"\";s:19:\"WATERMARK_TEXT_FONT\";s:0:\"\";s:20:\"WATERMARK_TEXT_COLOR\";s:0:\"\";s:19:\"WATERMARK_TEXT_SIZE\";s:0:\"\";s:23:\"WATERMARK_TEXT_POSITION\";s:2:\"tl\";s:18:\"USE_WATERMARK_FILE\";s:1:\"N\";s:14:\"WATERMARK_FILE\";s:0:\"\";s:20:\"WATERMARK_FILE_ALPHA\";s:0:\"\";s:23:\"WATERMARK_FILE_POSITION\";s:2:\"tl\";s:20:\"WATERMARK_FILE_ORDER\";N;}'),
	(4,'PREVIEW_TEXT','N',''),
	(4,'PREVIEW_TEXT_TYPE','Y','text'),
	(4,'SECTION_CODE','N','a:8:{s:6:\"UNIQUE\";s:1:\"N\";s:15:\"TRANSLITERATION\";s:1:\"N\";s:9:\"TRANS_LEN\";i:100;s:10:\"TRANS_CASE\";s:1:\"L\";s:11:\"TRANS_SPACE\";s:1:\"-\";s:11:\"TRANS_OTHER\";s:1:\"-\";s:9:\"TRANS_EAT\";s:1:\"Y\";s:10:\"USE_GOOGLE\";s:1:\"N\";}'),
	(4,'SECTION_DESCRIPTION','N',''),
	(4,'SECTION_DESCRIPTION_TYPE','Y','text'),
	(4,'SECTION_DETAIL_PICTURE','N','a:17:{s:5:\"SCALE\";s:1:\"N\";s:5:\"WIDTH\";s:0:\"\";s:6:\"HEIGHT\";s:0:\"\";s:13:\"IGNORE_ERRORS\";s:1:\"N\";s:6:\"METHOD\";s:8:\"resample\";s:11:\"COMPRESSION\";i:95;s:18:\"USE_WATERMARK_TEXT\";s:1:\"N\";s:14:\"WATERMARK_TEXT\";s:0:\"\";s:19:\"WATERMARK_TEXT_FONT\";s:0:\"\";s:20:\"WATERMARK_TEXT_COLOR\";s:0:\"\";s:19:\"WATERMARK_TEXT_SIZE\";s:0:\"\";s:23:\"WATERMARK_TEXT_POSITION\";s:2:\"tl\";s:18:\"USE_WATERMARK_FILE\";s:1:\"N\";s:14:\"WATERMARK_FILE\";s:0:\"\";s:20:\"WATERMARK_FILE_ALPHA\";s:0:\"\";s:23:\"WATERMARK_FILE_POSITION\";s:2:\"tl\";s:20:\"WATERMARK_FILE_ORDER\";N;}'),
	(4,'SECTION_NAME','Y',''),
	(4,'SECTION_PICTURE','N','a:20:{s:11:\"FROM_DETAIL\";s:1:\"N\";s:5:\"SCALE\";s:1:\"N\";s:5:\"WIDTH\";s:0:\"\";s:6:\"HEIGHT\";s:0:\"\";s:13:\"IGNORE_ERRORS\";s:1:\"N\";s:6:\"METHOD\";s:8:\"resample\";s:11:\"COMPRESSION\";i:95;s:18:\"DELETE_WITH_DETAIL\";s:1:\"N\";s:18:\"UPDATE_WITH_DETAIL\";s:1:\"N\";s:18:\"USE_WATERMARK_TEXT\";s:1:\"N\";s:14:\"WATERMARK_TEXT\";s:0:\"\";s:19:\"WATERMARK_TEXT_FONT\";s:0:\"\";s:20:\"WATERMARK_TEXT_COLOR\";s:0:\"\";s:19:\"WATERMARK_TEXT_SIZE\";s:0:\"\";s:23:\"WATERMARK_TEXT_POSITION\";s:2:\"tl\";s:18:\"USE_WATERMARK_FILE\";s:1:\"N\";s:14:\"WATERMARK_FILE\";s:0:\"\";s:20:\"WATERMARK_FILE_ALPHA\";s:0:\"\";s:23:\"WATERMARK_FILE_POSITION\";s:2:\"tl\";s:20:\"WATERMARK_FILE_ORDER\";N;}'),
	(4,'SECTION_XML_ID','N',''),
	(4,'SORT','N','0'),
	(4,'TAGS','N',''),
	(4,'XML_ID','N',''),
	(4,'XML_IMPORT_START_TIME','N',NULL),
	(5,'ACTIVE','Y','Y'),
	(5,'ACTIVE_FROM','N',''),
	(5,'ACTIVE_TO','N',''),
	(5,'CODE','Y','a:8:{s:6:\"UNIQUE\";s:1:\"Y\";s:15:\"TRANSLITERATION\";s:1:\"Y\";s:9:\"TRANS_LEN\";i:100;s:10:\"TRANS_CASE\";s:1:\"L\";s:11:\"TRANS_SPACE\";s:1:\"-\";s:11:\"TRANS_OTHER\";s:1:\"-\";s:9:\"TRANS_EAT\";s:1:\"Y\";s:10:\"USE_GOOGLE\";s:1:\"N\";}'),
	(5,'DETAIL_PICTURE','N','a:17:{s:5:\"SCALE\";s:1:\"N\";s:5:\"WIDTH\";s:0:\"\";s:6:\"HEIGHT\";s:0:\"\";s:13:\"IGNORE_ERRORS\";s:1:\"N\";s:6:\"METHOD\";s:8:\"resample\";s:11:\"COMPRESSION\";i:95;s:18:\"USE_WATERMARK_TEXT\";s:1:\"N\";s:14:\"WATERMARK_TEXT\";s:0:\"\";s:19:\"WATERMARK_TEXT_FONT\";s:0:\"\";s:20:\"WATERMARK_TEXT_COLOR\";s:0:\"\";s:19:\"WATERMARK_TEXT_SIZE\";s:0:\"\";s:23:\"WATERMARK_TEXT_POSITION\";s:2:\"tl\";s:18:\"USE_WATERMARK_FILE\";s:1:\"N\";s:14:\"WATERMARK_FILE\";s:0:\"\";s:20:\"WATERMARK_FILE_ALPHA\";s:0:\"\";s:23:\"WATERMARK_FILE_POSITION\";s:2:\"tl\";s:20:\"WATERMARK_FILE_ORDER\";N;}'),
	(5,'DETAIL_TEXT','N',''),
	(5,'DETAIL_TEXT_TYPE','Y','text'),
	(5,'IBLOCK_SECTION','N',''),
	(5,'LOG_ELEMENT_ADD','N',NULL),
	(5,'LOG_ELEMENT_DELETE','N',NULL),
	(5,'LOG_ELEMENT_EDIT','N',NULL),
	(5,'LOG_SECTION_ADD','N',NULL),
	(5,'LOG_SECTION_DELETE','N',NULL),
	(5,'LOG_SECTION_EDIT','N',NULL),
	(5,'NAME','Y',''),
	(5,'PREVIEW_PICTURE','N','a:20:{s:11:\"FROM_DETAIL\";s:1:\"N\";s:5:\"SCALE\";s:1:\"N\";s:5:\"WIDTH\";s:0:\"\";s:6:\"HEIGHT\";s:0:\"\";s:13:\"IGNORE_ERRORS\";s:1:\"N\";s:6:\"METHOD\";s:8:\"resample\";s:11:\"COMPRESSION\";i:95;s:18:\"DELETE_WITH_DETAIL\";s:1:\"N\";s:18:\"UPDATE_WITH_DETAIL\";s:1:\"N\";s:18:\"USE_WATERMARK_TEXT\";s:1:\"N\";s:14:\"WATERMARK_TEXT\";s:0:\"\";s:19:\"WATERMARK_TEXT_FONT\";s:0:\"\";s:20:\"WATERMARK_TEXT_COLOR\";s:0:\"\";s:19:\"WATERMARK_TEXT_SIZE\";s:0:\"\";s:23:\"WATERMARK_TEXT_POSITION\";s:2:\"tl\";s:18:\"USE_WATERMARK_FILE\";s:1:\"N\";s:14:\"WATERMARK_FILE\";s:0:\"\";s:20:\"WATERMARK_FILE_ALPHA\";s:0:\"\";s:23:\"WATERMARK_FILE_POSITION\";s:2:\"tl\";s:20:\"WATERMARK_FILE_ORDER\";N;}'),
	(5,'PREVIEW_TEXT','N',''),
	(5,'PREVIEW_TEXT_TYPE','Y','text'),
	(5,'SECTION_CODE','N','a:8:{s:6:\"UNIQUE\";s:1:\"N\";s:15:\"TRANSLITERATION\";s:1:\"N\";s:9:\"TRANS_LEN\";i:100;s:10:\"TRANS_CASE\";s:1:\"L\";s:11:\"TRANS_SPACE\";s:1:\"-\";s:11:\"TRANS_OTHER\";s:1:\"-\";s:9:\"TRANS_EAT\";s:1:\"Y\";s:10:\"USE_GOOGLE\";s:1:\"N\";}'),
	(5,'SECTION_DESCRIPTION','N',''),
	(5,'SECTION_DESCRIPTION_TYPE','Y','text'),
	(5,'SECTION_DETAIL_PICTURE','N','a:17:{s:5:\"SCALE\";s:1:\"N\";s:5:\"WIDTH\";s:0:\"\";s:6:\"HEIGHT\";s:0:\"\";s:13:\"IGNORE_ERRORS\";s:1:\"N\";s:6:\"METHOD\";s:8:\"resample\";s:11:\"COMPRESSION\";i:95;s:18:\"USE_WATERMARK_TEXT\";s:1:\"N\";s:14:\"WATERMARK_TEXT\";s:0:\"\";s:19:\"WATERMARK_TEXT_FONT\";s:0:\"\";s:20:\"WATERMARK_TEXT_COLOR\";s:0:\"\";s:19:\"WATERMARK_TEXT_SIZE\";s:0:\"\";s:23:\"WATERMARK_TEXT_POSITION\";s:2:\"tl\";s:18:\"USE_WATERMARK_FILE\";s:1:\"N\";s:14:\"WATERMARK_FILE\";s:0:\"\";s:20:\"WATERMARK_FILE_ALPHA\";s:0:\"\";s:23:\"WATERMARK_FILE_POSITION\";s:2:\"tl\";s:20:\"WATERMARK_FILE_ORDER\";N;}'),
	(5,'SECTION_NAME','Y',''),
	(5,'SECTION_PICTURE','N','a:20:{s:11:\"FROM_DETAIL\";s:1:\"N\";s:5:\"SCALE\";s:1:\"N\";s:5:\"WIDTH\";s:0:\"\";s:6:\"HEIGHT\";s:0:\"\";s:13:\"IGNORE_ERRORS\";s:1:\"N\";s:6:\"METHOD\";s:8:\"resample\";s:11:\"COMPRESSION\";i:95;s:18:\"DELETE_WITH_DETAIL\";s:1:\"N\";s:18:\"UPDATE_WITH_DETAIL\";s:1:\"N\";s:18:\"USE_WATERMARK_TEXT\";s:1:\"N\";s:14:\"WATERMARK_TEXT\";s:0:\"\";s:19:\"WATERMARK_TEXT_FONT\";s:0:\"\";s:20:\"WATERMARK_TEXT_COLOR\";s:0:\"\";s:19:\"WATERMARK_TEXT_SIZE\";s:0:\"\";s:23:\"WATERMARK_TEXT_POSITION\";s:2:\"tl\";s:18:\"USE_WATERMARK_FILE\";s:1:\"N\";s:14:\"WATERMARK_FILE\";s:0:\"\";s:20:\"WATERMARK_FILE_ALPHA\";s:0:\"\";s:23:\"WATERMARK_FILE_POSITION\";s:2:\"tl\";s:20:\"WATERMARK_FILE_ORDER\";N;}'),
	(5,'SECTION_XML_ID','N',''),
	(5,'SORT','N','0'),
	(5,'TAGS','N',''),
	(5,'XML_ID','N',''),
	(5,'XML_IMPORT_START_TIME','N',NULL),
	(6,'ACTIVE','Y','Y'),
	(6,'ACTIVE_FROM','N',''),
	(6,'ACTIVE_TO','N',''),
	(6,'CODE','N','a:8:{s:6:\"UNIQUE\";s:1:\"N\";s:15:\"TRANSLITERATION\";s:1:\"N\";s:9:\"TRANS_LEN\";i:100;s:10:\"TRANS_CASE\";s:1:\"L\";s:11:\"TRANS_SPACE\";s:1:\"-\";s:11:\"TRANS_OTHER\";s:1:\"-\";s:9:\"TRANS_EAT\";s:1:\"Y\";s:10:\"USE_GOOGLE\";s:1:\"N\";}'),
	(6,'DETAIL_PICTURE','N','a:17:{s:5:\"SCALE\";s:1:\"N\";s:5:\"WIDTH\";s:0:\"\";s:6:\"HEIGHT\";s:0:\"\";s:13:\"IGNORE_ERRORS\";s:1:\"N\";s:6:\"METHOD\";s:8:\"resample\";s:11:\"COMPRESSION\";i:95;s:18:\"USE_WATERMARK_TEXT\";s:1:\"N\";s:14:\"WATERMARK_TEXT\";s:0:\"\";s:19:\"WATERMARK_TEXT_FONT\";s:0:\"\";s:20:\"WATERMARK_TEXT_COLOR\";s:0:\"\";s:19:\"WATERMARK_TEXT_SIZE\";s:0:\"\";s:23:\"WATERMARK_TEXT_POSITION\";s:2:\"tl\";s:18:\"USE_WATERMARK_FILE\";s:1:\"N\";s:14:\"WATERMARK_FILE\";s:0:\"\";s:20:\"WATERMARK_FILE_ALPHA\";s:0:\"\";s:23:\"WATERMARK_FILE_POSITION\";s:2:\"tl\";s:20:\"WATERMARK_FILE_ORDER\";N;}'),
	(6,'DETAIL_TEXT','N',''),
	(6,'DETAIL_TEXT_TYPE','Y','text'),
	(6,'IBLOCK_SECTION','N',''),
	(6,'LOG_ELEMENT_ADD','N',NULL),
	(6,'LOG_ELEMENT_DELETE','N',NULL),
	(6,'LOG_ELEMENT_EDIT','N',NULL),
	(6,'LOG_SECTION_ADD','N',NULL),
	(6,'LOG_SECTION_DELETE','N',NULL),
	(6,'LOG_SECTION_EDIT','N',NULL),
	(6,'NAME','Y',''),
	(6,'PREVIEW_PICTURE','N','a:20:{s:11:\"FROM_DETAIL\";s:1:\"N\";s:5:\"SCALE\";s:1:\"N\";s:5:\"WIDTH\";s:0:\"\";s:6:\"HEIGHT\";s:0:\"\";s:13:\"IGNORE_ERRORS\";s:1:\"N\";s:6:\"METHOD\";s:8:\"resample\";s:11:\"COMPRESSION\";i:95;s:18:\"DELETE_WITH_DETAIL\";s:1:\"N\";s:18:\"UPDATE_WITH_DETAIL\";s:1:\"N\";s:18:\"USE_WATERMARK_TEXT\";s:1:\"N\";s:14:\"WATERMARK_TEXT\";s:0:\"\";s:19:\"WATERMARK_TEXT_FONT\";s:0:\"\";s:20:\"WATERMARK_TEXT_COLOR\";s:0:\"\";s:19:\"WATERMARK_TEXT_SIZE\";s:0:\"\";s:23:\"WATERMARK_TEXT_POSITION\";s:2:\"tl\";s:18:\"USE_WATERMARK_FILE\";s:1:\"N\";s:14:\"WATERMARK_FILE\";s:0:\"\";s:20:\"WATERMARK_FILE_ALPHA\";s:0:\"\";s:23:\"WATERMARK_FILE_POSITION\";s:2:\"tl\";s:20:\"WATERMARK_FILE_ORDER\";N;}'),
	(6,'PREVIEW_TEXT','N',''),
	(6,'PREVIEW_TEXT_TYPE','Y','text'),
	(6,'SECTION_CODE','N','a:8:{s:6:\"UNIQUE\";s:1:\"N\";s:15:\"TRANSLITERATION\";s:1:\"N\";s:9:\"TRANS_LEN\";i:100;s:10:\"TRANS_CASE\";s:1:\"L\";s:11:\"TRANS_SPACE\";s:1:\"-\";s:11:\"TRANS_OTHER\";s:1:\"-\";s:9:\"TRANS_EAT\";s:1:\"Y\";s:10:\"USE_GOOGLE\";s:1:\"N\";}'),
	(6,'SECTION_DESCRIPTION','N',''),
	(6,'SECTION_DESCRIPTION_TYPE','Y','text'),
	(6,'SECTION_DETAIL_PICTURE','N','a:17:{s:5:\"SCALE\";s:1:\"N\";s:5:\"WIDTH\";s:0:\"\";s:6:\"HEIGHT\";s:0:\"\";s:13:\"IGNORE_ERRORS\";s:1:\"N\";s:6:\"METHOD\";s:8:\"resample\";s:11:\"COMPRESSION\";i:95;s:18:\"USE_WATERMARK_TEXT\";s:1:\"N\";s:14:\"WATERMARK_TEXT\";s:0:\"\";s:19:\"WATERMARK_TEXT_FONT\";s:0:\"\";s:20:\"WATERMARK_TEXT_COLOR\";s:0:\"\";s:19:\"WATERMARK_TEXT_SIZE\";s:0:\"\";s:23:\"WATERMARK_TEXT_POSITION\";s:2:\"tl\";s:18:\"USE_WATERMARK_FILE\";s:1:\"N\";s:14:\"WATERMARK_FILE\";s:0:\"\";s:20:\"WATERMARK_FILE_ALPHA\";s:0:\"\";s:23:\"WATERMARK_FILE_POSITION\";s:2:\"tl\";s:20:\"WATERMARK_FILE_ORDER\";N;}'),
	(6,'SECTION_NAME','Y',''),
	(6,'SECTION_PICTURE','N','a:20:{s:11:\"FROM_DETAIL\";s:1:\"N\";s:5:\"SCALE\";s:1:\"N\";s:5:\"WIDTH\";s:0:\"\";s:6:\"HEIGHT\";s:0:\"\";s:13:\"IGNORE_ERRORS\";s:1:\"N\";s:6:\"METHOD\";s:8:\"resample\";s:11:\"COMPRESSION\";i:95;s:18:\"DELETE_WITH_DETAIL\";s:1:\"N\";s:18:\"UPDATE_WITH_DETAIL\";s:1:\"N\";s:18:\"USE_WATERMARK_TEXT\";s:1:\"N\";s:14:\"WATERMARK_TEXT\";s:0:\"\";s:19:\"WATERMARK_TEXT_FONT\";s:0:\"\";s:20:\"WATERMARK_TEXT_COLOR\";s:0:\"\";s:19:\"WATERMARK_TEXT_SIZE\";s:0:\"\";s:23:\"WATERMARK_TEXT_POSITION\";s:2:\"tl\";s:18:\"USE_WATERMARK_FILE\";s:1:\"N\";s:14:\"WATERMARK_FILE\";s:0:\"\";s:20:\"WATERMARK_FILE_ALPHA\";s:0:\"\";s:23:\"WATERMARK_FILE_POSITION\";s:2:\"tl\";s:20:\"WATERMARK_FILE_ORDER\";N;}'),
	(6,'SECTION_XML_ID','N',''),
	(6,'SORT','N','0'),
	(6,'TAGS','N',''),
	(6,'XML_ID','N',''),
	(6,'XML_IMPORT_START_TIME','N',NULL),
	(7,'ACTIVE','Y','Y'),
	(7,'ACTIVE_FROM','N',''),
	(7,'ACTIVE_TO','N',''),
	(7,'CODE','N','a:8:{s:6:\"UNIQUE\";s:1:\"Y\";s:15:\"TRANSLITERATION\";s:1:\"Y\";s:9:\"TRANS_LEN\";i:100;s:10:\"TRANS_CASE\";s:1:\"L\";s:11:\"TRANS_SPACE\";s:1:\"-\";s:11:\"TRANS_OTHER\";s:1:\"-\";s:9:\"TRANS_EAT\";s:1:\"Y\";s:10:\"USE_GOOGLE\";s:1:\"N\";}'),
	(7,'DETAIL_PICTURE','N','a:17:{s:5:\"SCALE\";s:1:\"N\";s:5:\"WIDTH\";s:0:\"\";s:6:\"HEIGHT\";s:0:\"\";s:13:\"IGNORE_ERRORS\";s:1:\"N\";s:6:\"METHOD\";s:8:\"resample\";s:11:\"COMPRESSION\";i:95;s:18:\"USE_WATERMARK_TEXT\";s:1:\"N\";s:14:\"WATERMARK_TEXT\";s:0:\"\";s:19:\"WATERMARK_TEXT_FONT\";s:0:\"\";s:20:\"WATERMARK_TEXT_COLOR\";s:0:\"\";s:19:\"WATERMARK_TEXT_SIZE\";s:0:\"\";s:23:\"WATERMARK_TEXT_POSITION\";s:2:\"tl\";s:18:\"USE_WATERMARK_FILE\";s:1:\"N\";s:14:\"WATERMARK_FILE\";s:0:\"\";s:20:\"WATERMARK_FILE_ALPHA\";s:0:\"\";s:23:\"WATERMARK_FILE_POSITION\";s:2:\"tl\";s:20:\"WATERMARK_FILE_ORDER\";N;}'),
	(7,'DETAIL_TEXT','N',''),
	(7,'DETAIL_TEXT_TYPE','Y','text'),
	(7,'IBLOCK_SECTION','N',''),
	(7,'LOG_ELEMENT_ADD','N',NULL),
	(7,'LOG_ELEMENT_DELETE','N',NULL),
	(7,'LOG_ELEMENT_EDIT','N',NULL),
	(7,'LOG_SECTION_ADD','N',NULL),
	(7,'LOG_SECTION_DELETE','N',NULL),
	(7,'LOG_SECTION_EDIT','N',NULL),
	(7,'NAME','Y',''),
	(7,'PREVIEW_PICTURE','N','a:20:{s:11:\"FROM_DETAIL\";s:1:\"N\";s:5:\"SCALE\";s:1:\"N\";s:5:\"WIDTH\";s:0:\"\";s:6:\"HEIGHT\";s:0:\"\";s:13:\"IGNORE_ERRORS\";s:1:\"N\";s:6:\"METHOD\";s:8:\"resample\";s:11:\"COMPRESSION\";i:95;s:18:\"DELETE_WITH_DETAIL\";s:1:\"N\";s:18:\"UPDATE_WITH_DETAIL\";s:1:\"N\";s:18:\"USE_WATERMARK_TEXT\";s:1:\"N\";s:14:\"WATERMARK_TEXT\";s:0:\"\";s:19:\"WATERMARK_TEXT_FONT\";s:0:\"\";s:20:\"WATERMARK_TEXT_COLOR\";s:0:\"\";s:19:\"WATERMARK_TEXT_SIZE\";s:0:\"\";s:23:\"WATERMARK_TEXT_POSITION\";s:2:\"tl\";s:18:\"USE_WATERMARK_FILE\";s:1:\"N\";s:14:\"WATERMARK_FILE\";s:0:\"\";s:20:\"WATERMARK_FILE_ALPHA\";s:0:\"\";s:23:\"WATERMARK_FILE_POSITION\";s:2:\"tl\";s:20:\"WATERMARK_FILE_ORDER\";N;}'),
	(7,'PREVIEW_TEXT','N',''),
	(7,'PREVIEW_TEXT_TYPE','Y','text'),
	(7,'SECTION_CODE','N','a:8:{s:6:\"UNIQUE\";s:1:\"N\";s:15:\"TRANSLITERATION\";s:1:\"N\";s:9:\"TRANS_LEN\";i:100;s:10:\"TRANS_CASE\";s:1:\"L\";s:11:\"TRANS_SPACE\";s:1:\"-\";s:11:\"TRANS_OTHER\";s:1:\"-\";s:9:\"TRANS_EAT\";s:1:\"Y\";s:10:\"USE_GOOGLE\";s:1:\"N\";}'),
	(7,'SECTION_DESCRIPTION','N',''),
	(7,'SECTION_DESCRIPTION_TYPE','Y','text'),
	(7,'SECTION_DETAIL_PICTURE','N','a:17:{s:5:\"SCALE\";s:1:\"N\";s:5:\"WIDTH\";s:0:\"\";s:6:\"HEIGHT\";s:0:\"\";s:13:\"IGNORE_ERRORS\";s:1:\"N\";s:6:\"METHOD\";s:8:\"resample\";s:11:\"COMPRESSION\";i:95;s:18:\"USE_WATERMARK_TEXT\";s:1:\"N\";s:14:\"WATERMARK_TEXT\";s:0:\"\";s:19:\"WATERMARK_TEXT_FONT\";s:0:\"\";s:20:\"WATERMARK_TEXT_COLOR\";s:0:\"\";s:19:\"WATERMARK_TEXT_SIZE\";s:0:\"\";s:23:\"WATERMARK_TEXT_POSITION\";s:2:\"tl\";s:18:\"USE_WATERMARK_FILE\";s:1:\"N\";s:14:\"WATERMARK_FILE\";s:0:\"\";s:20:\"WATERMARK_FILE_ALPHA\";s:0:\"\";s:23:\"WATERMARK_FILE_POSITION\";s:2:\"tl\";s:20:\"WATERMARK_FILE_ORDER\";N;}'),
	(7,'SECTION_NAME','Y',''),
	(7,'SECTION_PICTURE','N','a:20:{s:11:\"FROM_DETAIL\";s:1:\"N\";s:5:\"SCALE\";s:1:\"N\";s:5:\"WIDTH\";s:0:\"\";s:6:\"HEIGHT\";s:0:\"\";s:13:\"IGNORE_ERRORS\";s:1:\"N\";s:6:\"METHOD\";s:8:\"resample\";s:11:\"COMPRESSION\";i:95;s:18:\"DELETE_WITH_DETAIL\";s:1:\"N\";s:18:\"UPDATE_WITH_DETAIL\";s:1:\"N\";s:18:\"USE_WATERMARK_TEXT\";s:1:\"N\";s:14:\"WATERMARK_TEXT\";s:0:\"\";s:19:\"WATERMARK_TEXT_FONT\";s:0:\"\";s:20:\"WATERMARK_TEXT_COLOR\";s:0:\"\";s:19:\"WATERMARK_TEXT_SIZE\";s:0:\"\";s:23:\"WATERMARK_TEXT_POSITION\";s:2:\"tl\";s:18:\"USE_WATERMARK_FILE\";s:1:\"N\";s:14:\"WATERMARK_FILE\";s:0:\"\";s:20:\"WATERMARK_FILE_ALPHA\";s:0:\"\";s:23:\"WATERMARK_FILE_POSITION\";s:2:\"tl\";s:20:\"WATERMARK_FILE_ORDER\";N;}'),
	(7,'SECTION_XML_ID','N',''),
	(7,'SORT','N','0'),
	(7,'TAGS','N',''),
	(7,'XML_ID','N',''),
	(7,'XML_IMPORT_START_TIME','N',NULL),
	(8,'ACTIVE','Y','Y'),
	(8,'ACTIVE_FROM','N',''),
	(8,'ACTIVE_TO','N',''),
	(8,'CODE','N','a:8:{s:6:\"UNIQUE\";s:1:\"N\";s:15:\"TRANSLITERATION\";s:1:\"N\";s:9:\"TRANS_LEN\";i:100;s:10:\"TRANS_CASE\";s:1:\"L\";s:11:\"TRANS_SPACE\";s:1:\"-\";s:11:\"TRANS_OTHER\";s:1:\"-\";s:9:\"TRANS_EAT\";s:1:\"Y\";s:10:\"USE_GOOGLE\";s:1:\"N\";}'),
	(8,'DETAIL_PICTURE','N','a:17:{s:5:\"SCALE\";s:1:\"N\";s:5:\"WIDTH\";s:0:\"\";s:6:\"HEIGHT\";s:0:\"\";s:13:\"IGNORE_ERRORS\";s:1:\"N\";s:6:\"METHOD\";s:8:\"resample\";s:11:\"COMPRESSION\";i:95;s:18:\"USE_WATERMARK_TEXT\";s:1:\"N\";s:14:\"WATERMARK_TEXT\";s:0:\"\";s:19:\"WATERMARK_TEXT_FONT\";s:0:\"\";s:20:\"WATERMARK_TEXT_COLOR\";s:0:\"\";s:19:\"WATERMARK_TEXT_SIZE\";s:0:\"\";s:23:\"WATERMARK_TEXT_POSITION\";s:2:\"tl\";s:18:\"USE_WATERMARK_FILE\";s:1:\"N\";s:14:\"WATERMARK_FILE\";s:0:\"\";s:20:\"WATERMARK_FILE_ALPHA\";s:0:\"\";s:23:\"WATERMARK_FILE_POSITION\";s:2:\"tl\";s:20:\"WATERMARK_FILE_ORDER\";N;}'),
	(8,'DETAIL_TEXT','N',''),
	(8,'DETAIL_TEXT_TYPE','Y','text'),
	(8,'IBLOCK_SECTION','N',''),
	(8,'LOG_ELEMENT_ADD','N',NULL),
	(8,'LOG_ELEMENT_DELETE','N',NULL),
	(8,'LOG_ELEMENT_EDIT','N',NULL),
	(8,'LOG_SECTION_ADD','N',NULL),
	(8,'LOG_SECTION_DELETE','N',NULL),
	(8,'LOG_SECTION_EDIT','N',NULL),
	(8,'NAME','Y',''),
	(8,'PREVIEW_PICTURE','N','a:20:{s:11:\"FROM_DETAIL\";s:1:\"N\";s:5:\"SCALE\";s:1:\"N\";s:5:\"WIDTH\";s:0:\"\";s:6:\"HEIGHT\";s:0:\"\";s:13:\"IGNORE_ERRORS\";s:1:\"N\";s:6:\"METHOD\";s:8:\"resample\";s:11:\"COMPRESSION\";i:95;s:18:\"DELETE_WITH_DETAIL\";s:1:\"N\";s:18:\"UPDATE_WITH_DETAIL\";s:1:\"N\";s:18:\"USE_WATERMARK_TEXT\";s:1:\"N\";s:14:\"WATERMARK_TEXT\";s:0:\"\";s:19:\"WATERMARK_TEXT_FONT\";s:0:\"\";s:20:\"WATERMARK_TEXT_COLOR\";s:0:\"\";s:19:\"WATERMARK_TEXT_SIZE\";s:0:\"\";s:23:\"WATERMARK_TEXT_POSITION\";s:2:\"tl\";s:18:\"USE_WATERMARK_FILE\";s:1:\"N\";s:14:\"WATERMARK_FILE\";s:0:\"\";s:20:\"WATERMARK_FILE_ALPHA\";s:0:\"\";s:23:\"WATERMARK_FILE_POSITION\";s:2:\"tl\";s:20:\"WATERMARK_FILE_ORDER\";N;}'),
	(8,'PREVIEW_TEXT','N',''),
	(8,'PREVIEW_TEXT_TYPE','Y','text'),
	(8,'SECTION_CODE','N','a:8:{s:6:\"UNIQUE\";s:1:\"N\";s:15:\"TRANSLITERATION\";s:1:\"N\";s:9:\"TRANS_LEN\";i:100;s:10:\"TRANS_CASE\";s:1:\"L\";s:11:\"TRANS_SPACE\";s:1:\"-\";s:11:\"TRANS_OTHER\";s:1:\"-\";s:9:\"TRANS_EAT\";s:1:\"Y\";s:10:\"USE_GOOGLE\";s:1:\"N\";}'),
	(8,'SECTION_DESCRIPTION','N',''),
	(8,'SECTION_DESCRIPTION_TYPE','Y','text'),
	(8,'SECTION_DETAIL_PICTURE','N','a:17:{s:5:\"SCALE\";s:1:\"N\";s:5:\"WIDTH\";s:0:\"\";s:6:\"HEIGHT\";s:0:\"\";s:13:\"IGNORE_ERRORS\";s:1:\"N\";s:6:\"METHOD\";s:8:\"resample\";s:11:\"COMPRESSION\";i:95;s:18:\"USE_WATERMARK_TEXT\";s:1:\"N\";s:14:\"WATERMARK_TEXT\";s:0:\"\";s:19:\"WATERMARK_TEXT_FONT\";s:0:\"\";s:20:\"WATERMARK_TEXT_COLOR\";s:0:\"\";s:19:\"WATERMARK_TEXT_SIZE\";s:0:\"\";s:23:\"WATERMARK_TEXT_POSITION\";s:2:\"tl\";s:18:\"USE_WATERMARK_FILE\";s:1:\"N\";s:14:\"WATERMARK_FILE\";s:0:\"\";s:20:\"WATERMARK_FILE_ALPHA\";s:0:\"\";s:23:\"WATERMARK_FILE_POSITION\";s:2:\"tl\";s:20:\"WATERMARK_FILE_ORDER\";N;}'),
	(8,'SECTION_NAME','Y',''),
	(8,'SECTION_PICTURE','N','a:20:{s:11:\"FROM_DETAIL\";s:1:\"N\";s:5:\"SCALE\";s:1:\"N\";s:5:\"WIDTH\";s:0:\"\";s:6:\"HEIGHT\";s:0:\"\";s:13:\"IGNORE_ERRORS\";s:1:\"N\";s:6:\"METHOD\";s:8:\"resample\";s:11:\"COMPRESSION\";i:95;s:18:\"DELETE_WITH_DETAIL\";s:1:\"N\";s:18:\"UPDATE_WITH_DETAIL\";s:1:\"N\";s:18:\"USE_WATERMARK_TEXT\";s:1:\"N\";s:14:\"WATERMARK_TEXT\";s:0:\"\";s:19:\"WATERMARK_TEXT_FONT\";s:0:\"\";s:20:\"WATERMARK_TEXT_COLOR\";s:0:\"\";s:19:\"WATERMARK_TEXT_SIZE\";s:0:\"\";s:23:\"WATERMARK_TEXT_POSITION\";s:2:\"tl\";s:18:\"USE_WATERMARK_FILE\";s:1:\"N\";s:14:\"WATERMARK_FILE\";s:0:\"\";s:20:\"WATERMARK_FILE_ALPHA\";s:0:\"\";s:23:\"WATERMARK_FILE_POSITION\";s:2:\"tl\";s:20:\"WATERMARK_FILE_ORDER\";N;}'),
	(8,'SECTION_XML_ID','N',''),
	(8,'SORT','N','0'),
	(8,'TAGS','N',''),
	(8,'XML_ID','N',''),
	(8,'XML_IMPORT_START_TIME','N',NULL);

/*!40000 ALTER TABLE `b_iblock_fields` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table b_iblock_group
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_iblock_group`;

CREATE TABLE `b_iblock_group` (
  `IBLOCK_ID` int(11) NOT NULL,
  `GROUP_ID` int(11) NOT NULL,
  `PERMISSION` char(1) COLLATE utf8_unicode_ci NOT NULL,
  UNIQUE KEY `ux_iblock_group_1` (`IBLOCK_ID`,`GROUP_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `b_iblock_group` WRITE;
/*!40000 ALTER TABLE `b_iblock_group` DISABLE KEYS */;

INSERT INTO `b_iblock_group` (`IBLOCK_ID`, `GROUP_ID`, `PERMISSION`)
VALUES
	(1,1,'X'),
	(1,2,'R'),
	(2,1,'X'),
	(2,2,'R'),
	(3,1,'X'),
	(3,2,'R'),
	(4,1,'X'),
	(4,2,'R'),
	(5,1,'X'),
	(5,2,'R'),
	(6,1,'X'),
	(6,2,'R'),
	(7,1,'X'),
	(7,2,'R'),
	(8,1,'X'),
	(8,2,'R');

/*!40000 ALTER TABLE `b_iblock_group` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table b_iblock_iblock_iprop
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_iblock_iblock_iprop`;

CREATE TABLE `b_iblock_iblock_iprop` (
  `IBLOCK_ID` int(11) NOT NULL,
  `IPROP_ID` int(11) NOT NULL,
  `VALUE` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`IBLOCK_ID`,`IPROP_ID`),
  KEY `ix_b_iblock_iblock_iprop_0` (`IPROP_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_iblock_iproperty
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_iblock_iproperty`;

CREATE TABLE `b_iblock_iproperty` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `IBLOCK_ID` int(11) NOT NULL,
  `CODE` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `ENTITY_TYPE` char(1) COLLATE utf8_unicode_ci NOT NULL,
  `ENTITY_ID` int(11) NOT NULL,
  `TEMPLATE` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `ix_b_iblock_iprop_0` (`IBLOCK_ID`,`ENTITY_TYPE`,`ENTITY_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_iblock_messages
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_iblock_messages`;

CREATE TABLE `b_iblock_messages` (
  `IBLOCK_ID` int(18) NOT NULL,
  `MESSAGE_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `MESSAGE_TEXT` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`IBLOCK_ID`,`MESSAGE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `b_iblock_messages` WRITE;
/*!40000 ALTER TABLE `b_iblock_messages` DISABLE KEYS */;

INSERT INTO `b_iblock_messages` (`IBLOCK_ID`, `MESSAGE_ID`, `MESSAGE_TEXT`)
VALUES
	(1,'ELEMENT_ADD','Добавить элемент'),
	(1,'ELEMENT_DELETE','Удалить элемент'),
	(1,'ELEMENT_EDIT','Изменить элемент'),
	(1,'ELEMENT_NAME','Элемент'),
	(1,'ELEMENTS_NAME','Элементы'),
	(1,'SECTION_ADD','Добавить раздел'),
	(1,'SECTION_DELETE','Удалить раздел'),
	(1,'SECTION_EDIT','Изменить раздел'),
	(1,'SECTION_NAME','Раздел'),
	(1,'SECTIONS_NAME','Разделы'),
	(2,'ELEMENT_ADD','Добавить элемент'),
	(2,'ELEMENT_DELETE','Удалить элемент'),
	(2,'ELEMENT_EDIT','Изменить элемент'),
	(2,'ELEMENT_NAME','Элемент'),
	(2,'ELEMENTS_NAME','Элементы'),
	(2,'SECTION_ADD','Добавить раздел'),
	(2,'SECTION_DELETE','Удалить раздел'),
	(2,'SECTION_EDIT','Изменить раздел'),
	(2,'SECTION_NAME','Раздел'),
	(2,'SECTIONS_NAME','Разделы'),
	(3,'ELEMENT_ADD','Добавить элемент'),
	(3,'ELEMENT_DELETE','Удалить элемент'),
	(3,'ELEMENT_EDIT','Изменить элемент'),
	(3,'ELEMENT_NAME','Элемент'),
	(3,'ELEMENTS_NAME','Элементы'),
	(3,'SECTION_ADD','Добавить раздел'),
	(3,'SECTION_DELETE','Удалить раздел'),
	(3,'SECTION_EDIT','Изменить раздел'),
	(3,'SECTION_NAME','Раздел'),
	(3,'SECTIONS_NAME','Разделы'),
	(4,'ELEMENT_ADD','Добавить элемент'),
	(4,'ELEMENT_DELETE','Удалить элемент'),
	(4,'ELEMENT_EDIT','Изменить элемент'),
	(4,'ELEMENT_NAME','Элемент'),
	(4,'ELEMENTS_NAME','Элементы'),
	(4,'SECTION_ADD','Добавить раздел'),
	(4,'SECTION_DELETE','Удалить раздел'),
	(4,'SECTION_EDIT','Изменить раздел'),
	(4,'SECTION_NAME','Раздел'),
	(4,'SECTIONS_NAME','Разделы'),
	(5,'ELEMENT_ADD','Добавить элемент'),
	(5,'ELEMENT_DELETE','Удалить элемент'),
	(5,'ELEMENT_EDIT','Изменить элемент'),
	(5,'ELEMENT_NAME','Элемент'),
	(5,'ELEMENTS_NAME','Элементы'),
	(5,'SECTION_ADD','Добавить раздел'),
	(5,'SECTION_DELETE','Удалить раздел'),
	(5,'SECTION_EDIT','Изменить раздел'),
	(5,'SECTION_NAME','Раздел'),
	(5,'SECTIONS_NAME','Разделы'),
	(6,'ELEMENT_ADD','Добавить элемент'),
	(6,'ELEMENT_DELETE','Удалить элемент'),
	(6,'ELEMENT_EDIT','Изменить элемент'),
	(6,'ELEMENT_NAME','Элемент'),
	(6,'ELEMENTS_NAME','Элементы'),
	(6,'SECTION_ADD','Добавить раздел'),
	(6,'SECTION_DELETE','Удалить раздел'),
	(6,'SECTION_EDIT','Изменить раздел'),
	(6,'SECTION_NAME','Раздел'),
	(6,'SECTIONS_NAME','Разделы'),
	(7,'ELEMENT_ADD','Добавить элемент'),
	(7,'ELEMENT_DELETE','Удалить элемент'),
	(7,'ELEMENT_EDIT','Изменить элемент'),
	(7,'ELEMENT_NAME','Элемент'),
	(7,'ELEMENTS_NAME','Элементы'),
	(7,'SECTION_ADD','Добавить раздел'),
	(7,'SECTION_DELETE','Удалить раздел'),
	(7,'SECTION_EDIT','Изменить раздел'),
	(7,'SECTION_NAME','Раздел'),
	(7,'SECTIONS_NAME','Разделы'),
	(8,'ELEMENT_ADD','Добавить элемент'),
	(8,'ELEMENT_DELETE','Удалить элемент'),
	(8,'ELEMENT_EDIT','Изменить элемент'),
	(8,'ELEMENT_NAME','Элемент'),
	(8,'ELEMENTS_NAME','Элементы'),
	(8,'SECTION_ADD','Добавить раздел'),
	(8,'SECTION_DELETE','Удалить раздел'),
	(8,'SECTION_EDIT','Изменить раздел'),
	(8,'SECTION_NAME','Раздел'),
	(8,'SECTIONS_NAME','Разделы');

/*!40000 ALTER TABLE `b_iblock_messages` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table b_iblock_offers_tmp
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_iblock_offers_tmp`;

CREATE TABLE `b_iblock_offers_tmp` (
  `ID` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `PRODUCT_IBLOCK_ID` int(11) unsigned NOT NULL,
  `OFFERS_IBLOCK_ID` int(11) unsigned NOT NULL,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_iblock_property
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_iblock_property`;

CREATE TABLE `b_iblock_property` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `IBLOCK_ID` int(11) NOT NULL,
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `SORT` int(11) NOT NULL DEFAULT '500',
  `CODE` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DEFAULT_VALUE` text COLLATE utf8_unicode_ci,
  `PROPERTY_TYPE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'S',
  `ROW_COUNT` int(11) NOT NULL DEFAULT '1',
  `COL_COUNT` int(11) NOT NULL DEFAULT '30',
  `LIST_TYPE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'L',
  `MULTIPLE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `XML_ID` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FILE_TYPE` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `MULTIPLE_CNT` int(11) DEFAULT NULL,
  `TMP_ID` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LINK_IBLOCK_ID` int(18) DEFAULT NULL,
  `WITH_DESCRIPTION` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SEARCHABLE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `FILTRABLE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `IS_REQUIRED` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `VERSION` int(11) NOT NULL DEFAULT '1',
  `USER_TYPE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `USER_TYPE_SETTINGS` text COLLATE utf8_unicode_ci,
  `HINT` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ix_iblock_property_1` (`IBLOCK_ID`),
  KEY `ix_iblock_property_3` (`LINK_IBLOCK_ID`),
  KEY `ix_iblock_property_2` (`CODE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `b_iblock_property` WRITE;
/*!40000 ALTER TABLE `b_iblock_property` DISABLE KEYS */;

INSERT INTO `b_iblock_property` (`ID`, `TIMESTAMP_X`, `IBLOCK_ID`, `NAME`, `ACTIVE`, `SORT`, `CODE`, `DEFAULT_VALUE`, `PROPERTY_TYPE`, `ROW_COUNT`, `COL_COUNT`, `LIST_TYPE`, `MULTIPLE`, `XML_ID`, `FILE_TYPE`, `MULTIPLE_CNT`, `TMP_ID`, `LINK_IBLOCK_ID`, `WITH_DESCRIPTION`, `SEARCHABLE`, `FILTRABLE`, `IS_REQUIRED`, `VERSION`, `USER_TYPE`, `USER_TYPE_SETTINGS`, `HINT`)
VALUES
	(1,'2014-07-04 01:08:44',3,'Аббревиатура','Y',500,'SHORT','','S',1,30,'L','N',NULL,'',5,NULL,0,'N','N','N','N',1,NULL,NULL,''),
	(2,'2014-07-04 01:39:18',6,'Ссылка','Y',500,'LINK','','S',1,30,'L','N',NULL,'',5,NULL,0,'N','N','N','N',1,NULL,NULL,''),
	(3,'2014-07-08 19:19:11',7,'Открыт набор?','Y',500,'OPEN','','L',1,30,'C','N',NULL,'',5,NULL,0,'N','N','N','N',1,NULL,NULL,''),
	(4,'2014-07-08 13:05:39',8,'Отдел стажировки','Y',500,'SECTION','','S',1,30,'L','N',NULL,'',5,NULL,0,'N','N','N','N',1,NULL,NULL,''),
	(5,'2014-07-08 13:05:39',8,'Ссылка на подробную информацию','Y',500,'LINK','','S',1,30,'L','N',NULL,'',5,NULL,0,'N','N','N','N',1,NULL,NULL,''),
	(6,'2014-07-08 19:19:11',7,'SVG','Y',500,'SVG','','F',1,30,'L','N',NULL,'',5,NULL,0,'N','N','N','N',1,NULL,NULL,''),
	(7,'2014-07-11 16:15:46',5,'Описание','Y',500,'TITLE','','S',1,30,'L','N',NULL,'',5,NULL,0,'N','N','N','N',1,NULL,NULL,''),
	(8,'2014-07-11 16:15:46',5,'Цвет','Y',500,'COLOR','','L',1,30,'L','N',NULL,'',5,NULL,0,'N','N','N','N',1,NULL,NULL,''),
	(9,'2014-07-11 16:16:20',5,'SVG','Y',500,'SVG','','F',1,30,'L','N',NULL,'',5,NULL,0,'N','N','N','N',1,NULL,NULL,''),
	(10,'2014-07-12 13:35:25',1,'Город','Y',500,'CITY','','E',1,30,'L','N',NULL,'',5,NULL,3,'N','N','N','N',1,'EList','a:4:{s:4:\"size\";i:1;s:5:\"width\";i:0;s:5:\"group\";s:1:\"N\";s:8:\"multiple\";s:1:\"N\";}',''),
	(11,'2014-07-12 13:42:12',1,'Дата мероприятия','Y',500,'DATE',NULL,'S',1,30,'L','N',NULL,'',5,NULL,0,'N','N','N','N',1,'DateTime',NULL,''),
	(12,'2014-07-12 13:42:12',1,'Направление','Y',500,'DIRECTION','','E',1,30,'L','N',NULL,'',5,NULL,5,'N','N','N','N',1,'EList','a:4:{s:4:\"size\";i:1;s:5:\"width\";i:0;s:5:\"group\";s:1:\"N\";s:8:\"multiple\";s:1:\"N\";}',''),
	(13,'2014-07-12 13:42:12',1,'Спикеры','Y',500,'SPEAKERS','','E',1,30,'L','N',NULL,'',5,NULL,2,'N','N','N','N',1,'EAutocomplete','a:9:{s:4:\"VIEW\";s:1:\"A\";s:8:\"SHOW_ADD\";s:1:\"N\";s:9:\"MAX_WIDTH\";i:0;s:10:\"MIN_HEIGHT\";i:24;s:10:\"MAX_HEIGHT\";i:1000;s:7:\"BAN_SYM\";s:2:\",;\";s:7:\"REP_SYM\";s:1:\" \";s:13:\"OTHER_REP_SYM\";s:0:\"\";s:11:\"IBLOCK_MESS\";s:1:\"N\";}',''),
	(14,'2014-07-12 13:42:35',1,'Тип мероприятия','Y',500,'TYPE','','E',1,30,'L','N',NULL,'',5,NULL,4,'N','N','N','N',1,'EList','a:4:{s:4:\"size\";i:1;s:5:\"width\";i:0;s:5:\"group\";s:1:\"N\";s:8:\"multiple\";s:1:\"N\";}','');

/*!40000 ALTER TABLE `b_iblock_property` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table b_iblock_property_enum
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_iblock_property_enum`;

CREATE TABLE `b_iblock_property_enum` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `PROPERTY_ID` int(11) NOT NULL,
  `VALUE` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `DEF` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `SORT` int(11) NOT NULL DEFAULT '500',
  `XML_ID` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `TMP_ID` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ux_iblock_property_enum` (`PROPERTY_ID`,`XML_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `b_iblock_property_enum` WRITE;
/*!40000 ALTER TABLE `b_iblock_property_enum` DISABLE KEYS */;

INSERT INTO `b_iblock_property_enum` (`ID`, `PROPERTY_ID`, `VALUE`, `DEF`, `SORT`, `XML_ID`, `TMP_ID`)
VALUES
	(1,3,'Да','N',500,'Y',NULL),
	(2,8,'Оранжевый','Y',500,'orange',NULL),
	(3,8,'Зеленый','N',500,'green',NULL),
	(4,8,'Фиолетовый','N',500,'violet',NULL),
	(5,8,'Желтый','N',500,'yellow',NULL);

/*!40000 ALTER TABLE `b_iblock_property_enum` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table b_iblock_right
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_iblock_right`;

CREATE TABLE `b_iblock_right` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `IBLOCK_ID` int(11) NOT NULL,
  `GROUP_CODE` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `ENTITY_TYPE` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `ENTITY_ID` int(11) NOT NULL,
  `DO_INHERIT` char(1) COLLATE utf8_unicode_ci NOT NULL,
  `TASK_ID` int(11) NOT NULL,
  `OP_SREAD` char(1) COLLATE utf8_unicode_ci NOT NULL,
  `OP_EREAD` char(1) COLLATE utf8_unicode_ci NOT NULL,
  `XML_ID` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ix_b_iblock_right_iblock_id` (`IBLOCK_ID`,`ENTITY_TYPE`,`ENTITY_ID`),
  KEY `ix_b_iblock_right_group_code` (`GROUP_CODE`,`IBLOCK_ID`),
  KEY `ix_b_iblock_right_entity` (`ENTITY_ID`,`ENTITY_TYPE`),
  KEY `ix_b_iblock_right_op_eread` (`ID`,`OP_EREAD`,`GROUP_CODE`),
  KEY `ix_b_iblock_right_op_sread` (`ID`,`OP_SREAD`,`GROUP_CODE`),
  KEY `ix_b_iblock_right_task_id` (`TASK_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_iblock_rss
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_iblock_rss`;

CREATE TABLE `b_iblock_rss` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `IBLOCK_ID` int(11) NOT NULL,
  `NODE` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `NODE_VALUE` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_iblock_section
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_iblock_section`;

CREATE TABLE `b_iblock_section` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `MODIFIED_BY` int(18) DEFAULT NULL,
  `DATE_CREATE` datetime DEFAULT NULL,
  `CREATED_BY` int(18) DEFAULT NULL,
  `IBLOCK_ID` int(11) NOT NULL,
  `IBLOCK_SECTION_ID` int(11) DEFAULT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `GLOBAL_ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `SORT` int(11) NOT NULL DEFAULT '500',
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `PICTURE` int(18) DEFAULT NULL,
  `LEFT_MARGIN` int(18) DEFAULT NULL,
  `RIGHT_MARGIN` int(18) DEFAULT NULL,
  `DEPTH_LEVEL` int(18) DEFAULT NULL,
  `DESCRIPTION` text COLLATE utf8_unicode_ci,
  `DESCRIPTION_TYPE` char(4) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'text',
  `SEARCHABLE_CONTENT` text COLLATE utf8_unicode_ci,
  `CODE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `XML_ID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TMP_ID` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DETAIL_PICTURE` int(18) DEFAULT NULL,
  `SOCNET_GROUP_ID` int(18) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ix_iblock_section_1` (`IBLOCK_ID`,`IBLOCK_SECTION_ID`),
  KEY `ix_iblock_section_depth_level` (`IBLOCK_ID`,`DEPTH_LEVEL`),
  KEY `ix_iblock_section_left_margin` (`IBLOCK_ID`,`LEFT_MARGIN`,`RIGHT_MARGIN`),
  KEY `ix_iblock_section_right_margin` (`IBLOCK_ID`,`RIGHT_MARGIN`,`LEFT_MARGIN`),
  KEY `ix_iblock_section_code` (`IBLOCK_ID`,`CODE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_iblock_section_element
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_iblock_section_element`;

CREATE TABLE `b_iblock_section_element` (
  `IBLOCK_SECTION_ID` int(11) NOT NULL,
  `IBLOCK_ELEMENT_ID` int(11) NOT NULL,
  `ADDITIONAL_PROPERTY_ID` int(18) DEFAULT NULL,
  UNIQUE KEY `ux_iblock_section_element` (`IBLOCK_SECTION_ID`,`IBLOCK_ELEMENT_ID`,`ADDITIONAL_PROPERTY_ID`),
  KEY `UX_IBLOCK_SECTION_ELEMENT2` (`IBLOCK_ELEMENT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_iblock_section_iprop
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_iblock_section_iprop`;

CREATE TABLE `b_iblock_section_iprop` (
  `IBLOCK_ID` int(11) NOT NULL,
  `SECTION_ID` int(11) NOT NULL,
  `IPROP_ID` int(11) NOT NULL,
  `VALUE` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`SECTION_ID`,`IPROP_ID`),
  KEY `ix_b_iblock_section_iprop_0` (`IPROP_ID`),
  KEY `ix_b_iblock_section_iprop_1` (`IBLOCK_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_iblock_section_property
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_iblock_section_property`;

CREATE TABLE `b_iblock_section_property` (
  `IBLOCK_ID` int(11) NOT NULL,
  `SECTION_ID` int(11) NOT NULL,
  `PROPERTY_ID` int(11) NOT NULL,
  `SMART_FILTER` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`IBLOCK_ID`,`SECTION_ID`,`PROPERTY_ID`),
  KEY `ix_b_iblock_section_property_1` (`PROPERTY_ID`),
  KEY `ix_b_iblock_section_property_2` (`SECTION_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_iblock_section_right
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_iblock_section_right`;

CREATE TABLE `b_iblock_section_right` (
  `IBLOCK_ID` int(11) NOT NULL,
  `SECTION_ID` int(11) NOT NULL,
  `RIGHT_ID` int(11) NOT NULL,
  `IS_INHERITED` char(1) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`RIGHT_ID`,`SECTION_ID`),
  KEY `ix_b_iblock_section_right_1` (`SECTION_ID`,`IBLOCK_ID`),
  KEY `ix_b_iblock_section_right_2` (`IBLOCK_ID`,`RIGHT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_iblock_sequence
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_iblock_sequence`;

CREATE TABLE `b_iblock_sequence` (
  `IBLOCK_ID` int(18) NOT NULL,
  `CODE` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `SEQ_VALUE` int(11) DEFAULT NULL,
  PRIMARY KEY (`IBLOCK_ID`,`CODE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_iblock_site
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_iblock_site`;

CREATE TABLE `b_iblock_site` (
  `IBLOCK_ID` int(18) NOT NULL,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`IBLOCK_ID`,`SITE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `b_iblock_site` WRITE;
/*!40000 ALTER TABLE `b_iblock_site` DISABLE KEYS */;

INSERT INTO `b_iblock_site` (`IBLOCK_ID`, `SITE_ID`)
VALUES
	(1,'s1'),
	(2,'s1'),
	(3,'s1'),
	(4,'s1'),
	(5,'s1'),
	(6,'s1'),
	(7,'s1'),
	(8,'s1');

/*!40000 ALTER TABLE `b_iblock_site` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table b_iblock_type
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_iblock_type`;

CREATE TABLE `b_iblock_type` (
  `ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `SECTIONS` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `EDIT_FILE_BEFORE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `EDIT_FILE_AFTER` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `IN_RSS` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `SORT` int(18) NOT NULL DEFAULT '500',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `b_iblock_type` WRITE;
/*!40000 ALTER TABLE `b_iblock_type` DISABLE KEYS */;

INSERT INTO `b_iblock_type` (`ID`, `SECTIONS`, `EDIT_FILE_BEFORE`, `EDIT_FILE_AFTER`, `IN_RSS`, `SORT`)
VALUES
	('content','Y','','','N',500),
	('events','Y','','','N',500);

/*!40000 ALTER TABLE `b_iblock_type` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table b_iblock_type_lang
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_iblock_type_lang`;

CREATE TABLE `b_iblock_type_lang` (
  `IBLOCK_TYPE_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `LID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `NAME` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `SECTION_NAME` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ELEMENT_NAME` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `b_iblock_type_lang` WRITE;
/*!40000 ALTER TABLE `b_iblock_type_lang` DISABLE KEYS */;

INSERT INTO `b_iblock_type_lang` (`IBLOCK_TYPE_ID`, `LID`, `NAME`, `SECTION_NAME`, `ELEMENT_NAME`)
VALUES
	('events','ru','Мероприятия','',''),
	('events','en','Events','',''),
	('content','ru','Карьера','',''),
	('content','en','Career','','');

/*!40000 ALTER TABLE `b_iblock_type_lang` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table b_lang
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_lang`;

CREATE TABLE `b_lang` (
  `LID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `SORT` int(18) NOT NULL DEFAULT '100',
  `DEF` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `NAME` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `DIR` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `FORMAT_DATE` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FORMAT_DATETIME` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FORMAT_NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `WEEK_START` int(11) DEFAULT NULL,
  `CHARSET` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LANGUAGE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `DOC_ROOT` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DOMAIN_LIMITED` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `SERVER_NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SITE_NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `EMAIL` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CULTURE_ID` int(11) DEFAULT NULL,
  PRIMARY KEY (`LID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `b_lang` WRITE;
/*!40000 ALTER TABLE `b_lang` DISABLE KEYS */;

INSERT INTO `b_lang` (`LID`, `SORT`, `DEF`, `ACTIVE`, `NAME`, `DIR`, `FORMAT_DATE`, `FORMAT_DATETIME`, `FORMAT_NAME`, `WEEK_START`, `CHARSET`, `LANGUAGE_ID`, `DOC_ROOT`, `DOMAIN_LIMITED`, `SERVER_NAME`, `SITE_NAME`, `EMAIL`, `CULTURE_ID`)
VALUES
	('s1',1,'Y','Y','Mars Graduates','/',NULL,NULL,NULL,NULL,NULL,'ru','','N','','','',1);

/*!40000 ALTER TABLE `b_lang` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table b_lang_domain
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_lang_domain`;

CREATE TABLE `b_lang_domain` (
  `LID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `DOMAIN` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`LID`,`DOMAIN`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_language
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_language`;

CREATE TABLE `b_language` (
  `LID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `SORT` int(11) NOT NULL DEFAULT '100',
  `DEF` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `NAME` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `FORMAT_DATE` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FORMAT_DATETIME` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FORMAT_NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `WEEK_START` int(11) DEFAULT NULL,
  `CHARSET` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DIRECTION` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CULTURE_ID` int(11) DEFAULT NULL,
  PRIMARY KEY (`LID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `b_language` WRITE;
/*!40000 ALTER TABLE `b_language` DISABLE KEYS */;

INSERT INTO `b_language` (`LID`, `SORT`, `DEF`, `ACTIVE`, `NAME`, `FORMAT_DATE`, `FORMAT_DATETIME`, `FORMAT_NAME`, `WEEK_START`, `CHARSET`, `DIRECTION`, `CULTURE_ID`)
VALUES
	('en',2,'N','Y','English',NULL,NULL,NULL,NULL,NULL,NULL,2),
	('ru',1,'Y','Y','Russian',NULL,NULL,NULL,NULL,NULL,NULL,1);

/*!40000 ALTER TABLE `b_language` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table b_list_rubric
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_list_rubric`;

CREATE TABLE `b_list_rubric` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `LID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `CODE` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `NAME` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DESCRIPTION` text COLLATE utf8_unicode_ci,
  `SORT` int(11) NOT NULL DEFAULT '100',
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `AUTO` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `DAYS_OF_MONTH` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DAYS_OF_WEEK` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TIMES_OF_DAY` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TEMPLATE` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LAST_EXECUTED` datetime DEFAULT NULL,
  `VISIBLE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `FROM_FIELD` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_medialib_collection
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_medialib_collection`;

CREATE TABLE `b_medialib_collection` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `DESCRIPTION` text COLLATE utf8_unicode_ci,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `DATE_UPDATE` datetime NOT NULL,
  `OWNER_ID` int(11) DEFAULT NULL,
  `PARENT_ID` int(11) DEFAULT NULL,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `KEYWORDS` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ITEMS_COUNT` int(11) DEFAULT NULL,
  `ML_TYPE` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_medialib_collection_item
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_medialib_collection_item`;

CREATE TABLE `b_medialib_collection_item` (
  `COLLECTION_ID` int(11) NOT NULL,
  `ITEM_ID` int(11) NOT NULL,
  PRIMARY KEY (`ITEM_ID`,`COLLECTION_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_medialib_item
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_medialib_item`;

CREATE TABLE `b_medialib_item` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ITEM_TYPE` char(30) COLLATE utf8_unicode_ci NOT NULL,
  `DESCRIPTION` text COLLATE utf8_unicode_ci,
  `DATE_CREATE` datetime NOT NULL,
  `DATE_UPDATE` datetime NOT NULL,
  `SOURCE_ID` int(11) NOT NULL,
  `KEYWORDS` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SEARCHABLE_CONTENT` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_medialib_type
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_medialib_type`;

CREATE TABLE `b_medialib_type` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CODE` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `EXT` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `SYSTEM` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `DESCRIPTION` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `b_medialib_type` WRITE;
/*!40000 ALTER TABLE `b_medialib_type` DISABLE KEYS */;

INSERT INTO `b_medialib_type` (`ID`, `NAME`, `CODE`, `EXT`, `SYSTEM`, `DESCRIPTION`)
VALUES
	(1,'image_name','image','jpg,jpeg,gif,png','Y','image_desc'),
	(2,'video_name','video','flv,mp4,wmv','Y','video_desc'),
	(3,'sound_name','sound','mp3,wma,aac','Y','sound_desc');

/*!40000 ALTER TABLE `b_medialib_type` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table b_module
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_module`;

CREATE TABLE `b_module` (
  `ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `DATE_ACTIVE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `b_module` WRITE;
/*!40000 ALTER TABLE `b_module` DISABLE KEYS */;

INSERT INTO `b_module` (`ID`, `DATE_ACTIVE`)
VALUES
	('bitrix.sitecorporate','2014-07-03 23:56:12'),
	('bitrix.siteinfoportal','2014-07-03 23:56:13'),
	('bitrix.sitepersonal','2014-07-03 23:56:13'),
	('bitrixcloud','2014-07-03 23:56:14'),
	('clouds','2014-07-03 23:56:16'),
	('compression','2014-07-03 23:56:16'),
	('fileman','2014-07-03 23:56:17'),
	('form','2014-07-03 23:56:18'),
	('highloadblock','2014-07-03 23:56:21'),
	('iblock','2014-07-03 23:56:22'),
	('main','2014-07-03 23:56:09'),
	('perfmon','2014-07-03 23:56:25'),
	('photogallery','2014-07-03 23:56:25'),
	('scale','2014-07-03 23:56:26'),
	('search','2014-07-03 23:56:27'),
	('security','2014-07-03 23:56:28'),
	('seo','2014-07-03 23:56:28'),
	('socialservices','2014-07-03 23:56:29'),
	('subscribe','2014-07-03 23:56:29'),
	('vote','2014-07-03 23:56:30');

/*!40000 ALTER TABLE `b_module` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table b_module_group
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_module_group`;

CREATE TABLE `b_module_group` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `MODULE_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `GROUP_ID` int(11) NOT NULL,
  `G_ACCESS` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UK_GROUP_MODULE` (`MODULE_ID`,`GROUP_ID`,`SITE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_module_to_module
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_module_to_module`;

CREATE TABLE `b_module_to_module` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `SORT` int(18) NOT NULL DEFAULT '100',
  `FROM_MODULE_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `MESSAGE_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `TO_MODULE_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `TO_PATH` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TO_CLASS` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TO_METHOD` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TO_METHOD_ARG` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `VERSION` int(18) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ix_module_to_module` (`FROM_MODULE_ID`,`MESSAGE_ID`,`TO_MODULE_ID`,`TO_CLASS`,`TO_METHOD`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `b_module_to_module` WRITE;
/*!40000 ALTER TABLE `b_module_to_module` DISABLE KEYS */;

INSERT INTO `b_module_to_module` (`ID`, `TIMESTAMP_X`, `SORT`, `FROM_MODULE_ID`, `MESSAGE_ID`, `TO_MODULE_ID`, `TO_PATH`, `TO_CLASS`, `TO_METHOD`, `TO_METHOD_ARG`, `VERSION`)
VALUES
	(1,'2014-07-03 23:56:09',100,'iblock','OnIBlockPropertyBuildList','main','/modules/main/tools/prop_userid.php','CIBlockPropertyUserID','GetUserTypeDescription','',1),
	(2,'2014-07-03 23:56:09',100,'main','OnUserDelete','main','/modules/main/classes/mysql/favorites.php','CFavorites','OnUserDelete','',1),
	(3,'2014-07-03 23:56:09',100,'main','OnLanguageDelete','main','/modules/main/classes/mysql/favorites.php','CFavorites','OnLanguageDelete','',1),
	(4,'2014-07-03 23:56:09',100,'main','OnUserDelete','main','','CUserOptions','OnUserDelete','',1),
	(5,'2014-07-03 23:56:09',100,'main','OnChangeFile','main','','CMain','OnChangeFileComponent','',1),
	(6,'2014-07-03 23:56:09',100,'main','OnUserTypeRightsCheck','main','','CUser','UserTypeRightsCheck','',1),
	(7,'2014-07-03 23:56:09',100,'main','OnUserLogin','main','','UpdateTools','CheckUpdates','',1),
	(8,'2014-07-03 23:56:09',100,'main','OnModuleUpdate','main','','UpdateTools','SetUpdateResult','',1),
	(9,'2014-07-03 23:56:09',100,'main','OnUpdateCheck','main','','UpdateTools','SetUpdateError','',1),
	(10,'2014-07-03 23:56:09',100,'main','OnPanelCreate','main','','CUndo','CheckNotifyMessage','',1),
	(11,'2014-07-03 23:56:09',100,'main','OnAfterAddRating','main','','CRatingsComponentsMain','OnAfterAddRating','',1),
	(12,'2014-07-03 23:56:09',100,'main','OnAfterUpdateRating','main','','CRatingsComponentsMain','OnAfterUpdateRating','',1),
	(13,'2014-07-03 23:56:09',100,'main','OnSetRatingsConfigs','main','','CRatingsComponentsMain','OnSetRatingConfigs','',1),
	(14,'2014-07-03 23:56:09',100,'main','OnGetRatingsConfigs','main','','CRatingsComponentsMain','OnGetRatingConfigs','',1),
	(15,'2014-07-03 23:56:09',100,'main','OnGetRatingsObjects','main','','CRatingsComponentsMain','OnGetRatingObject','',1),
	(16,'2014-07-03 23:56:09',100,'main','OnGetRatingContentOwner','main','','CRatingsComponentsMain','OnGetRatingContentOwner','',1),
	(17,'2014-07-03 23:56:09',100,'main','OnAfterAddRatingRule','main','','CRatingRulesMain','OnAfterAddRatingRule','',1),
	(18,'2014-07-03 23:56:09',100,'main','OnAfterUpdateRatingRule','main','','CRatingRulesMain','OnAfterUpdateRatingRule','',1),
	(19,'2014-07-03 23:56:09',100,'main','OnGetRatingRuleObjects','main','','CRatingRulesMain','OnGetRatingRuleObjects','',1),
	(20,'2014-07-03 23:56:09',100,'main','OnGetRatingRuleConfigs','main','','CRatingRulesMain','OnGetRatingRuleConfigs','',1),
	(21,'2014-07-03 23:56:09',100,'main','OnAfterUserAdd','main','','CRatings','OnAfterUserRegister','',1),
	(22,'2014-07-03 23:56:09',100,'main','OnUserDelete','main','','CRatings','OnUserDelete','',1),
	(23,'2014-07-03 23:56:09',100,'main','OnUserDelete','main','','CAccess','OnUserDelete','',1),
	(24,'2014-07-03 23:56:09',100,'main','OnAfterGroupAdd','main','','CGroupAuthProvider','OnAfterGroupAdd','',1),
	(25,'2014-07-03 23:56:09',100,'main','OnBeforeGroupUpdate','main','','CGroupAuthProvider','OnBeforeGroupUpdate','',1),
	(26,'2014-07-03 23:56:09',100,'main','OnBeforeGroupDelete','main','','CGroupAuthProvider','OnBeforeGroupDelete','',1),
	(27,'2014-07-03 23:56:09',100,'main','OnAfterSetUserGroup','main','','CGroupAuthProvider','OnAfterSetUserGroup','',1),
	(28,'2014-07-03 23:56:09',100,'main','OnUserLogin','main','','CGroupAuthProvider','OnUserLogin','',1),
	(29,'2014-07-03 23:56:09',100,'main','OnEventLogGetAuditTypes','main','','CEventMain','GetAuditTypes','',1),
	(30,'2014-07-03 23:56:09',100,'main','OnEventLogGetAuditHandlers','main','','CEventMain','MakeMainObject','',1),
	(31,'2014-07-03 23:56:09',100,'perfmon','OnGetTableSchema','main','','CTableSchema','OnGetTableSchema','',1),
	(32,'2014-07-03 23:56:09',110,'main','OnUserTypeBuildList','main','','CUserTypeString','GetUserTypeDescription','',1),
	(33,'2014-07-03 23:56:09',120,'main','OnUserTypeBuildList','main','','CUserTypeInteger','GetUserTypeDescription','',1),
	(34,'2014-07-03 23:56:09',130,'main','OnUserTypeBuildList','main','','CUserTypeDouble','GetUserTypeDescription','',1),
	(35,'2014-07-03 23:56:09',140,'main','OnUserTypeBuildList','main','','CUserTypeDateTime','GetUserTypeDescription','',1),
	(36,'2014-07-03 23:56:09',145,'main','OnUserTypeBuildList','main','','CUserTypeDate','GetUserTypeDescription','',1),
	(37,'2014-07-03 23:56:09',150,'main','OnUserTypeBuildList','main','','CUserTypeBoolean','GetUserTypeDescription','',1),
	(38,'2014-07-03 23:56:09',160,'main','OnUserTypeBuildList','main','','CUserTypeFile','GetUserTypeDescription','',1),
	(39,'2014-07-03 23:56:09',170,'main','OnUserTypeBuildList','main','','CUserTypeEnum','GetUserTypeDescription','',1),
	(40,'2014-07-03 23:56:09',180,'main','OnUserTypeBuildList','main','','CUserTypeIBlockSection','GetUserTypeDescription','',1),
	(41,'2014-07-03 23:56:09',190,'main','OnUserTypeBuildList','main','','CUserTypeIBlockElement','GetUserTypeDescription','',1),
	(42,'2014-07-03 23:56:09',200,'main','OnUserTypeBuildList','main','','CUserTypeStringFormatted','GetUserTypeDescription','',1),
	(43,'2014-07-03 23:56:12',100,'main','OnBeforeProlog','bitrix.sitecorporate','','CSiteCorporate','ShowPanel','',1),
	(44,'2014-07-03 23:56:13',100,'main','OnBeforeProlog','bitrix.siteinfoportal','','CSiteInfoportal','ShowPanel','',1),
	(45,'2014-07-03 23:56:13',100,'main','OnBeforeProlog','bitrix.sitepersonal','','CSitePersonal','ShowPanel','',1),
	(46,'2014-07-03 23:56:14',100,'main','OnAdminInformerInsertItems','bitrixcloud','','CBitrixCloudCDN','OnAdminInformerInsertItems','',1),
	(47,'2014-07-03 23:56:14',100,'main','OnAdminInformerInsertItems','bitrixcloud','','CBitrixCloudBackup','OnAdminInformerInsertItems','',1),
	(48,'2014-07-03 23:56:14',100,'mobileapp','OnBeforeAdminMobileMenuBuild','bitrixcloud','','CBitrixCloudMobile','OnBeforeAdminMobileMenuBuild','',1),
	(64,'2014-07-03 23:56:16',100,'main','OnEventLogGetAuditTypes','clouds','','CCloudStorage','GetAuditTypes','',1),
	(65,'2014-07-03 23:56:16',100,'main','OnBeforeProlog','clouds','','CCloudStorage','OnBeforeProlog','',1),
	(66,'2014-07-03 23:56:16',100,'main','OnAdminListDisplay','clouds','','CCloudStorage','OnAdminListDisplay','',1),
	(67,'2014-07-03 23:56:16',100,'main','OnBuildGlobalMenu','clouds','','CCloudStorage','OnBuildGlobalMenu','',1),
	(68,'2014-07-03 23:56:16',100,'main','OnFileSave','clouds','','CCloudStorage','OnFileSave','',1),
	(69,'2014-07-03 23:56:16',100,'main','OnGetFileSRC','clouds','','CCloudStorage','OnGetFileSRC','',1),
	(70,'2014-07-03 23:56:16',100,'main','OnFileCopy','clouds','','CCloudStorage','OnFileCopy','',1),
	(71,'2014-07-03 23:56:16',100,'main','OnFileDelete','clouds','','CCloudStorage','OnFileDelete','',1),
	(72,'2014-07-03 23:56:16',100,'main','OnMakeFileArray','clouds','','CCloudStorage','OnMakeFileArray','',1),
	(73,'2014-07-03 23:56:16',100,'main','OnBeforeResizeImage','clouds','','CCloudStorage','OnBeforeResizeImage','',1),
	(74,'2014-07-03 23:56:16',100,'main','OnAfterResizeImage','clouds','','CCloudStorage','OnAfterResizeImage','',1),
	(75,'2014-07-03 23:56:16',100,'clouds','OnGetStorageService','clouds','','CCloudStorageService_AmazonS3','GetObject','',1),
	(76,'2014-07-03 23:56:16',100,'clouds','OnGetStorageService','clouds','','CCloudStorageService_GoogleStorage','GetObject','',1),
	(77,'2014-07-03 23:56:16',100,'clouds','OnGetStorageService','clouds','','CCloudStorageService_OpenStackStorage','GetObject','',1),
	(78,'2014-07-03 23:56:16',100,'clouds','OnGetStorageService','clouds','','CCloudStorageService_RackSpaceCloudFiles','GetObject','',1),
	(79,'2014-07-03 23:56:16',100,'clouds','OnGetStorageService','clouds','','CCloudStorageService_ClodoRU','GetObject','',1),
	(80,'2014-07-03 23:56:16',100,'clouds','OnGetStorageService','clouds','','CCloudStorageService_Selectel','GetObject','',1),
	(81,'2014-07-03 23:56:16',1,'main','OnPageStart','compression','','CCompress','OnPageStart','',1),
	(82,'2014-07-03 23:56:16',10000,'main','OnAfterEpilog','compression','','CCompress','OnAfterEpilog','',1),
	(83,'2014-07-03 23:56:17',100,'main','OnGroupDelete','fileman','','CFileman','OnGroupDelete','',1),
	(84,'2014-07-03 23:56:17',100,'main','OnPanelCreate','fileman','','CFileman','OnPanelCreate','',1),
	(85,'2014-07-03 23:56:17',100,'main','OnModuleUpdate','fileman','','CFileman','OnModuleUpdate','',1),
	(86,'2014-07-03 23:56:17',100,'main','OnModuleInstalled','fileman','','CFileman','ClearComponentsListCache','',1),
	(87,'2014-07-03 23:56:17',100,'iblock','OnIBlockPropertyBuildList','fileman','','CIBlockPropertyMapGoogle','GetUserTypeDescription','',1),
	(88,'2014-07-03 23:56:17',100,'iblock','OnIBlockPropertyBuildList','fileman','','CIBlockPropertyMapYandex','GetUserTypeDescription','',1),
	(89,'2014-07-03 23:56:17',100,'iblock','OnIBlockPropertyBuildList','fileman','','CIBlockPropertyVideo','GetUserTypeDescription','',1),
	(90,'2014-07-03 23:56:17',100,'main','OnUserTypeBuildList','fileman','','CUserTypeVideo','GetUserTypeDescription','',1),
	(91,'2014-07-03 23:56:17',100,'main','OnEventLogGetAuditTypes','fileman','','CEventFileman','GetAuditTypes','',1),
	(92,'2014-07-03 23:56:17',100,'main','OnEventLogGetAuditHandlers','fileman','','CEventFileman','MakeFilemanObject','',1),
	(98,'2014-07-03 23:56:19',100,'iblock','OnIBlockPropertyBuildList','main','/modules/forum/tools/prop_topicid.php','CIBlockPropertyTopicID','GetUserTypeDescription','',1),
	(103,'2014-07-03 23:56:19',100,'socialnetwork','OnSocNetLogFormatEvent','forum','','CForumMessage','OnSocNetLogFormatEvent','',1),
	(104,'2014-07-03 23:56:19',100,'mail','OnGetFilterList','forum','','CForumEMail','OnGetSocNetFilterList','',1),
	(113,'2014-07-03 23:56:21',100,'main','OnBeforeUserTypeAdd','highloadblock','','\\Bitrix\\Highloadblock\\HighloadBlockTable','OnBeforeUserTypeAdd','',1),
	(114,'2014-07-03 23:56:21',100,'main','OnBeforeUserTypeDelete','highloadblock','','\\Bitrix\\Highloadblock\\HighloadBlockTable','OnBeforeUserTypeDelete','',1),
	(115,'2014-07-03 23:56:21',100,'iblock','OnIBlockPropertyBuildList','highloadblock','','CIBlockPropertyDirectory','GetUserTypeDescription','',1),
	(116,'2014-07-03 23:56:22',100,'main','OnGroupDelete','iblock','','CIBlock','OnGroupDelete','',1),
	(117,'2014-07-03 23:56:22',100,'main','OnBeforeLangDelete','iblock','','CIBlock','OnBeforeLangDelete','',1),
	(118,'2014-07-03 23:56:22',100,'main','OnLangDelete','iblock','','CIBlock','OnLangDelete','',1),
	(119,'2014-07-03 23:56:22',100,'main','OnUserTypeRightsCheck','iblock','','CIBlockSection','UserTypeRightsCheck','',1),
	(120,'2014-07-03 23:56:22',100,'search','OnReindex','iblock','','CIBlock','OnSearchReindex','',1),
	(121,'2014-07-03 23:56:22',100,'search','OnSearchGetURL','iblock','','CIBlock','OnSearchGetURL','',1),
	(122,'2014-07-03 23:56:22',100,'main','OnEventLogGetAuditTypes','iblock','','CIBlock','GetAuditTypes','',1),
	(123,'2014-07-03 23:56:22',100,'main','OnEventLogGetAuditHandlers','iblock','','CEventIBlock','MakeIBlockObject','',1),
	(124,'2014-07-03 23:56:22',200,'main','OnGetRatingContentOwner','iblock','','CRatingsComponentsIBlock','OnGetRatingContentOwner','',1),
	(125,'2014-07-03 23:56:22',100,'main','OnTaskOperationsChanged','iblock','','CIBlockRightsStorage','OnTaskOperationsChanged','',1),
	(126,'2014-07-03 23:56:22',100,'main','OnGroupDelete','iblock','','CIBlockRightsStorage','OnGroupDelete','',1),
	(127,'2014-07-03 23:56:22',100,'main','OnUserDelete','iblock','','CIBlockRightsStorage','OnUserDelete','',1),
	(128,'2014-07-03 23:56:22',100,'perfmon','OnGetTableSchema','iblock','','iblock','OnGetTableSchema','',1),
	(129,'2014-07-03 23:56:22',10,'iblock','OnIBlockPropertyBuildList','iblock','','CIBlockProperty','_DateTime_GetUserTypeDescription','',1),
	(130,'2014-07-03 23:56:22',20,'iblock','OnIBlockPropertyBuildList','iblock','','CIBlockProperty','_XmlID_GetUserTypeDescription','',1),
	(131,'2014-07-03 23:56:22',30,'iblock','OnIBlockPropertyBuildList','iblock','','CIBlockProperty','_FileMan_GetUserTypeDescription','',1),
	(132,'2014-07-03 23:56:22',40,'iblock','OnIBlockPropertyBuildList','iblock','','CIBlockProperty','_HTML_GetUserTypeDescription','',1),
	(133,'2014-07-03 23:56:22',50,'iblock','OnIBlockPropertyBuildList','iblock','','CIBlockProperty','_ElementList_GetUserTypeDescription','',1),
	(134,'2014-07-03 23:56:22',60,'iblock','OnIBlockPropertyBuildList','iblock','','CIBlockProperty','_Sequence_GetUserTypeDescription','',1),
	(135,'2014-07-03 23:56:22',70,'iblock','OnIBlockPropertyBuildList','iblock','','CIBlockProperty','_ElementAutoComplete_GetUserTypeDescription','',1),
	(136,'2014-07-03 23:56:22',80,'iblock','OnIBlockPropertyBuildList','iblock','','CIBlockProperty','_SKU_GetUserTypeDescription','',1),
	(138,'2014-07-03 23:56:25',100,'iblock','OnBeforeIBlockElementDelete','photogallery','','CPhotogalleryElement','OnBeforeIBlockElementDelete','',1),
	(139,'2014-07-03 23:56:25',100,'iblock','OnAfterIBlockElementAdd','photogallery','','CPhotogalleryElement','OnAfterIBlockElementAdd','',1),
	(140,'2014-07-03 23:56:25',100,'search','BeforeIndex','photogallery','','CRatingsComponentsPhotogallery','BeforeIndex','',1),
	(141,'2014-07-03 23:56:25',100,'im','OnGetNotifySchema','photogallery','','CPhotogalleryNotifySchema','OnGetNotifySchema','',1),
	(142,'2014-07-03 23:56:26',100,'main','OnEventLogGetAuditTypes','scale','','\\Bitrix\\Scale\\Logger','onEventLogGetAuditTypes','',1),
	(143,'2014-07-03 23:56:27',100,'main','OnChangePermissions','search','','CSearch','OnChangeFilePermissions','',1),
	(144,'2014-07-03 23:56:27',100,'main','OnChangeFile','search','','CSearch','OnChangeFile','',1),
	(145,'2014-07-03 23:56:27',100,'main','OnGroupDelete','search','','CSearch','OnGroupDelete','',1),
	(146,'2014-07-03 23:56:27',100,'main','OnLangDelete','search','','CSearch','OnLangDelete','',1),
	(147,'2014-07-03 23:56:27',100,'main','OnAfterUserUpdate','search','','CSearchUser','OnAfterUserUpdate','',1),
	(148,'2014-07-03 23:56:27',100,'main','OnUserDelete','search','','CSearchUser','DeleteByUserID','',1),
	(149,'2014-07-03 23:56:27',100,'cluster','OnGetTableList','search','','search','OnGetTableList','',1),
	(150,'2014-07-03 23:56:27',100,'perfmon','OnGetTableSchema','search','','search','OnGetTableSchema','',1),
	(151,'2014-07-03 23:56:27',90,'main','OnEpilog','search','','CSearchStatistic','OnEpilog','',1),
	(152,'2014-07-03 23:56:28',100,'main','OnUserDelete','security','','CSecurityUser','OnUserDelete','',1),
	(153,'2014-07-03 23:56:28',100,'main','OnEventLogGetAuditTypes','security','','CSecurityFilter','GetAuditTypes','',1),
	(154,'2014-07-03 23:56:28',100,'main','OnEventLogGetAuditTypes','security','','CSecurityAntiVirus','GetAuditTypes','',1),
	(155,'2014-07-03 23:56:28',100,'main','OnAdminInformerInsertItems','security','','CSecurityFilter','OnAdminInformerInsertItems','',1),
	(156,'2014-07-03 23:56:28',100,'main','OnAdminInformerInsertItems','security','','CSecuritySiteChecker','OnAdminInformerInsertItems','',1),
	(157,'2014-07-03 23:56:28',5,'main','OnBeforeProlog','security','','CSecurityFilter','OnBeforeProlog','',1),
	(158,'2014-07-03 23:56:28',9999,'main','OnEndBufferContent','security','','CSecurityXSSDetect','OnEndBufferContent','',1),
	(159,'2014-07-03 23:56:28',-1,'main','OnPageStart','security','','CSecurityAntiVirus','OnPageStart','',1),
	(160,'2014-07-03 23:56:28',10000,'main','OnEndBufferContent','security','','CSecurityAntiVirus','OnEndBufferContent','',1),
	(161,'2014-07-03 23:56:28',10001,'main','OnAfterEpilog','security','','CSecurityAntiVirus','OnAfterEpilog','',1),
	(162,'2014-07-03 23:56:28',100,'main','OnPanelCreate','seo','','CSeoEventHandlers','SeoOnPanelCreate','',2),
	(163,'2014-07-03 23:56:28',100,'fileman','OnIncludeHTMLEditorScript','seo','','CSeoEventHandlers','OnIncludeHTMLEditorScript','',2),
	(164,'2014-07-03 23:56:28',100,'iblock','OnAfterIBlockSectionAdd','seo','','\\Bitrix\\Seo\\SitemapIblock','addSection','',2),
	(165,'2014-07-03 23:56:28',100,'iblock','OnAfterIBlockElementAdd','seo','','\\Bitrix\\Seo\\SitemapIblock','addElement','',2),
	(166,'2014-07-03 23:56:28',100,'iblock','OnBeforeIBlockSectionDelete','seo','','\\Bitrix\\Seo\\SitemapIblock','beforeDeleteSection','',2),
	(167,'2014-07-03 23:56:28',100,'iblock','OnBeforeIBlockElementDelete','seo','','\\Bitrix\\Seo\\SitemapIblock','beforeDeleteElement','',2),
	(168,'2014-07-03 23:56:28',100,'iblock','OnAfterIBlockSectionDelete','seo','','\\Bitrix\\Seo\\SitemapIblock','deleteSection','',2),
	(169,'2014-07-03 23:56:28',100,'iblock','OnAfterIBlockElementDelete','seo','','\\Bitrix\\Seo\\SitemapIblock','deleteElement','',2),
	(170,'2014-07-03 23:56:28',100,'iblock','OnBeforeIBlockSectionUpdate','seo','','\\Bitrix\\Seo\\SitemapIblock','beforeUpdateSection','',2),
	(171,'2014-07-03 23:56:28',100,'iblock','OnBeforeIBlockElementUpdate','seo','','\\Bitrix\\Seo\\SitemapIblock','beforeUpdateElement','',2),
	(172,'2014-07-03 23:56:28',100,'iblock','OnAfterIBlockSectionUpdate','seo','','\\Bitrix\\Seo\\SitemapIblock','updateSection','',2),
	(173,'2014-07-03 23:56:28',100,'iblock','OnAfterIBlockElementUpdate','seo','','\\Bitrix\\Seo\\SitemapIblock','updateElement','',2),
	(174,'2014-07-03 23:56:28',100,'forum','onAfterTopicAdd','seo','','\\Bitrix\\Seo\\SitemapForum','addTopic','',2),
	(175,'2014-07-03 23:56:28',100,'forum','onAfterTopicUpdate','seo','','\\Bitrix\\Seo\\SitemapForum','updateTopic','',2),
	(176,'2014-07-03 23:56:28',100,'forum','onAfterTopicDelete','seo','','\\Bitrix\\Seo\\SitemapForum','deleteTopic','',2),
	(177,'2014-07-03 23:56:29',100,'main','OnUserDelete','socialservices','','CSocServAuthDB','OnUserDelete','',1),
	(178,'2014-07-03 23:56:29',100,'timeman','OnAfterTMReportDailyAdd','socialservices','','CSocServAuthDB','OnAfterTMReportDailyAdd','',1),
	(179,'2014-07-03 23:56:29',100,'timeman','OnAfterTMDayStart','socialservices','','CSocServAuthDB','OnAfterTMDayStart','',1),
	(180,'2014-07-03 23:56:29',100,'timeman','OnTimeManShow','socialservices','','CSocServEventHandlers','OnTimeManShow','',1),
	(181,'2014-07-03 23:56:29',100,'main','OnBeforeLangDelete','subscribe','','CRubric','OnBeforeLangDelete','',1),
	(182,'2014-07-03 23:56:29',100,'main','OnUserDelete','subscribe','','CSubscription','OnUserDelete','',1),
	(183,'2014-07-03 23:56:29',100,'main','OnUserLogout','subscribe','','CSubscription','OnUserLogout','',1),
	(184,'2014-07-03 23:56:29',100,'main','OnGroupDelete','subscribe','','CPosting','OnGroupDelete','',1),
	(185,'2014-07-03 23:56:30',100,'main','OnBeforeProlog','main','/modules/vote/keepvoting.php','','','',1),
	(186,'2014-07-03 23:56:30',200,'main','OnUserTypeBuildList','vote','','CUserTypeVote','GetUserTypeDescription','',1),
	(187,'2014-07-03 23:56:30',200,'main','OnUserLogin','vote','','CVoteUser','OnUserLogin','',1),
	(188,'2014-07-03 23:56:30',100,'im','OnGetNotifySchema','vote','','CVoteNotifySchema','OnGetNotifySchema','',1),
	(190,'2014-07-13 13:41:11',100,'main','OnEpilog','main','','CHTMLPagesCache','OnEpilog','',1),
	(191,'2014-07-13 13:41:11',100,'main','OnLocalRedirect','main','','CHTMLPagesCache','OnEpilog','',1),
	(192,'2014-07-13 13:41:11',100,'main','OnChangeFile','main','','CHTMLPagesCache','OnChangeFile','',1);

/*!40000 ALTER TABLE `b_module_to_module` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table b_operation
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_operation`;

CREATE TABLE `b_operation` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `MODULE_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `DESCRIPTION` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `BINDING` varchar(50) COLLATE utf8_unicode_ci DEFAULT 'module',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `b_operation` WRITE;
/*!40000 ALTER TABLE `b_operation` DISABLE KEYS */;

INSERT INTO `b_operation` (`ID`, `NAME`, `MODULE_ID`, `DESCRIPTION`, `BINDING`)
VALUES
	(1,'edit_php','main',NULL,'module'),
	(2,'view_own_profile','main',NULL,'module'),
	(3,'edit_own_profile','main',NULL,'module'),
	(4,'view_all_users','main',NULL,'module'),
	(5,'view_groups','main',NULL,'module'),
	(6,'view_tasks','main',NULL,'module'),
	(7,'view_other_settings','main',NULL,'module'),
	(8,'view_subordinate_users','main',NULL,'module'),
	(9,'edit_subordinate_users','main',NULL,'module'),
	(10,'edit_all_users','main',NULL,'module'),
	(11,'edit_groups','main',NULL,'module'),
	(12,'edit_tasks','main',NULL,'module'),
	(13,'edit_other_settings','main',NULL,'module'),
	(14,'cache_control','main',NULL,'module'),
	(15,'lpa_template_edit','main',NULL,'module'),
	(16,'view_event_log','main',NULL,'module'),
	(17,'edit_ratings','main',NULL,'module'),
	(18,'manage_short_uri','main',NULL,'module'),
	(19,'fm_view_permission','main',NULL,'file'),
	(20,'fm_view_file','main',NULL,'file'),
	(21,'fm_view_listing','main',NULL,'file'),
	(22,'fm_edit_existent_folder','main',NULL,'file'),
	(23,'fm_create_new_file','main',NULL,'file'),
	(24,'fm_edit_existent_file','main',NULL,'file'),
	(25,'fm_create_new_folder','main',NULL,'file'),
	(26,'fm_delete_file','main',NULL,'file'),
	(27,'fm_delete_folder','main',NULL,'file'),
	(28,'fm_edit_in_workflow','main',NULL,'file'),
	(29,'fm_rename_file','main',NULL,'file'),
	(30,'fm_rename_folder','main',NULL,'file'),
	(31,'fm_upload_file','main',NULL,'file'),
	(32,'fm_add_to_menu','main',NULL,'file'),
	(33,'fm_download_file','main',NULL,'file'),
	(34,'fm_lpa','main',NULL,'file'),
	(35,'fm_edit_permission','main',NULL,'file'),
	(36,'clouds_browse','clouds',NULL,'module'),
	(37,'clouds_upload','clouds',NULL,'module'),
	(38,'clouds_config','clouds',NULL,'module'),
	(39,'fileman_view_all_settings','fileman','','module'),
	(40,'fileman_edit_menu_types','fileman','','module'),
	(41,'fileman_add_element_to_menu','fileman','','module'),
	(42,'fileman_edit_menu_elements','fileman','','module'),
	(43,'fileman_edit_existent_files','fileman','','module'),
	(44,'fileman_edit_existent_folders','fileman','','module'),
	(45,'fileman_admin_files','fileman','','module'),
	(46,'fileman_admin_folders','fileman','','module'),
	(47,'fileman_view_permissions','fileman','','module'),
	(48,'fileman_edit_all_settings','fileman','','module'),
	(49,'fileman_upload_files','fileman','','module'),
	(50,'fileman_view_file_structure','fileman','','module'),
	(51,'fileman_install_control','fileman','','module'),
	(52,'medialib_view_collection','fileman','','medialib'),
	(53,'medialib_new_collection','fileman','','medialib'),
	(54,'medialib_edit_collection','fileman','','medialib'),
	(55,'medialib_del_collection','fileman','','medialib'),
	(56,'medialib_access','fileman','','medialib'),
	(57,'medialib_new_item','fileman','','medialib'),
	(58,'medialib_edit_item','fileman','','medialib'),
	(59,'medialib_del_item','fileman','','medialib'),
	(60,'sticker_view','fileman','','stickers'),
	(61,'sticker_edit','fileman','','stickers'),
	(62,'sticker_new','fileman','','stickers'),
	(63,'sticker_del','fileman','','stickers'),
	(64,'section_read','iblock',NULL,'iblock'),
	(65,'element_read','iblock',NULL,'iblock'),
	(66,'section_element_bind','iblock',NULL,'iblock'),
	(67,'iblock_admin_display','iblock',NULL,'iblock'),
	(68,'element_edit','iblock',NULL,'iblock'),
	(69,'element_edit_price','iblock',NULL,'iblock'),
	(70,'element_delete','iblock',NULL,'iblock'),
	(71,'element_bizproc_start','iblock',NULL,'iblock'),
	(72,'section_edit','iblock',NULL,'iblock'),
	(73,'section_delete','iblock',NULL,'iblock'),
	(74,'section_section_bind','iblock',NULL,'iblock'),
	(75,'element_edit_any_wf_status','iblock',NULL,'iblock'),
	(76,'iblock_edit','iblock',NULL,'iblock'),
	(77,'iblock_delete','iblock',NULL,'iblock'),
	(78,'iblock_rights_edit','iblock',NULL,'iblock'),
	(79,'iblock_export','iblock',NULL,'iblock'),
	(80,'section_rights_edit','iblock',NULL,'iblock'),
	(81,'element_rights_edit','iblock',NULL,'iblock'),
	(82,'security_filter_bypass','security',NULL,'module'),
	(83,'security_edit_user_otp','security',NULL,'module'),
	(84,'security_module_settings_read','security',NULL,'module'),
	(85,'security_panel_view','security',NULL,'module'),
	(86,'security_filter_settings_read','security',NULL,'module'),
	(87,'security_otp_settings_read','security',NULL,'module'),
	(88,'security_iprule_admin_settings_read','security',NULL,'module'),
	(89,'security_session_settings_read','security',NULL,'module'),
	(90,'security_redirect_settings_read','security',NULL,'module'),
	(91,'security_stat_activity_settings_read','security',NULL,'module'),
	(92,'security_iprule_settings_read','security',NULL,'module'),
	(93,'security_antivirus_settings_read','security',NULL,'module'),
	(94,'security_frame_settings_read','security',NULL,'module'),
	(95,'security_module_settings_write','security',NULL,'module'),
	(96,'security_filter_settings_write','security',NULL,'module'),
	(97,'security_otp_settings_write','security',NULL,'module'),
	(98,'security_iprule_admin_settings_write','security',NULL,'module'),
	(99,'security_session_settings_write','security',NULL,'module'),
	(100,'security_redirect_settings_write','security',NULL,'module'),
	(101,'security_stat_activity_settings_write','security',NULL,'module'),
	(102,'security_iprule_settings_write','security',NULL,'module'),
	(103,'security_file_verifier_sign','security',NULL,'module'),
	(104,'security_file_verifier_collect','security',NULL,'module'),
	(105,'security_file_verifier_verify','security',NULL,'module'),
	(106,'security_antivirus_settings_write','security',NULL,'module'),
	(107,'security_frame_settings_write','security',NULL,'module'),
	(108,'seo_settings','seo','','module'),
	(109,'seo_tools','seo','','module');

/*!40000 ALTER TABLE `b_operation` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table b_option
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_option`;

CREATE TABLE `b_option` (
  `MODULE_ID` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `NAME` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `VALUE` text COLLATE utf8_unicode_ci,
  `DESCRIPTION` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  UNIQUE KEY `ix_option` (`MODULE_ID`,`NAME`,`SITE_ID`),
  KEY `ix_option_name` (`NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `b_option` WRITE;
/*!40000 ALTER TABLE `b_option` DISABLE KEYS */;

INSERT INTO `b_option` (`MODULE_ID`, `NAME`, `VALUE`, `DESCRIPTION`, `SITE_ID`)
VALUES
	('main','rating_authority_rating','2',NULL,NULL),
	('main','rating_assign_rating_group_add','1',NULL,NULL),
	('main','rating_assign_rating_group_delete','1',NULL,NULL),
	('main','rating_assign_rating_group','3',NULL,NULL),
	('main','rating_assign_authority_group_add','2',NULL,NULL),
	('main','rating_assign_authority_group_delete','2',NULL,NULL),
	('main','rating_assign_authority_group','4',NULL,NULL),
	('main','rating_community_size','1',NULL,NULL),
	('main','rating_community_authority','30',NULL,NULL),
	('main','rating_vote_weight','10',NULL,NULL),
	('main','rating_normalization_type','auto',NULL,NULL),
	('main','rating_normalization','10',NULL,NULL),
	('main','rating_count_vote','10',NULL,NULL),
	('main','rating_authority_weight_formula','Y',NULL,NULL),
	('main','rating_community_last_visit','90',NULL,NULL),
	('main','rating_text_like_y','Мне нравится',NULL,NULL),
	('main','rating_text_like_n','Больше не нравится',NULL,NULL),
	('main','rating_text_like_d','Это нравится',NULL,NULL),
	('main','rating_assign_type','auto',NULL,NULL),
	('main','rating_vote_type','like',NULL,NULL),
	('main','rating_self_vote','Y',NULL,NULL),
	('main','rating_vote_show','Y',NULL,NULL),
	('main','rating_vote_template','like',NULL,NULL),
	('main','rating_start_authority','3',NULL,NULL),
	('main','auth_comp2','Y',NULL,NULL),
	('main','PARAM_MAX_SITES','2',NULL,NULL),
	('main','PARAM_MAX_USERS','0',NULL,NULL),
	('main','distributive6','Y',NULL,NULL),
	('main','~new_license11_sign','Y',NULL,NULL),
	('main','GROUP_DEFAULT_TASK','1',NULL,NULL),
	('main','vendor','1c_bitrix',NULL,NULL),
	('main','admin_lid','ru',NULL,NULL),
	('main','update_site','www.bitrixsoft.com',NULL,NULL),
	('main','update_site_ns','Y',NULL,NULL),
	('main','optimize_css_files','Y',NULL,NULL),
	('main','optimize_js_files','Y',NULL,NULL),
	('main','admin_passwordh','FVgQcGYUBgYtCUVcAxcFCgsTAQ==',NULL,NULL),
	('main','server_uniq_id','d034607f29974216491020e2ebe988ab',NULL,NULL),
	('blog','socNetNewPerms','Y',NULL,NULL),
	('fileman','use_editor_3','Y',NULL,NULL),
	('forum','FILTER_DICT_W','1',NULL,'ru'),
	('forum','FILTER_DICT_T','2',NULL,'ru'),
	('forum','FILTER_DICT_W','3',NULL,'en'),
	('forum','FILTER_DICT_T','4',NULL,'en'),
	('forum','FILTER','N',NULL,NULL),
	('search','version','v2.0',NULL,NULL),
	('search','dbnode_id','N',NULL,NULL),
	('search','dbnode_status','ok',NULL,NULL),
	('security','ipcheck_disable_file','/bitrix/modules/ipcheck_disable_afc923acc60bc6fb8ecfbe1497311e85',NULL,NULL),
	('vote','VOTE_DIR','',NULL,NULL),
	('vote','VOTE_COMPATIBLE_OLD_TEMPLATE','N',NULL,NULL),
	('main','email_from','andrey.slider@gmail.com',NULL,NULL),
	('fileman','stickers_use_hotkeys','N',NULL,NULL),
	('main','update_system_check','06.07.2014 13:36:17',NULL,NULL),
	('iblock','use_htmledit','',NULL,NULL),
	('iblock','list_image_size','50',NULL,NULL),
	('iblock','detail_image_size','200',NULL,NULL),
	('iblock','show_xml_id','',NULL,NULL),
	('iblock','path2rss','/upload/',NULL,NULL),
	('iblock','combined_list_mode','Y',NULL,NULL),
	('iblock','iblock_menu_max_sections','50',NULL,NULL),
	('iblock','event_log_iblock','Y',NULL,NULL),
	('iblock','num_catalog_levels','3',NULL,NULL),
	('fileman','GROUP_DEFAULT_TASK','16',NULL,NULL),
	('fileman','default_edit','php',NULL,NULL),
	('fileman','ar_entities','umlya,greek,other',NULL,NULL),
	('fileman','editor_body_id','',NULL,NULL),
	('fileman','editor_body_class','',NULL,NULL),
	('fileman','ml_thumb_width','140',NULL,NULL),
	('fileman','ml_thumb_height','105',NULL,NULL),
	('fileman','ml_media_extentions','jpg,jpeg,gif,png,flv,mp4,wmv,wma,mp3,ppt',NULL,NULL),
	('fileman','ml_max_width','1024',NULL,NULL),
	('fileman','ml_max_height','1024',NULL,NULL),
	('fileman','ml_media_available_ext','jpg,jpeg,gif,png,flv,mp4,wmv,wma,mp3,ppt,aac',NULL,NULL),
	('fileman','ml_use_default','1',NULL,NULL),
	('fileman','~script_files','php,php3,php4,php5,php6,phtml,pl,asp,aspx,cgi,exe,ico,shtm,shtml',NULL,NULL),
	('fileman','~allowed_components','',NULL,NULL),
	('fileman','different_set','N',NULL,NULL),
	('fileman','num_menu_param','1',NULL,NULL),
	('fileman','menutypes','a:2:{s:6:\\\"social\\\";s:29:\\\"Социальные сети\\\";s:3:\\\"top\\\";s:23:\\\"Верхнее меню\\\";}',NULL,NULL),
	('fileman','propstypes','a:2:{s:11:\\\"description\\\";s:16:\\\"Описание\\\";s:8:\\\"keywords\\\";s:27:\\\"Ключевые слова\\\";}',NULL,NULL),
	('fileman','search_max_open_file_size','1024',NULL,NULL),
	('fileman','search_max_res_count','',NULL,NULL),
	('fileman','search_time_step','5',NULL,NULL),
	('fileman','search_mask','*.php',NULL,NULL),
	('fileman','show_inc_icons','N',NULL,NULL),
	('fileman','hide_physical_struc','',NULL,NULL),
	('fileman','use_translit','1',NULL,NULL),
	('fileman','use_translit_google','1',NULL,NULL),
	('fileman','log_menu','Y',NULL,NULL),
	('fileman','log_page','Y',NULL,NULL),
	('fileman','use_code_editor','Y',NULL,NULL),
	('fileman','default_edit_groups','',NULL,NULL),
	('fileman','archive_step_time','30',NULL,NULL),
	('fileman','GROUP_DEFAULT_RIGHT','D',NULL,NULL),
	('main','composite_welcome_screen','N',NULL,NULL);

/*!40000 ALTER TABLE `b_option` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table b_perf_cache
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_perf_cache`;

CREATE TABLE `b_perf_cache` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `HIT_ID` int(18) DEFAULT NULL,
  `COMPONENT_ID` int(18) DEFAULT NULL,
  `NN` int(18) DEFAULT NULL,
  `CACHE_SIZE` float DEFAULT NULL,
  `OP_MODE` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `MODULE_NAME` text COLLATE utf8_unicode_ci,
  `COMPONENT_NAME` text COLLATE utf8_unicode_ci,
  `BASE_DIR` text COLLATE utf8_unicode_ci,
  `INIT_DIR` text COLLATE utf8_unicode_ci,
  `FILE_NAME` text COLLATE utf8_unicode_ci,
  `FILE_PATH` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `IX_B_PERF_CACHE_0` (`HIT_ID`,`NN`),
  KEY `IX_B_PERF_CACHE_1` (`COMPONENT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_perf_cluster
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_perf_cluster`;

CREATE TABLE `b_perf_cluster` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `THREADS` int(11) DEFAULT NULL,
  `HITS` int(11) DEFAULT NULL,
  `ERRORS` int(11) DEFAULT NULL,
  `PAGES_PER_SECOND` float DEFAULT NULL,
  `PAGE_EXEC_TIME` float DEFAULT NULL,
  `PAGE_RESP_TIME` float DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_perf_component
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_perf_component`;

CREATE TABLE `b_perf_component` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `HIT_ID` int(18) DEFAULT NULL,
  `NN` int(18) DEFAULT NULL,
  `CACHE_TYPE` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CACHE_SIZE` int(11) DEFAULT NULL,
  `CACHE_COUNT_R` int(11) DEFAULT NULL,
  `CACHE_COUNT_W` int(11) DEFAULT NULL,
  `CACHE_COUNT_C` int(11) DEFAULT NULL,
  `COMPONENT_TIME` float DEFAULT NULL,
  `QUERIES` int(11) DEFAULT NULL,
  `QUERIES_TIME` float DEFAULT NULL,
  `COMPONENT_NAME` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `IX_B_PERF_COMPONENT_0` (`HIT_ID`,`NN`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_perf_error
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_perf_error`;

CREATE TABLE `b_perf_error` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `HIT_ID` int(18) DEFAULT NULL,
  `ERRNO` int(18) DEFAULT NULL,
  `ERRSTR` text COLLATE utf8_unicode_ci,
  `ERRFILE` text COLLATE utf8_unicode_ci,
  `ERRLINE` int(18) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_B_PERF_ERROR_0` (`HIT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_perf_history
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_perf_history`;

CREATE TABLE `b_perf_history` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `TOTAL_MARK` float DEFAULT NULL,
  `ACCELERATOR_ENABLED` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_perf_hit
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_perf_hit`;

CREATE TABLE `b_perf_hit` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `DATE_HIT` datetime DEFAULT NULL,
  `IS_ADMIN` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `REQUEST_METHOD` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SERVER_NAME` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SERVER_PORT` int(11) DEFAULT NULL,
  `SCRIPT_NAME` text COLLATE utf8_unicode_ci,
  `REQUEST_URI` text COLLATE utf8_unicode_ci,
  `INCLUDED_FILES` int(11) DEFAULT NULL,
  `MEMORY_PEAK_USAGE` int(11) DEFAULT NULL,
  `CACHE_TYPE` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CACHE_SIZE` int(11) DEFAULT NULL,
  `CACHE_COUNT_R` int(11) DEFAULT NULL,
  `CACHE_COUNT_W` int(11) DEFAULT NULL,
  `CACHE_COUNT_C` int(11) DEFAULT NULL,
  `QUERIES` int(11) DEFAULT NULL,
  `QUERIES_TIME` float DEFAULT NULL,
  `COMPONENTS` int(11) DEFAULT NULL,
  `COMPONENTS_TIME` float DEFAULT NULL,
  `SQL_LOG` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PAGE_TIME` float DEFAULT NULL,
  `PROLOG_TIME` float DEFAULT NULL,
  `PROLOG_BEFORE_TIME` float DEFAULT NULL,
  `AGENTS_TIME` float DEFAULT NULL,
  `PROLOG_AFTER_TIME` float DEFAULT NULL,
  `WORK_AREA_TIME` float DEFAULT NULL,
  `EPILOG_TIME` float DEFAULT NULL,
  `EPILOG_BEFORE_TIME` float DEFAULT NULL,
  `EVENTS_TIME` float DEFAULT NULL,
  `EPILOG_AFTER_TIME` float DEFAULT NULL,
  `MENU_RECALC` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_B_PERF_HIT_0` (`DATE_HIT`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_perf_index_ban
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_perf_index_ban`;

CREATE TABLE `b_perf_index_ban` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `BAN_TYPE` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TABLE_NAME` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `COLUMN_NAMES` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_perf_index_complete
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_perf_index_complete`;

CREATE TABLE `b_perf_index_complete` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `BANNED` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TABLE_NAME` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `COLUMN_NAMES` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `INDEX_NAME` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ix_b_perf_index_complete_0` (`TABLE_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_perf_index_suggest
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_perf_index_suggest`;

CREATE TABLE `b_perf_index_suggest` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `SQL_MD5` char(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SQL_COUNT` int(11) DEFAULT NULL,
  `SQL_TIME` float DEFAULT NULL,
  `TABLE_NAME` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TABLE_ALIAS` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `COLUMN_NAMES` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SQL_TEXT` text COLLATE utf8_unicode_ci,
  `SQL_EXPLAIN` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `ix_b_perf_index_suggest_0` (`SQL_MD5`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_perf_index_suggest_sql
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_perf_index_suggest_sql`;

CREATE TABLE `b_perf_index_suggest_sql` (
  `SUGGEST_ID` int(11) NOT NULL DEFAULT '0',
  `SQL_ID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`SUGGEST_ID`,`SQL_ID`),
  KEY `ix_b_perf_index_suggest_sql_0` (`SQL_ID`,`SUGGEST_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_perf_sql
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_perf_sql`;

CREATE TABLE `b_perf_sql` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `HIT_ID` int(18) DEFAULT NULL,
  `COMPONENT_ID` int(18) DEFAULT NULL,
  `NN` int(18) DEFAULT NULL,
  `QUERY_TIME` float DEFAULT NULL,
  `NODE_ID` int(18) DEFAULT NULL,
  `MODULE_NAME` text COLLATE utf8_unicode_ci,
  `COMPONENT_NAME` text COLLATE utf8_unicode_ci,
  `SQL_TEXT` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `IX_B_PERF_SQL_0` (`HIT_ID`,`NN`),
  KEY `IX_B_PERF_SQL_1` (`COMPONENT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_perf_sql_backtrace
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_perf_sql_backtrace`;

CREATE TABLE `b_perf_sql_backtrace` (
  `SQL_ID` int(18) NOT NULL DEFAULT '0',
  `NN` int(18) NOT NULL DEFAULT '0',
  `FILE_NAME` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LINE_NO` int(18) DEFAULT NULL,
  `CLASS_NAME` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FUNCTION_NAME` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`SQL_ID`,`NN`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_perf_tab_column_stat
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_perf_tab_column_stat`;

CREATE TABLE `b_perf_tab_column_stat` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `TABLE_NAME` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `COLUMN_NAME` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TABLE_ROWS` float DEFAULT NULL,
  `COLUMN_ROWS` float DEFAULT NULL,
  `VALUE` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ix_b_perf_tab_column_stat` (`TABLE_NAME`,`COLUMN_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_perf_tab_stat
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_perf_tab_stat`;

CREATE TABLE `b_perf_tab_stat` (
  `TABLE_NAME` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `TABLE_SIZE` float DEFAULT NULL,
  `TABLE_ROWS` float DEFAULT NULL,
  PRIMARY KEY (`TABLE_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_perf_test
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_perf_test`;

CREATE TABLE `b_perf_test` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `REFERENCE_ID` int(18) DEFAULT NULL,
  `NAME` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_B_PERF_TEST_0` (`REFERENCE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_posting
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_posting`;

CREATE TABLE `b_posting` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `STATUS` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'D',
  `VERSION` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DATE_SENT` datetime DEFAULT NULL,
  `SENT_BCC` mediumtext COLLATE utf8_unicode_ci,
  `FROM_FIELD` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `TO_FIELD` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `BCC_FIELD` mediumtext COLLATE utf8_unicode_ci,
  `EMAIL_FILTER` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SUBJECT` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `BODY_TYPE` varchar(4) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'text',
  `BODY` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `DIRECT_SEND` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `CHARSET` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `MSG_CHARSET` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SUBSCR_FORMAT` varchar(4) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ERROR_EMAIL` mediumtext COLLATE utf8_unicode_ci,
  `AUTO_SEND_TIME` datetime DEFAULT NULL,
  `BCC_TO_SEND` mediumtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_posting_email
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_posting_email`;

CREATE TABLE `b_posting_email` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `POSTING_ID` int(11) NOT NULL,
  `STATUS` char(1) COLLATE utf8_unicode_ci NOT NULL,
  `EMAIL` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `SUBSCRIPTION_ID` int(11) DEFAULT NULL,
  `USER_ID` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ix_posting_email_status` (`POSTING_ID`,`STATUS`),
  KEY `ix_posting_email_email` (`POSTING_ID`,`EMAIL`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_posting_file
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_posting_file`;

CREATE TABLE `b_posting_file` (
  `POSTING_ID` int(11) NOT NULL,
  `FILE_ID` int(11) NOT NULL,
  UNIQUE KEY `UK_POSTING_POSTING_FILE` (`POSTING_ID`,`FILE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_posting_group
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_posting_group`;

CREATE TABLE `b_posting_group` (
  `POSTING_ID` int(11) NOT NULL,
  `GROUP_ID` int(11) NOT NULL,
  UNIQUE KEY `UK_POSTING_POSTING_GROUP` (`POSTING_ID`,`GROUP_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_posting_rubric
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_posting_rubric`;

CREATE TABLE `b_posting_rubric` (
  `POSTING_ID` int(11) NOT NULL,
  `LIST_RUBRIC_ID` int(11) NOT NULL,
  UNIQUE KEY `UK_POSTING_POSTING_RUBRIC` (`POSTING_ID`,`LIST_RUBRIC_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_rating
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_rating`;

CREATE TABLE `b_rating` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL,
  `NAME` varchar(512) COLLATE utf8_unicode_ci NOT NULL,
  `ENTITY_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `CALCULATION_METHOD` varchar(3) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'SUM',
  `CREATED` datetime DEFAULT NULL,
  `LAST_MODIFIED` datetime DEFAULT NULL,
  `LAST_CALCULATED` datetime DEFAULT NULL,
  `POSITION` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  `AUTHORITY` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  `CALCULATED` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `CONFIGS` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `b_rating` WRITE;
/*!40000 ALTER TABLE `b_rating` DISABLE KEYS */;

INSERT INTO `b_rating` (`ID`, `ACTIVE`, `NAME`, `ENTITY_ID`, `CALCULATION_METHOD`, `CREATED`, `LAST_MODIFIED`, `LAST_CALCULATED`, `POSITION`, `AUTHORITY`, `CALCULATED`, `CONFIGS`)
VALUES
	(1,'N','Рейтинг','USER','SUM','2014-07-03 23:56:09',NULL,NULL,'Y','N','N','a:3:{s:4:\"MAIN\";a:2:{s:4:\"VOTE\";a:1:{s:4:\"USER\";a:2:{s:11:\"COEFFICIENT\";s:1:\"1\";s:5:\"LIMIT\";s:2:\"30\";}}s:6:\"RATING\";a:1:{s:5:\"BONUS\";a:2:{s:6:\"ACTIVE\";s:1:\"Y\";s:11:\"COEFFICIENT\";s:1:\"1\";}}}s:5:\"FORUM\";a:2:{s:4:\"VOTE\";a:2:{s:5:\"TOPIC\";a:3:{s:6:\"ACTIVE\";s:1:\"Y\";s:11:\"COEFFICIENT\";s:3:\"0.5\";s:5:\"LIMIT\";s:2:\"30\";}s:4:\"POST\";a:3:{s:6:\"ACTIVE\";s:1:\"Y\";s:11:\"COEFFICIENT\";s:3:\"0.1\";s:5:\"LIMIT\";s:2:\"30\";}}s:6:\"RATING\";a:1:{s:8:\"ACTIVITY\";a:9:{s:6:\"ACTIVE\";s:1:\"Y\";s:16:\"TODAY_TOPIC_COEF\";s:3:\"0.4\";s:15:\"WEEK_TOPIC_COEF\";s:3:\"0.2\";s:16:\"MONTH_TOPIC_COEF\";s:3:\"0.1\";s:14:\"ALL_TOPIC_COEF\";s:1:\"0\";s:15:\"TODAY_POST_COEF\";s:3:\"0.2\";s:14:\"WEEK_POST_COEF\";s:3:\"0.1\";s:15:\"MONTH_POST_COEF\";s:4:\"0.05\";s:13:\"ALL_POST_COEF\";s:1:\"0\";}}}s:4:\"BLOG\";a:2:{s:4:\"VOTE\";a:2:{s:4:\"POST\";a:3:{s:6:\"ACTIVE\";s:1:\"Y\";s:11:\"COEFFICIENT\";s:3:\"0.5\";s:5:\"LIMIT\";s:2:\"30\";}s:7:\"COMMENT\";a:3:{s:6:\"ACTIVE\";s:1:\"Y\";s:11:\"COEFFICIENT\";s:3:\"0.1\";s:5:\"LIMIT\";s:2:\"30\";}}s:6:\"RATING\";a:1:{s:8:\"ACTIVITY\";a:9:{s:6:\"ACTIVE\";s:1:\"Y\";s:15:\"TODAY_POST_COEF\";s:3:\"0.4\";s:14:\"WEEK_POST_COEF\";s:3:\"0.2\";s:15:\"MONTH_POST_COEF\";s:3:\"0.1\";s:13:\"ALL_POST_COEF\";s:1:\"0\";s:18:\"TODAY_COMMENT_COEF\";s:3:\"0.2\";s:17:\"WEEK_COMMENT_COEF\";s:3:\"0.1\";s:18:\"MONTH_COMMENT_COEF\";s:4:\"0.05\";s:16:\"ALL_COMMENT_COEF\";s:1:\"0\";}}}}'),
	(2,'N','Авторитет','USER','SUM','2014-07-03 23:56:09',NULL,NULL,'Y','Y','N','a:3:{s:4:\"MAIN\";a:2:{s:4:\"VOTE\";a:1:{s:4:\"USER\";a:3:{s:6:\"ACTIVE\";s:1:\"Y\";s:11:\"COEFFICIENT\";s:1:\"1\";s:5:\"LIMIT\";s:1:\"0\";}}s:6:\"RATING\";a:1:{s:5:\"BONUS\";a:2:{s:6:\"ACTIVE\";s:1:\"Y\";s:11:\"COEFFICIENT\";s:1:\"1\";}}}s:5:\"FORUM\";a:2:{s:4:\"VOTE\";a:2:{s:5:\"TOPIC\";a:2:{s:11:\"COEFFICIENT\";s:1:\"1\";s:5:\"LIMIT\";s:2:\"30\";}s:4:\"POST\";a:2:{s:11:\"COEFFICIENT\";s:1:\"1\";s:5:\"LIMIT\";s:2:\"30\";}}s:6:\"RATING\";a:1:{s:8:\"ACTIVITY\";a:8:{s:16:\"TODAY_TOPIC_COEF\";s:2:\"20\";s:15:\"WEEK_TOPIC_COEF\";s:2:\"10\";s:16:\"MONTH_TOPIC_COEF\";s:1:\"5\";s:14:\"ALL_TOPIC_COEF\";s:1:\"0\";s:15:\"TODAY_POST_COEF\";s:3:\"0.4\";s:14:\"WEEK_POST_COEF\";s:3:\"0.2\";s:15:\"MONTH_POST_COEF\";s:3:\"0.1\";s:13:\"ALL_POST_COEF\";s:1:\"0\";}}}s:4:\"BLOG\";a:2:{s:4:\"VOTE\";a:2:{s:4:\"POST\";a:2:{s:11:\"COEFFICIENT\";s:1:\"1\";s:5:\"LIMIT\";s:2:\"30\";}s:7:\"COMMENT\";a:2:{s:11:\"COEFFICIENT\";s:1:\"1\";s:5:\"LIMIT\";s:2:\"30\";}}s:6:\"RATING\";a:1:{s:8:\"ACTIVITY\";a:8:{s:15:\"TODAY_POST_COEF\";s:3:\"0.4\";s:14:\"WEEK_POST_COEF\";s:3:\"0.2\";s:15:\"MONTH_POST_COEF\";s:3:\"0.1\";s:13:\"ALL_POST_COEF\";s:1:\"0\";s:18:\"TODAY_COMMENT_COEF\";s:3:\"0.2\";s:17:\"WEEK_COMMENT_COEF\";s:3:\"0.1\";s:18:\"MONTH_COMMENT_COEF\";s:4:\"0.05\";s:16:\"ALL_COMMENT_COEF\";s:1:\"0\";}}}}');

/*!40000 ALTER TABLE `b_rating` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table b_rating_component
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_rating_component`;

CREATE TABLE `b_rating_component` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `RATING_ID` int(11) NOT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ENTITY_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `MODULE_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `RATING_TYPE` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `NAME` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `COMPLEX_NAME` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `CLASS` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `CALC_METHOD` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `EXCEPTION_METHOD` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LAST_MODIFIED` datetime DEFAULT NULL,
  `LAST_CALCULATED` datetime DEFAULT NULL,
  `NEXT_CALCULATION` datetime DEFAULT NULL,
  `REFRESH_INTERVAL` int(11) NOT NULL,
  `CONFIG` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `IX_RATING_ID_1` (`RATING_ID`,`ACTIVE`,`NEXT_CALCULATION`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_rating_component_results
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_rating_component_results`;

CREATE TABLE `b_rating_component_results` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `RATING_ID` int(11) NOT NULL,
  `ENTITY_TYPE_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `ENTITY_ID` int(11) NOT NULL,
  `MODULE_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `RATING_TYPE` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `NAME` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `COMPLEX_NAME` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `CURRENT_VALUE` decimal(18,4) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_ENTITY_TYPE_ID` (`ENTITY_TYPE_ID`),
  KEY `IX_COMPLEX_NAME` (`COMPLEX_NAME`),
  KEY `IX_RATING_ID_2` (`RATING_ID`,`COMPLEX_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_rating_prepare
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_rating_prepare`;

CREATE TABLE `b_rating_prepare` (
  `ID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_rating_results
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_rating_results`;

CREATE TABLE `b_rating_results` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `RATING_ID` int(11) NOT NULL,
  `ENTITY_TYPE_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `ENTITY_ID` int(11) NOT NULL,
  `CURRENT_VALUE` decimal(18,4) DEFAULT NULL,
  `PREVIOUS_VALUE` decimal(18,4) DEFAULT NULL,
  `CURRENT_POSITION` int(11) DEFAULT '0',
  `PREVIOUS_POSITION` int(11) DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `IX_RATING_3` (`RATING_ID`,`ENTITY_TYPE_ID`,`ENTITY_ID`),
  KEY `IX_RATING_4` (`RATING_ID`,`ENTITY_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_rating_rule
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_rating_rule`;

CREATE TABLE `b_rating_rule` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `NAME` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `ENTITY_TYPE_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `CONDITION_NAME` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `CONDITION_MODULE` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CONDITION_CLASS` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `CONDITION_METHOD` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `CONDITION_CONFIG` text COLLATE utf8_unicode_ci NOT NULL,
  `ACTION_NAME` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `ACTION_CONFIG` text COLLATE utf8_unicode_ci NOT NULL,
  `ACTIVATE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ACTIVATE_CLASS` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ACTIVATE_METHOD` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `DEACTIVATE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `DEACTIVATE_CLASS` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `DEACTIVATE_METHOD` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `CREATED` datetime DEFAULT NULL,
  `LAST_MODIFIED` datetime DEFAULT NULL,
  `LAST_APPLIED` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `b_rating_rule` WRITE;
/*!40000 ALTER TABLE `b_rating_rule` DISABLE KEYS */;

INSERT INTO `b_rating_rule` (`ID`, `ACTIVE`, `NAME`, `ENTITY_TYPE_ID`, `CONDITION_NAME`, `CONDITION_MODULE`, `CONDITION_CLASS`, `CONDITION_METHOD`, `CONDITION_CONFIG`, `ACTION_NAME`, `ACTION_CONFIG`, `ACTIVATE`, `ACTIVATE_CLASS`, `ACTIVATE_METHOD`, `DEACTIVATE`, `DEACTIVATE_CLASS`, `DEACTIVATE_METHOD`, `CREATED`, `LAST_MODIFIED`, `LAST_APPLIED`)
VALUES
	(1,'N','Добавление в группу пользователей, имеющих право голосовать за рейтинг','USER','AUTHORITY',NULL,'CRatingRulesMain','ratingCheck','a:1:{s:9:\"AUTHORITY\";a:2:{s:16:\"RATING_CONDITION\";i:1;s:12:\"RATING_VALUE\";i:1;}}','ADD_TO_GROUP','a:1:{s:12:\"ADD_TO_GROUP\";a:1:{s:8:\"GROUP_ID\";s:1:\"3\";}}','N','CRatingRulesMain','addToGroup','N','CRatingRulesMain ','addToGroup','2014-07-03 23:56:09','2014-07-03 23:56:09',NULL),
	(2,'N','Удаление из группы пользователей, не имеющих права голосовать за рейтинг','USER','AUTHORITY',NULL,'CRatingRulesMain','ratingCheck','a:1:{s:9:\"AUTHORITY\";a:2:{s:16:\"RATING_CONDITION\";i:2;s:12:\"RATING_VALUE\";i:1;}}','REMOVE_FROM_GROUP','a:1:{s:17:\"REMOVE_FROM_GROUP\";a:1:{s:8:\"GROUP_ID\";s:1:\"3\";}}','N','CRatingRulesMain','removeFromGroup','N','CRatingRulesMain ','removeFromGroup','2014-07-03 23:56:09','2014-07-03 23:56:09',NULL),
	(3,'N','Добавление в группу пользователей, имеющих право голосовать за авторитет','USER','AUTHORITY',NULL,'CRatingRulesMain','ratingCheck','a:1:{s:9:\"AUTHORITY\";a:2:{s:16:\"RATING_CONDITION\";i:1;s:12:\"RATING_VALUE\";i:2;}}','ADD_TO_GROUP','a:1:{s:12:\"ADD_TO_GROUP\";a:1:{s:8:\"GROUP_ID\";s:1:\"4\";}}','N','CRatingRulesMain','addToGroup','N','CRatingRulesMain ','addToGroup','2014-07-03 23:56:09','2014-07-03 23:56:09',NULL),
	(4,'N','Удаление из группы пользователей, не имеющих права голосовать за авторитет','USER','AUTHORITY',NULL,'CRatingRulesMain','ratingCheck','a:1:{s:9:\"AUTHORITY\";a:2:{s:16:\"RATING_CONDITION\";i:2;s:12:\"RATING_VALUE\";i:2;}}','REMOVE_FROM_GROUP','a:1:{s:17:\"REMOVE_FROM_GROUP\";a:1:{s:8:\"GROUP_ID\";s:1:\"4\";}}','N','CRatingRulesMain','removeFromGroup','N','CRatingRulesMain ','removeFromGroup','2014-07-03 23:56:09','2014-07-03 23:56:09',NULL),
	(5,'Y','Автоматическое голосование за авторитет пользователя','USER','VOTE',NULL,'CRatingRulesMain','voteCheck','a:1:{s:4:\"VOTE\";a:6:{s:10:\"VOTE_LIMIT\";i:90;s:11:\"VOTE_RESULT\";i:10;s:16:\"VOTE_FORUM_TOPIC\";d:0.5;s:15:\"VOTE_FORUM_POST\";d:0.1000000000000000055511151231257827021181583404541015625;s:14:\"VOTE_BLOG_POST\";d:0.5;s:17:\"VOTE_BLOG_COMMENT\";d:0.1000000000000000055511151231257827021181583404541015625;}}','empty','a:0:{}','N','empty','empty','N','empty ','empty','2014-07-03 23:56:09','2014-07-03 23:56:09',NULL);

/*!40000 ALTER TABLE `b_rating_rule` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table b_rating_rule_vetting
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_rating_rule_vetting`;

CREATE TABLE `b_rating_rule_vetting` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `RULE_ID` int(11) NOT NULL,
  `ENTITY_TYPE_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `ENTITY_ID` int(11) NOT NULL,
  `ACTIVATE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `APPLIED` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`ID`),
  KEY `RULE_ID` (`RULE_ID`,`ENTITY_TYPE_ID`,`ENTITY_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_rating_user
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_rating_user`;

CREATE TABLE `b_rating_user` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `RATING_ID` int(11) NOT NULL,
  `ENTITY_ID` int(11) NOT NULL,
  `BONUS` decimal(18,4) DEFAULT '0.0000',
  `VOTE_WEIGHT` decimal(18,4) DEFAULT '0.0000',
  `VOTE_COUNT` int(11) DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `RATING_ID` (`RATING_ID`,`ENTITY_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `b_rating_user` WRITE;
/*!40000 ALTER TABLE `b_rating_user` DISABLE KEYS */;

INSERT INTO `b_rating_user` (`ID`, `RATING_ID`, `ENTITY_ID`, `BONUS`, `VOTE_WEIGHT`, `VOTE_COUNT`)
VALUES
	(1,2,1,3.0000,30.0000,13);

/*!40000 ALTER TABLE `b_rating_user` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table b_rating_vote
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_rating_vote`;

CREATE TABLE `b_rating_vote` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `RATING_VOTING_ID` int(11) NOT NULL,
  `ENTITY_TYPE_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `ENTITY_ID` int(11) NOT NULL,
  `OWNER_ID` int(11) NOT NULL,
  `VALUE` decimal(18,4) NOT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL,
  `CREATED` datetime NOT NULL,
  `USER_ID` int(11) NOT NULL,
  `USER_IP` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_RAT_VOTE_ID` (`RATING_VOTING_ID`,`USER_ID`),
  KEY `IX_RAT_VOTE_ID_2` (`ENTITY_TYPE_ID`,`ENTITY_ID`,`USER_ID`),
  KEY `IX_RAT_VOTE_ID_3` (`OWNER_ID`,`CREATED`),
  KEY `IX_RAT_VOTE_ID_4` (`USER_ID`),
  KEY `IX_RAT_VOTE_ID_5` (`CREATED`,`VALUE`),
  KEY `IX_RAT_VOTE_ID_6` (`ACTIVE`),
  KEY `IX_RAT_VOTE_ID_7` (`RATING_VOTING_ID`,`CREATED`),
  KEY `IX_RAT_VOTE_ID_8` (`ENTITY_TYPE_ID`,`CREATED`),
  KEY `IX_RAT_VOTE_ID_9` (`CREATED`,`USER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_rating_vote_group
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_rating_vote_group`;

CREATE TABLE `b_rating_vote_group` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `GROUP_ID` int(11) NOT NULL,
  `TYPE` char(1) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `RATING_ID` (`GROUP_ID`,`TYPE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `b_rating_vote_group` WRITE;
/*!40000 ALTER TABLE `b_rating_vote_group` DISABLE KEYS */;

INSERT INTO `b_rating_vote_group` (`ID`, `GROUP_ID`, `TYPE`)
VALUES
	(5,1,'A'),
	(1,1,'R'),
	(3,1,'R'),
	(2,3,'R'),
	(4,3,'R'),
	(6,4,'A');

/*!40000 ALTER TABLE `b_rating_vote_group` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table b_rating_voting
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_rating_voting`;

CREATE TABLE `b_rating_voting` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ENTITY_TYPE_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `ENTITY_ID` int(11) NOT NULL,
  `OWNER_ID` int(11) NOT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL,
  `CREATED` datetime DEFAULT NULL,
  `LAST_CALCULATED` datetime DEFAULT NULL,
  `TOTAL_VALUE` decimal(18,4) NOT NULL,
  `TOTAL_VOTES` int(11) NOT NULL,
  `TOTAL_POSITIVE_VOTES` int(11) NOT NULL,
  `TOTAL_NEGATIVE_VOTES` int(11) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_ENTITY_TYPE_ID_2` (`ENTITY_TYPE_ID`,`ENTITY_ID`,`ACTIVE`),
  KEY `IX_ENTITY_TYPE_ID_4` (`TOTAL_VALUE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_rating_voting_prepare
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_rating_voting_prepare`;

CREATE TABLE `b_rating_voting_prepare` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `RATING_VOTING_ID` int(11) NOT NULL,
  `TOTAL_VALUE` decimal(18,4) NOT NULL,
  `TOTAL_VOTES` int(11) NOT NULL,
  `TOTAL_POSITIVE_VOTES` int(11) NOT NULL,
  `TOTAL_NEGATIVE_VOTES` int(11) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_RATING_VOTING_ID` (`RATING_VOTING_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_rating_weight
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_rating_weight`;

CREATE TABLE `b_rating_weight` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `RATING_FROM` decimal(18,4) NOT NULL,
  `RATING_TO` decimal(18,4) NOT NULL,
  `WEIGHT` decimal(18,4) DEFAULT '0.0000',
  `COUNT` int(11) DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `b_rating_weight` WRITE;
/*!40000 ALTER TABLE `b_rating_weight` DISABLE KEYS */;

INSERT INTO `b_rating_weight` (`ID`, `RATING_FROM`, `RATING_TO`, `WEIGHT`, `COUNT`)
VALUES
	(1,-1000000.0000,1000000.0000,1.0000,10);

/*!40000 ALTER TABLE `b_rating_weight` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table b_search_content
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_search_content`;

CREATE TABLE `b_search_content` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `DATE_CHANGE` datetime NOT NULL,
  `MODULE_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `ITEM_ID` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `CUSTOM_RANK` int(11) NOT NULL DEFAULT '0',
  `USER_ID` int(11) DEFAULT NULL,
  `ENTITY_TYPE_ID` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ENTITY_ID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `URL` text COLLATE utf8_unicode_ci,
  `TITLE` text COLLATE utf8_unicode_ci,
  `BODY` longtext COLLATE utf8_unicode_ci,
  `TAGS` text COLLATE utf8_unicode_ci,
  `PARAM1` text COLLATE utf8_unicode_ci,
  `PARAM2` text COLLATE utf8_unicode_ci,
  `UPD` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DATE_FROM` datetime DEFAULT NULL,
  `DATE_TO` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UX_B_SEARCH_CONTENT` (`MODULE_ID`,`ITEM_ID`),
  KEY `IX_B_SEARCH_CONTENT_1` (`MODULE_ID`,`PARAM1`(50),`PARAM2`(50)),
  KEY `IX_B_SEARCH_CONTENT_2` (`ENTITY_ID`(50),`ENTITY_TYPE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `b_search_content` WRITE;
/*!40000 ALTER TABLE `b_search_content` DISABLE KEYS */;

INSERT INTO `b_search_content` (`ID`, `DATE_CHANGE`, `MODULE_ID`, `ITEM_ID`, `CUSTOM_RANK`, `USER_ID`, `ENTITY_TYPE_ID`, `ENTITY_ID`, `URL`, `TITLE`, `BODY`, `TAGS`, `PARAM1`, `PARAM2`, `UPD`, `DATE_FROM`, `DATE_TO`)
VALUES
	(1,'2014-07-04 01:33:57','iblock','1',0,NULL,NULL,NULL,'=ID=1&EXTERNAL_ID=1&IBLOCK_SECTION_ID=&IBLOCK_TYPE_ID=events&IBLOCK_ID=4&IBLOCK_CODE=types&IBLOCK_EXTERNAL_ID=&CODE=master-сlass','Мастер-класс','','','events','4',NULL,NULL,NULL),
	(2,'2014-07-04 01:34:25','iblock','2',0,NULL,NULL,NULL,'=ID=2&EXTERNAL_ID=2&IBLOCK_SECTION_ID=&IBLOCK_TYPE_ID=events&IBLOCK_ID=4&IBLOCK_CODE=types&IBLOCK_EXTERNAL_ID=&CODE=seminar','Семинар','','','events','4',NULL,NULL,NULL),
	(3,'2014-07-04 01:34:52','iblock','3',0,NULL,NULL,NULL,'=ID=3&EXTERNAL_ID=3&IBLOCK_SECTION_ID=&IBLOCK_TYPE_ID=events&IBLOCK_ID=4&IBLOCK_CODE=types&IBLOCK_EXTERNAL_ID=&CODE=training-course','Курс тренингов','','','events','4',NULL,NULL,NULL),
	(4,'2014-07-04 01:35:29','iblock','4',0,NULL,NULL,NULL,'=ID=4&EXTERNAL_ID=4&IBLOCK_SECTION_ID=&IBLOCK_TYPE_ID=events&IBLOCK_ID=4&IBLOCK_CODE=types&IBLOCK_EXTERNAL_ID=&CODE=webinar','Вебинар','','','events','4',NULL,NULL,NULL),
	(5,'2014-07-04 01:35:54','iblock','5',0,NULL,NULL,NULL,'=ID=5&EXTERNAL_ID=5&IBLOCK_SECTION_ID=&IBLOCK_TYPE_ID=events&IBLOCK_ID=4&IBLOCK_CODE=types&IBLOCK_EXTERNAL_ID=&CODE=training','Третинг','','','events','4',NULL,NULL,NULL),
	(6,'2014-07-04 01:36:39','iblock','6',0,NULL,NULL,NULL,'=ID=6&EXTERNAL_ID=6&IBLOCK_SECTION_ID=&IBLOCK_TYPE_ID=events&IBLOCK_ID=4&IBLOCK_CODE=types&IBLOCK_EXTERNAL_ID=&CODE=conference','Конференция','','','events','4',NULL,NULL,NULL),
	(7,'2014-07-18 17:13:28','iblock','7',0,NULL,NULL,NULL,'=ID=7&EXTERNAL_ID=7&IBLOCK_SECTION_ID=&IBLOCK_TYPE_ID=content&IBLOCK_ID=7&IBLOCK_CODE=career&IBLOCK_EXTERNAL_ID=&CODE=leadership','Leadreship Development Program','Leadership Development Program - программа развития, которая помогает талантливым сотрудникам становиться настоящими лидерами бизнеса. Программа длится от 2 до 4 лет. Вас ждет уникальный опыт работы в международных проектах, командировки и тренинги, общение с топ-менеджерами компании. Раскройте свой потенциал и станьте руководителем в Mars!','','content','7',NULL,NULL,NULL),
	(8,'2014-07-18 17:22:48','iblock','8',0,NULL,NULL,NULL,'=ID=8&EXTERNAL_ID=8&IBLOCK_SECTION_ID=&IBLOCK_TYPE_ID=content&IBLOCK_ID=7&IBLOCK_CODE=career&IBLOCK_EXTERNAL_ID=&CODE=internship','Mars internship program','Mars Internship Program – это не просто возможность испытать на практике полученные во время учебы знания, это шанс стать частью легендарной команды профессионалов Mars. Хотите глубже познакомиться с выбранной профессией, попробовать себя в решении реальных бизнес-задач и получить массу полезных практических навыков за одно лето? В Mars ваши возможности почти безграничны.','','content','7',NULL,NULL,NULL),
	(10,'2014-07-11 10:55:39','iblock','10',0,NULL,NULL,NULL,'=ID=10&EXTERNAL_ID=10&IBLOCK_SECTION_ID=&IBLOCK_TYPE_ID=content&IBLOCK_ID=8&IBLOCK_CODE=vacancy&IBLOCK_EXTERNAL_ID=&CODE=','Стажер в отдел товарного обеспечения (Ульяновск)','','','content','8',NULL,NULL,NULL),
	(11,'2014-07-18 16:50:53','iblock','11',0,NULL,NULL,NULL,'=ID=11&EXTERNAL_ID=11&IBLOCK_SECTION_ID=&IBLOCK_TYPE_ID=events&IBLOCK_ID=5&IBLOCK_CODE=direction&IBLOCK_EXTERNAL_ID=&CODE=marketing','Маркетинг и продажи','Тебя интересует, как запустить новый продукт и организовать его движение от фабрики до полок магазинов? Как построить правильную коммуникацию с потребителем и сделать бренд сильным и уникальным? Секретами маркетинга и продаж с тобой поделятся профессионалы Mars, работающие с такими звёздами как SNICKERS®, M&M’S®, PEDIGREE®, ORBIT®. Не упусти шанс узнать подробности на лекциях и мастер-классах направления «Маркетинг и Продажи».','','events','5',NULL,NULL,NULL),
	(12,'2014-07-18 16:54:29','iblock','12',0,NULL,NULL,NULL,'=ID=12&EXTERNAL_ID=12&IBLOCK_SECTION_ID=&IBLOCK_TYPE_ID=events&IBLOCK_ID=5&IBLOCK_CODE=direction&IBLOCK_EXTERNAL_ID=&CODE=finans','Финансы и закупки','Все, что ты хотел знать о финансах и закупках, но не знал, у кого спросить! Как организованы финансовые потоки в международной корпорации и как устроена система закупок? Как Mars адаптируется к финансовым особенностям локальных рынков? За что любят и ненавидят финансистов, уважают и боятся специалистов отдела закупок? Самое увлекательное и полезное о столпах FMCG-индустрии — из первых рук!','','events','5',NULL,NULL,NULL),
	(13,'2014-07-18 17:01:50','iblock','13',0,NULL,NULL,NULL,'=ID=13&EXTERNAL_ID=13&IBLOCK_SECTION_ID=&IBLOCK_TYPE_ID=events&IBLOCK_ID=5&IBLOCK_CODE=direction&IBLOCK_EXTERNAL_ID=&CODE=tech','Технологии и производство','Ты узнаешь, как устроено эффективное производство и как глобальные стандарты работают на локальных рынках. Какие технологии использует Mars и почему так много внимания уделяется научным разработкам. Все этапы технологического процесса, от исследований до готового продукта — ни один нюанс не укроется от тебя благодаря захватывающим лекциям и мастер-классам специалистов Mars.','','events','5',NULL,NULL,NULL),
	(14,'2014-07-12 15:38:13','iblock','14',0,NULL,NULL,NULL,'=ID=14&EXTERNAL_ID=14&IBLOCK_SECTION_ID=&IBLOCK_TYPE_ID=events&IBLOCK_ID=5&IBLOCK_CODE=direction&IBLOCK_EXTERNAL_ID=&CODE=razvitie-liderstva','Развитие лидерства','Компания Mars стала одним из гигантов глобального FMCG-рынка во многом благодаря своим лидерам, которых готовит не первое десятилетие. Как ставить прорывные цели, которые органично вплетаются в жизнь компании? Как создать эффективную команду, живущую одним делом?\r\nБыть лидером — это искусство и опыт, которым мы готовы поделиться на лекциях в рамках направления «Развитие лидерства».','','events','5',NULL,NULL,NULL),
	(15,'2014-07-12 13:36:24','iblock','15',0,NULL,NULL,NULL,'=ID=15&EXTERNAL_ID=15&IBLOCK_SECTION_ID=&IBLOCK_TYPE_ID=events&IBLOCK_ID=3&IBLOCK_CODE=citys&IBLOCK_EXTERNAL_ID=&CODE=online','Онлайн','','','events','3',NULL,NULL,NULL),
	(16,'2014-07-12 13:36:39','iblock','16',0,NULL,NULL,NULL,'=ID=16&EXTERNAL_ID=16&IBLOCK_SECTION_ID=&IBLOCK_TYPE_ID=events&IBLOCK_ID=3&IBLOCK_CODE=citys&IBLOCK_EXTERNAL_ID=&CODE=moscow','Москва','','','events','3',NULL,NULL,NULL),
	(17,'2014-07-12 13:37:15','iblock','17',0,NULL,NULL,NULL,'=ID=17&EXTERNAL_ID=17&IBLOCK_SECTION_ID=&IBLOCK_TYPE_ID=events&IBLOCK_ID=3&IBLOCK_CODE=citys&IBLOCK_EXTERNAL_ID=&CODE=petersburg','Санкт-Петербург','','','events','3',NULL,NULL,NULL),
	(18,'2014-07-12 13:38:02','iblock','18',0,NULL,NULL,NULL,'=ID=18&EXTERNAL_ID=18&IBLOCK_SECTION_ID=&IBLOCK_TYPE_ID=events&IBLOCK_ID=3&IBLOCK_CODE=citys&IBLOCK_EXTERNAL_ID=&CODE=irkutsk','Иркутск','','','events','3',NULL,NULL,NULL),
	(19,'2014-07-12 13:38:38','iblock','19',0,NULL,NULL,NULL,'=ID=19&EXTERNAL_ID=19&IBLOCK_SECTION_ID=&IBLOCK_TYPE_ID=events&IBLOCK_ID=3&IBLOCK_CODE=citys&IBLOCK_EXTERNAL_ID=&CODE=krasnodar','Краснодар','','','events','3',NULL,NULL,NULL),
	(20,'2014-07-12 13:38:58','iblock','20',0,NULL,NULL,NULL,'=ID=20&EXTERNAL_ID=20&IBLOCK_SECTION_ID=&IBLOCK_TYPE_ID=events&IBLOCK_ID=3&IBLOCK_CODE=citys&IBLOCK_EXTERNAL_ID=&CODE=novosibirsk','Новосибирск','','','events','3',NULL,NULL,NULL),
	(21,'2014-07-12 13:39:24','iblock','21',0,NULL,NULL,NULL,'=ID=21&EXTERNAL_ID=21&IBLOCK_SECTION_ID=&IBLOCK_TYPE_ID=events&IBLOCK_ID=3&IBLOCK_CODE=citys&IBLOCK_EXTERNAL_ID=&CODE=omsk','Омск','','','events','3',NULL,NULL,NULL),
	(22,'2014-07-12 13:39:45','iblock','22',0,NULL,NULL,NULL,'=ID=22&EXTERNAL_ID=22&IBLOCK_SECTION_ID=&IBLOCK_TYPE_ID=events&IBLOCK_ID=3&IBLOCK_CODE=citys&IBLOCK_EXTERNAL_ID=&CODE=rostov','Ростов-на-дому','','','events','3',NULL,NULL,NULL),
	(23,'2014-07-12 13:40:00','iblock','23',0,NULL,NULL,NULL,'=ID=23&EXTERNAL_ID=23&IBLOCK_SECTION_ID=&IBLOCK_TYPE_ID=events&IBLOCK_ID=3&IBLOCK_CODE=citys&IBLOCK_EXTERNAL_ID=&CODE=samara','Самара','','','events','3',NULL,NULL,NULL),
	(24,'2014-07-12 13:40:18','iblock','24',0,NULL,NULL,NULL,'=ID=24&EXTERNAL_ID=24&IBLOCK_SECTION_ID=&IBLOCK_TYPE_ID=events&IBLOCK_ID=3&IBLOCK_CODE=citys&IBLOCK_EXTERNAL_ID=&CODE=tomsk','Томск','','','events','3',NULL,NULL,NULL),
	(25,'2014-07-12 13:40:38','iblock','25',0,NULL,NULL,NULL,'=ID=25&EXTERNAL_ID=25&IBLOCK_SECTION_ID=&IBLOCK_TYPE_ID=events&IBLOCK_ID=3&IBLOCK_CODE=citys&IBLOCK_EXTERNAL_ID=&CODE=ulyanovsk','Ульяновск','','','events','3',NULL,NULL,NULL),
	(26,'2014-07-12 13:40:50','iblock','26',0,NULL,NULL,NULL,'=ID=26&EXTERNAL_ID=26&IBLOCK_SECTION_ID=&IBLOCK_TYPE_ID=events&IBLOCK_ID=3&IBLOCK_CODE=citys&IBLOCK_EXTERNAL_ID=&CODE=chelyabinsk','Челябинск','','','events','3',NULL,NULL,NULL),
	(27,'2014-07-18 12:41:27','iblock','27',0,NULL,NULL,NULL,'=ID=27&EXTERNAL_ID=27&IBLOCK_SECTION_ID=&IBLOCK_TYPE_ID=events&IBLOCK_ID=1&IBLOCK_CODE=events&IBLOCK_EXTERNAL_ID=&CODE=rol-otdela-r-d-v-fmcg-nauka-i-innovatsii-v-komanii-mars','Роль отдела R&D в FMCG: наука и инновации в комании MARS','','','events','1',NULL,NULL,NULL),
	(28,'2014-07-18 12:41:21','iblock','28',0,NULL,NULL,NULL,'=ID=28&EXTERNAL_ID=28&IBLOCK_SECTION_ID=&IBLOCK_TYPE_ID=events&IBLOCK_ID=1&IBLOCK_CODE=events&IBLOCK_EXTERNAL_ID=&CODE=rol-otdela-finansov-v-fmcg-market-finance','Роль отдела финансов в FMCG. Market Finance','','','events','1',NULL,NULL,NULL);

/*!40000 ALTER TABLE `b_search_content` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table b_search_content_freq
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_search_content_freq`;

CREATE TABLE `b_search_content_freq` (
  `STEM` int(11) NOT NULL DEFAULT '0',
  `LANGUAGE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FREQ` float DEFAULT NULL,
  `TF` float DEFAULT NULL,
  UNIQUE KEY `UX_B_SEARCH_CONTENT_FREQ` (`STEM`,`LANGUAGE_ID`,`SITE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_search_content_param
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_search_content_param`;

CREATE TABLE `b_search_content_param` (
  `SEARCH_CONTENT_ID` int(11) NOT NULL,
  `PARAM_NAME` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `PARAM_VALUE` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  KEY `IX_B_SEARCH_CONTENT_PARAM` (`SEARCH_CONTENT_ID`,`PARAM_NAME`),
  KEY `IX_B_SEARCH_CONTENT_PARAM_1` (`PARAM_NAME`,`PARAM_VALUE`(50),`SEARCH_CONTENT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_search_content_right
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_search_content_right`;

CREATE TABLE `b_search_content_right` (
  `SEARCH_CONTENT_ID` int(11) NOT NULL,
  `GROUP_CODE` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  UNIQUE KEY `UX_B_SEARCH_CONTENT_RIGHT` (`SEARCH_CONTENT_ID`,`GROUP_CODE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `b_search_content_right` WRITE;
/*!40000 ALTER TABLE `b_search_content_right` DISABLE KEYS */;

INSERT INTO `b_search_content_right` (`SEARCH_CONTENT_ID`, `GROUP_CODE`)
VALUES
	(1,'G2'),
	(2,'G2'),
	(3,'G2'),
	(4,'G2'),
	(5,'G2'),
	(6,'G2'),
	(7,'G1'),
	(7,'G2'),
	(8,'G1'),
	(8,'G2'),
	(10,'G2'),
	(11,'G1'),
	(11,'G2'),
	(12,'G1'),
	(12,'G2'),
	(13,'G1'),
	(13,'G2'),
	(14,'G2'),
	(15,'G2'),
	(16,'G2'),
	(17,'G2'),
	(18,'G2'),
	(19,'G2'),
	(20,'G2'),
	(21,'G2'),
	(22,'G2'),
	(23,'G2'),
	(24,'G2'),
	(25,'G2'),
	(26,'G2'),
	(27,'G1'),
	(27,'G2'),
	(28,'G1'),
	(28,'G2');

/*!40000 ALTER TABLE `b_search_content_right` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table b_search_content_site
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_search_content_site`;

CREATE TABLE `b_search_content_site` (
  `SEARCH_CONTENT_ID` int(18) NOT NULL,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `URL` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`SEARCH_CONTENT_ID`,`SITE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `b_search_content_site` WRITE;
/*!40000 ALTER TABLE `b_search_content_site` DISABLE KEYS */;

INSERT INTO `b_search_content_site` (`SEARCH_CONTENT_ID`, `SITE_ID`, `URL`)
VALUES
	(1,'s1',''),
	(2,'s1',''),
	(3,'s1',''),
	(4,'s1',''),
	(5,'s1',''),
	(6,'s1',''),
	(7,'s1',''),
	(8,'s1',''),
	(10,'s1',''),
	(11,'s1',''),
	(12,'s1',''),
	(13,'s1',''),
	(14,'s1',''),
	(15,'s1',''),
	(16,'s1',''),
	(17,'s1',''),
	(18,'s1',''),
	(19,'s1',''),
	(20,'s1',''),
	(21,'s1',''),
	(22,'s1',''),
	(23,'s1',''),
	(24,'s1',''),
	(25,'s1',''),
	(26,'s1',''),
	(27,'s1',''),
	(28,'s1','');

/*!40000 ALTER TABLE `b_search_content_site` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table b_search_content_stem
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_search_content_stem`;

CREATE TABLE `b_search_content_stem` (
  `SEARCH_CONTENT_ID` int(11) NOT NULL,
  `LANGUAGE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `STEM` int(11) NOT NULL,
  `TF` float NOT NULL,
  `PS` float NOT NULL,
  UNIQUE KEY `UX_B_SEARCH_CONTENT_STEM` (`STEM`,`LANGUAGE_ID`,`TF`,`PS`,`SEARCH_CONTENT_ID`),
  KEY `IND_B_SEARCH_CONTENT_STEM` (`SEARCH_CONTENT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci DELAY_KEY_WRITE=1;

LOCK TABLES `b_search_content_stem` WRITE;
/*!40000 ALTER TABLE `b_search_content_stem` DISABLE KEYS */;

INSERT INTO `b_search_content_stem` (`SEARCH_CONTENT_ID`, `LANGUAGE_ID`, `STEM`, `TF`, `PS`)
VALUES
	(1,'ru',1,0.2314,1),
	(2,'ru',2,0.2314,1),
	(3,'ru',3,0.2314,1),
	(3,'ru',4,0.2314,2),
	(3,'ru',5,0.2314,2),
	(4,'ru',6,0.2314,1),
	(5,'ru',7,0.2314,1),
	(6,'ru',8,0.2314,1),
	(7,'ru',5,0.1934,45),
	(7,'ru',9,0.1934,1),
	(7,'ru',10,0.3066,3.5),
	(7,'ru',11,0.3066,4.5),
	(7,'ru',12,0.1934,62),
	(7,'ru',44,0.1934,29),
	(7,'ru',47,0.1934,4),
	(7,'ru',48,0.3066,15.5),
	(7,'ru',49,0.1934,9),
	(7,'ru',50,0.1934,10),
	(7,'ru',51,0.1934,11),
	(7,'ru',52,0.1934,12),
	(7,'ru',53,0.1934,13),
	(7,'ru',54,0.1934,14),
	(7,'ru',55,0.1934,15),
	(7,'ru',56,0.1934,16),
	(7,'ru',57,0.1934,17),
	(7,'ru',58,0.1934,24),
	(7,'ru',59,0.1934,35),
	(7,'ru',60,0.1934,36),
	(7,'ru',61,0.1934,37),
	(7,'ru',62,0.1934,38),
	(7,'ru',63,0.1934,39),
	(7,'ru',64,0.1934,41),
	(7,'ru',65,0.1934,42),
	(7,'ru',66,0.1934,43),
	(7,'ru',67,0.1934,46),
	(7,'ru',68,0.1934,48),
	(7,'ru',69,0.1934,49),
	(7,'ru',70,0.1934,55),
	(7,'ru',71,0.1934,57),
	(7,'ru',72,0.1934,59),
	(7,'ru',73,0.1934,60),
	(8,'ru',11,0.2939,4.5),
	(8,'ru',12,0.4306,22.5),
	(8,'ru',13,0.2939,3.5),
	(8,'ru',14,0.1854,9),
	(8,'ru',15,0.2939,35.5),
	(8,'ru',16,0.1854,11),
	(8,'ru',17,0.1854,13),
	(8,'ru',18,0.1854,14),
	(8,'ru',19,0.1854,16),
	(8,'ru',20,0.1854,17),
	(8,'ru',21,0.1854,18),
	(8,'ru',22,0.1854,20),
	(8,'ru',23,0.1854,21),
	(8,'ru',24,0.1854,22),
	(8,'ru',25,0.1854,23),
	(8,'ru',26,0.1854,24),
	(8,'ru',27,0.1854,25),
	(8,'ru',28,0.1854,25),
	(8,'ru',29,0.1854,33),
	(8,'ru',30,0.1854,34),
	(8,'ru',31,0.1854,36),
	(8,'ru',32,0.1854,37),
	(8,'ru',33,0.1854,38),
	(8,'ru',34,0.1854,41),
	(8,'ru',35,0.1854,42),
	(8,'ru',36,0.1854,43),
	(8,'ru',37,0.1854,45),
	(8,'ru',38,0.1854,46),
	(8,'ru',39,0.1854,47),
	(8,'ru',40,0.1854,48),
	(8,'ru',41,0.1854,49),
	(8,'ru',42,0.1854,49),
	(8,'ru',43,0.1854,51),
	(8,'ru',44,0.1854,52),
	(8,'ru',45,0.1854,62),
	(8,'ru',46,0.1854,63),
	(10,'ru',74,0.2314,1),
	(10,'ru',75,0.2314,3),
	(10,'ru',77,0.2314,6),
	(10,'ru',78,0.2314,4),
	(10,'ru',79,0.2314,5),
	(11,'ru',1,0.1867,74),
	(11,'ru',12,0.1867,49),
	(11,'ru',22,0.1867,68),
	(11,'ru',28,0.1867,48),
	(11,'ru',61,0.1867,35),
	(11,'ru',80,0.3733,39.6667),
	(11,'ru',81,0.3733,41.6667),
	(11,'ru',82,0.1867,5),
	(11,'ru',83,0.1867,7),
	(11,'ru',84,0.1867,8),
	(11,'ru',85,0.1867,9),
	(11,'ru',86,0.1867,11),
	(11,'ru',87,0.1867,13),
	(11,'ru',88,0.1867,15),
	(11,'ru',89,0.1867,17),
	(11,'ru',90,0.1867,18),
	(11,'ru',91,0.1867,18),
	(11,'ru',92,0.1867,25),
	(11,'ru',93,0.1867,26),
	(11,'ru',94,0.1867,27),
	(11,'ru',95,0.1867,29),
	(11,'ru',96,0.1867,31),
	(11,'ru',97,0.1867,32),
	(11,'ru',98,0.1867,33),
	(11,'ru',99,0.1867,41),
	(11,'ru',100,0.1867,46),
	(11,'ru',101,0.1867,47),
	(11,'ru',102,0.1867,50),
	(11,'ru',103,0.1867,53),
	(11,'ru',104,0.1867,55),
	(11,'ru',105,0.1867,59),
	(11,'ru',106,0.1867,60),
	(11,'ru',107,0.1867,67),
	(11,'ru',108,0.1867,69),
	(11,'ru',109,0.1867,70),
	(11,'ru',110,0.1867,72),
	(11,'ru',111,0.1867,75),
	(12,'ru',12,0.1867,42),
	(12,'ru',39,0.1867,74),
	(12,'ru',64,0.1867,29),
	(12,'ru',75,0.1867,64),
	(12,'ru',86,0.1867,25),
	(12,'ru',112,0.3733,18.6667),
	(12,'ru',113,0.2958,7.5),
	(12,'ru',114,0.1867,7),
	(12,'ru',115,0.1867,8),
	(12,'ru',116,0.1867,15),
	(12,'ru',117,0.1867,17),
	(12,'ru',118,0.1867,18),
	(12,'ru',119,0.2958,35.5),
	(12,'ru',120,0.1867,27),
	(12,'ru',121,0.1867,30),
	(12,'ru',122,0.1867,33),
	(12,'ru',123,0.1867,34),
	(12,'ru',124,0.2958,50),
	(12,'ru',125,0.1867,43),
	(12,'ru',126,0.1867,46),
	(12,'ru',127,0.1867,47),
	(12,'ru',128,0.1867,48),
	(12,'ru',129,0.1867,48),
	(12,'ru',130,0.1867,56),
	(12,'ru',131,0.1867,58),
	(12,'ru',132,0.1867,59),
	(12,'ru',133,0.1867,59),
	(12,'ru',134,0.1867,60),
	(12,'ru',135,0.1867,62),
	(12,'ru',136,0.1867,63),
	(12,'ru',137,0.1867,63),
	(12,'ru',138,0.1867,72),
	(12,'ru',139,0.1867,76),
	(12,'ru',140,0.1867,77),
	(12,'ru',141,0.1867,79),
	(12,'ru',142,0.1867,80),
	(13,'ru',1,0.1934,60),
	(13,'ru',12,0.3066,44),
	(13,'ru',85,0.1934,48),
	(13,'ru',102,0.1934,14),
	(13,'ru',108,0.1934,5),
	(13,'ru',110,0.1934,58),
	(13,'ru',122,0.1934,7),
	(13,'ru',127,0.1934,16),
	(13,'ru',129,0.1934,17),
	(13,'ru',136,0.1934,61),
	(13,'ru',137,0.1934,61),
	(13,'ru',143,0.3066,12.5),
	(13,'ru',144,0.3066,6),
	(13,'ru',145,0.1934,8),
	(13,'ru',146,0.1934,12),
	(13,'ru',147,0.1934,13),
	(13,'ru',148,0.1934,25),
	(13,'ru',149,0.1934,28),
	(13,'ru',150,0.1934,30),
	(13,'ru',151,0.1934,31),
	(13,'ru',152,0.1934,32),
	(13,'ru',153,0.1934,33),
	(13,'ru',154,0.1934,34),
	(13,'ru',155,0.1934,41),
	(13,'ru',156,0.1934,42),
	(13,'ru',157,0.1934,43),
	(13,'ru',158,0.1934,45),
	(13,'ru',159,0.1934,47),
	(13,'ru',160,0.1934,50),
	(13,'ru',161,0.1934,51),
	(13,'ru',162,0.1934,53),
	(13,'ru',163,0.1934,56),
	(13,'ru',164,0.1934,57),
	(14,'ru',12,0.1854,4),
	(14,'ru',26,0.1854,44),
	(14,'ru',43,0.2939,26),
	(14,'ru',49,0.2939,34.5),
	(14,'ru',50,0.3709,35),
	(14,'ru',56,0.2939,34.5),
	(14,'ru',62,0.1854,58),
	(14,'ru',69,0.2939,19),
	(14,'ru',101,0.1854,62),
	(14,'ru',110,0.1854,64),
	(14,'ru',111,0.1854,67),
	(14,'ru',141,0.1854,19),
	(14,'ru',145,0.1854,43),
	(14,'ru',146,0.1854,9),
	(14,'ru',150,0.1854,12),
	(14,'ru',159,0.2939,39),
	(14,'ru',163,0.1854,13),
	(14,'ru',165,0.2939,35.5),
	(14,'ru',166,0.1854,5),
	(14,'ru',167,0.1854,8),
	(14,'ru',168,0.1854,8),
	(14,'ru',169,0.1854,10),
	(14,'ru',170,0.1854,20),
	(14,'ru',171,0.1854,27),
	(14,'ru',172,0.1854,28),
	(14,'ru',173,0.1854,29),
	(14,'ru',174,0.1854,31),
	(14,'ru',175,0.1854,32),
	(14,'ru',176,0.1854,34),
	(14,'ru',177,0.1854,42),
	(14,'ru',178,0.1854,45),
	(14,'ru',179,0.1854,47),
	(14,'ru',180,0.1854,56),
	(14,'ru',181,0.1854,66),
	(15,'ru',182,0.2314,1),
	(16,'ru',183,0.2314,1),
	(17,'ru',184,0.2314,1),
	(18,'ru',185,0.2314,1),
	(19,'ru',186,0.2314,1),
	(20,'ru',187,0.2314,1),
	(21,'ru',188,0.2314,1),
	(22,'ru',189,0.2314,1),
	(23,'ru',190,0.2314,1),
	(24,'ru',191,0.2314,1),
	(25,'ru',77,0.2314,1),
	(26,'ru',192,0.2314,1),
	(27,'ru',12,0.2314,12),
	(27,'ru',75,0.2314,2),
	(27,'ru',193,0.2314,1),
	(27,'ru',194,0.2314,6),
	(27,'ru',195,0.2314,7),
	(27,'ru',196,0.2314,9),
	(27,'ru',197,0.2314,11),
	(28,'ru',75,0.2314,2),
	(28,'ru',112,0.2314,3),
	(28,'ru',119,0.2314,3),
	(28,'ru',193,0.2314,1),
	(28,'ru',194,0.2314,5),
	(28,'ru',198,0.2314,11),
	(28,'ru',199,0.2314,12);

/*!40000 ALTER TABLE `b_search_content_stem` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table b_search_content_text
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_search_content_text`;

CREATE TABLE `b_search_content_text` (
  `SEARCH_CONTENT_ID` int(11) NOT NULL,
  `SEARCH_CONTENT_MD5` char(32) COLLATE utf8_unicode_ci NOT NULL,
  `SEARCHABLE_CONTENT` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`SEARCH_CONTENT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `b_search_content_text` WRITE;
/*!40000 ALTER TABLE `b_search_content_text` DISABLE KEYS */;

INSERT INTO `b_search_content_text` (`SEARCH_CONTENT_ID`, `SEARCH_CONTENT_MD5`, `SEARCHABLE_CONTENT`)
VALUES
	(1,'4c013664f6256f34dfd5f453f75510f8','МАСТЕР-КЛАСС\r\n\r\n'),
	(2,'8012f3896e85cb6d246784e681a3e402','СЕМИНАР\r\n\r\n'),
	(3,'9bf31c3d30127169132b20638f46bb6b','КУРС ТРЕНИНГОВ\r\n\r\n'),
	(4,'f8699baca9fe39e0dd40c2104e228fa7','ВЕБИНАР\r\n\r\n'),
	(5,'ed5834ef90207479921bf8a69536027e','ТРЕТИНГ\r\n\r\n'),
	(6,'968bf1ccf1355f24fccc7521d645a8fb','КОНФЕРЕНЦИЯ\r\n\r\n'),
	(7,'50c47f9a7ba8a2689b5300e49636d094','LEADRESHIP DEVELOPMENT PROGRAM\r\nLEADERSHIP DEVELOPMENT PROGRAM - ПРОГРАММА РАЗВИТИЯ, КОТОРАЯ ПОМОГАЕТ ТАЛАНТЛИВЫМ СОТРУДНИКАМ СТАНОВИТЬСЯ НАСТОЯЩИМИ ЛИДЕРАМИ БИЗНЕСА. ПРОГРАММА ДЛИТСЯ ОТ 2 ДО 4 ЛЕТ. ВАС ЖДЕТ УНИКАЛЬНЫЙ ОПЫТ РАБОТЫ В МЕЖДУНАРОДНЫХ ПРОЕКТАХ, КОМАНДИРОВКИ И ТРЕНИНГИ, ОБЩЕНИЕ С ТОП-МЕНЕДЖЕРАМИ КОМПАНИИ. РАСКРОЙТЕ СВОЙ ПОТЕНЦИАЛ И СТАНЬТЕ РУКОВОДИТЕЛЕМ В MARS!\r\n'),
	(8,'55e5c39f650518528a80a78906838147','MARS INTERNSHIP PROGRAM\r\nMARS INTERNSHIP PROGRAM – ЭТО НЕ ПРОСТО ВОЗМОЖНОСТЬ ИСПЫТАТЬ НА ПРАКТИКЕ ПОЛУЧЕННЫЕ ВО ВРЕМЯ УЧЕБЫ ЗНАНИЯ, ЭТО ШАНС СТАТЬ ЧАСТЬЮ ЛЕГЕНДАРНОЙ КОМАНДЫ ПРОФЕССИОНАЛОВ MARS. ХОТИТЕ ГЛУБЖЕ ПОЗНАКОМИТЬСЯ С ВЫБРАННОЙ ПРОФЕССИЕЙ, ПОПРОБОВАТЬ СЕБЯ В РЕШЕНИИ РЕАЛЬНЫХ БИЗНЕС-ЗАДАЧ И ПОЛУЧИТЬ МАССУ ПОЛЕЗНЫХ ПРАКТИЧЕСКИХ НАВЫКОВ ЗА ОДНО ЛЕТО? В MARS ВАШИ ВОЗМОЖНОСТИ ПОЧТИ БЕЗГРАНИЧНЫ.\r\n'),
	(10,'6ddb7100484ce24a566d639434f5c5bf','СТАЖЕР В ОТДЕЛ ТОВАРНОГО ОБЕСПЕЧЕНИЯ (УЛЬЯНОВСК)\r\n\r\n'),
	(11,'8f1085c2cac3c88ecea0186c2985e270','МАРКЕТИНГ И ПРОДАЖИ\r\nТЕБЯ ИНТЕРЕСУЕТ, КАК ЗАПУСТИТЬ НОВЫЙ ПРОДУКТ И ОРГАНИЗОВАТЬ ЕГО ДВИЖЕНИЕ ОТ ФАБРИКИ ДО ПОЛОК МАГАЗИНОВ? КАК ПОСТРОИТЬ ПРАВИЛЬНУЮ КОММУНИКАЦИЮ С ПОТРЕБИТЕЛЕМ И СДЕЛАТЬ БРЕНД СИЛЬНЫМ И УНИКАЛЬНЫМ? СЕКРЕТАМИ МАРКЕТИНГА И ПРОДАЖ С ТОБОЙ ПОДЕЛЯТСЯ ПРОФЕССИОНАЛЫ MARS, РАБОТАЮЩИЕ С ТАКИМИ ЗВЁЗДАМИ КАК SNICKERS®, M&M’S®, PEDIGREE®, ORBIT®. НЕ УПУСТИ ШАНС УЗНАТЬ ПОДРОБНОСТИ НА ЛЕКЦИЯХ И МАСТЕР-КЛАССАХ НАПРАВЛЕНИЯ «МАРКЕТИНГ И ПРОДАЖИ».\r\n'),
	(12,'f844d6b63a5760cce4d1f3b8977f809b','ФИНАНСЫ И ЗАКУПКИ\r\nВСЕ, ЧТО ТЫ ХОТЕЛ ЗНАТЬ О ФИНАНСАХ И ЗАКУПКАХ, НО НЕ ЗНАЛ, У КОГО СПРОСИТЬ! КАК ОРГАНИЗОВАНЫ ФИНАНСОВЫЕ ПОТОКИ В МЕЖДУНАРОДНОЙ КОРПОРАЦИИ И КАК УСТРОЕНА СИСТЕМА ЗАКУПОК? КАК MARS АДАПТИРУЕТСЯ К ФИНАНСОВЫМ ОСОБЕННОСТЯМ ЛОКАЛЬНЫХ РЫНКОВ? ЗА ЧТО ЛЮБЯТ И НЕНАВИДЯТ ФИНАНСИСТОВ, УВАЖАЮТ И БОЯТСЯ СПЕЦИАЛИСТОВ ОТДЕЛА ЗАКУПОК? САМОЕ УВЛЕКАТЕЛЬНОЕ И ПОЛЕЗНОЕ О СТОЛПАХ FMCG-ИНДУСТРИИ — ИЗ ПЕРВЫХ РУК!\r\n'),
	(13,'3c5449358cef595a90e74d4c873195a8','ТЕХНОЛОГИИ И ПРОИЗВОДСТВО\r\nТЫ УЗНАЕШЬ, КАК УСТРОЕНО ЭФФЕКТИВНОЕ ПРОИЗВОДСТВО И КАК ГЛОБАЛЬНЫЕ СТАНДАРТЫ РАБОТАЮТ НА ЛОКАЛЬНЫХ РЫНКАХ. КАКИЕ ТЕХНОЛОГИИ ИСПОЛЬЗУЕТ MARS И ПОЧЕМУ ТАК МНОГО ВНИМАНИЯ УДЕЛЯЕТСЯ НАУЧНЫМ РАЗРАБОТКАМ. ВСЕ ЭТАПЫ ТЕХНОЛОГИЧЕСКОГО ПРОЦЕССА, ОТ ИССЛЕДОВАНИЙ ДО ГОТОВОГО ПРОДУКТА — НИ ОДИН НЮАНС НЕ УКРОЕТСЯ ОТ ТЕБЯ БЛАГОДАРЯ ЗАХВАТЫВАЮЩИМ ЛЕКЦИЯМ И МАСТЕР-КЛАССАМ СПЕЦИАЛИСТОВ MARS.\r\n'),
	(14,'c2e14f387d4c349c61736e1c64fd0dd2','РАЗВИТИЕ ЛИДЕРСТВА\r\nКОМПАНИЯ MARS СТАЛА ОДНИМ ИЗ ГИГАНТОВ ГЛОБАЛЬНОГО FMCG-РЫНКА ВО МНОГОМ БЛАГОДАРЯ СВОИМ ЛИДЕРАМ, КОТОРЫХ ГОТОВИТ НЕ ПЕРВОЕ ДЕСЯТИЛЕТИЕ. КАК СТАВИТЬ ПРОРЫВНЫЕ ЦЕЛИ, КОТОРЫЕ ОРГАНИЧНО ВПЛЕТАЮТСЯ В ЖИЗНЬ КОМПАНИИ? КАК СОЗДАТЬ ЭФФЕКТИВНУЮ КОМАНДУ, ЖИВУЩУЮ ОДНИМ ДЕЛОМ?\r\nБЫТЬ ЛИДЕРОМ — ЭТО ИСКУССТВО И ОПЫТ, КОТОРЫМ МЫ ГОТОВЫ ПОДЕЛИТЬСЯ НА ЛЕКЦИЯХ В РАМКАХ НАПРАВЛЕНИЯ «РАЗВИТИЕ ЛИДЕРСТВА».\r\n'),
	(15,'91e631824021993bce4427cf06e834f2','ОНЛАЙН\r\n\r\n'),
	(16,'10a6d78ce15e1a1acf089cf7c840e3e8','МОСКВА\r\n\r\n'),
	(17,'66227b1fe114b48fbf90cd068b71f839','САНКТ-ПЕТЕРБУРГ\r\n\r\n'),
	(18,'548afeb2ba0788438eb5980bce042c46','ИРКУТСК\r\n\r\n'),
	(19,'cb20449579d41e2c2da55f7d8b6104f8','КРАСНОДАР\r\n\r\n'),
	(20,'ebea9741f4560a10a29fa1a9e3a510a1','НОВОСИБИРСК\r\n\r\n'),
	(21,'2ff4a0f8b103ea0d43799405b70801f7','ОМСК\r\n\r\n'),
	(22,'af13f5957f108a8b8204c3da773e2c44','РОСТОВ-НА-ДОМУ\r\n\r\n'),
	(23,'685d98e662485d209d5e0bf35abb9416','САМАРА\r\n\r\n'),
	(24,'fd982294205a21110d3c1eb13f80ade4','ТОМСК\r\n\r\n'),
	(25,'5abe3be5a0298691585b9f4bc98d985e','УЛЬЯНОВСК\r\n\r\n'),
	(26,'3ffd3a879bbd9c9ac0cc0bd48a05717c','ЧЕЛЯБИНСК\r\n\r\n'),
	(27,'a2f9b2d365103bdcbd23ed16210960ea','РОЛЬ ОТДЕЛА R&D В FMCG: НАУКА И ИННОВАЦИИ В КОМАНИИ MARS\r\n\r\n'),
	(28,'d3eb7da25d443ab5bac2adfe1d8e5bb2','РОЛЬ ОТДЕЛА ФИНАНСОВ В FMCG. MARKET FINANCE\r\n\r\n');

/*!40000 ALTER TABLE `b_search_content_text` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table b_search_content_title
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_search_content_title`;

CREATE TABLE `b_search_content_title` (
  `SEARCH_CONTENT_ID` int(11) NOT NULL,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `POS` int(11) NOT NULL,
  `WORD` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  UNIQUE KEY `UX_B_SEARCH_CONTENT_TITLE` (`SITE_ID`,`WORD`,`SEARCH_CONTENT_ID`,`POS`),
  KEY `IND_B_SEARCH_CONTENT_TITLE` (`SEARCH_CONTENT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci DELAY_KEY_WRITE=1;

LOCK TABLES `b_search_content_title` WRITE;
/*!40000 ALTER TABLE `b_search_content_title` DISABLE KEYS */;

INSERT INTO `b_search_content_title` (`SEARCH_CONTENT_ID`, `SITE_ID`, `POS`, `WORD`)
VALUES
	(1,'s1',0,'МАСТЕР-КЛАСС'),
	(2,'s1',0,'СЕМИНАР'),
	(3,'s1',0,'КУРС'),
	(3,'s1',5,'ТРЕНИНГОВ'),
	(4,'s1',0,'ВЕБИНАР'),
	(5,'s1',0,'ТРЕТИНГ'),
	(6,'s1',0,'КОНФЕРЕНЦИЯ'),
	(7,'s1',11,'DEVELOPMENT'),
	(7,'s1',0,'LEADRESHIP'),
	(7,'s1',23,'PROGRAM'),
	(8,'s1',5,'INTERNSHIP'),
	(8,'s1',0,'MARS'),
	(8,'s1',16,'PROGRAM'),
	(10,'s1',7,'В'),
	(10,'s1',25,'ОБЕСПЕЧЕНИЯ'),
	(10,'s1',9,'ОТДЕЛ'),
	(10,'s1',0,'СТАЖЕР'),
	(10,'s1',15,'ТОВАРНОГО'),
	(10,'s1',38,'УЛЬЯНОВСК'),
	(11,'s1',6,'И'),
	(11,'s1',0,'МАРКЕТИНГ'),
	(11,'s1',12,'ПРОДАЖИ'),
	(12,'s1',10,'ЗАКУПКИ'),
	(12,'s1',1,'И'),
	(12,'s1',0,'ФИНАНСЫ'),
	(13,'s1',8,'И'),
	(13,'s1',13,'ПРОИЗВОДСТВО'),
	(13,'s1',0,'ТЕХНОЛОГИИ'),
	(14,'s1',9,'ЛИДЕРСТВА'),
	(14,'s1',0,'РАЗВИТИЕ'),
	(15,'s1',0,'ОНЛАЙН'),
	(16,'s1',0,'МОСКВА'),
	(17,'s1',0,'САНКТ-ПЕТЕРБУРГ'),
	(18,'s1',0,'ИРКУТСК'),
	(19,'s1',0,'КРАСНОДАР'),
	(20,'s1',0,'НОВОСИБИРСК'),
	(21,'s1',0,'ОМСК'),
	(22,'s1',0,'РОСТОВ-НА-ДОМУ'),
	(23,'s1',0,'САМАРА'),
	(24,'s1',0,'ТОМСК'),
	(25,'s1',0,'УЛЬЯНОВСК'),
	(26,'s1',0,'ЧЕЛЯБИНСК'),
	(27,'s1',14,'D'),
	(27,'s1',18,'FMCG'),
	(27,'s1',52,'MARS'),
	(27,'s1',12,'R'),
	(27,'s1',16,'В'),
	(27,'s1',30,'И'),
	(27,'s1',32,'ИННОВАЦИИ'),
	(27,'s1',44,'КОМАНИИ'),
	(27,'s1',24,'НАУКА'),
	(27,'s1',5,'ОТДЕЛА'),
	(27,'s1',0,'РОЛЬ'),
	(28,'s1',36,'FINANCE'),
	(28,'s1',23,'FMCG'),
	(28,'s1',29,'MARKET'),
	(28,'s1',19,'В'),
	(28,'s1',5,'ОТДЕЛА'),
	(28,'s1',0,'РОЛЬ'),
	(28,'s1',12,'ФИНАНСОВ');

/*!40000 ALTER TABLE `b_search_content_title` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table b_search_custom_rank
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_search_custom_rank`;

CREATE TABLE `b_search_custom_rank` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `APPLIED` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `RANK` int(11) NOT NULL DEFAULT '0',
  `SITE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `MODULE_ID` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `PARAM1` text COLLATE utf8_unicode_ci,
  `PARAM2` text COLLATE utf8_unicode_ci,
  `ITEM_ID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IND_B_SEARCH_CUSTOM_RANK` (`SITE_ID`,`MODULE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_search_phrase
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_search_phrase`;

CREATE TABLE `b_search_phrase` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `TIMESTAMP_X` datetime NOT NULL,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `RESULT_COUNT` int(11) NOT NULL,
  `PAGES` int(11) NOT NULL,
  `SESSION_ID` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `PHRASE` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TAGS` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `URL_TO` text COLLATE utf8_unicode_ci,
  `URL_TO_404` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `URL_TO_SITE_ID` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `STAT_SESS_ID` int(18) DEFAULT NULL,
  `EVENT1` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IND_PK_B_SEARCH_PHRASE_SESS_PH` (`SESSION_ID`,`PHRASE`(50)),
  KEY `IND_PK_B_SEARCH_PHRASE_SESS_TG` (`SESSION_ID`,`TAGS`(50)),
  KEY `IND_PK_B_SEARCH_PHRASE_TIME` (`TIMESTAMP_X`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_search_stem
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_search_stem`;

CREATE TABLE `b_search_stem` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `STEM` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UX_B_SEARCH_STEM` (`STEM`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `b_search_stem` WRITE;
/*!40000 ALTER TABLE `b_search_stem` DISABLE KEYS */;

INSERT INTO `b_search_stem` (`ID`, `STEM`)
VALUES
	(10,X'444556454C4F50'),
	(199,X'46494E414E43'),
	(194,X'464D4347'),
	(140,X'464D43472DD098D09DD094D0A3D0A1D0A2D0A0'),
	(169,X'464D43472DD0A0D0ABD09DD09A'),
	(13,X'494E5445524E53484950'),
	(47,X'4C454144455253484950'),
	(9,X'4C454144524553484950'),
	(12,X'4D4152'),
	(198,X'4D41524B4554'),
	(106,X'4F52424954'),
	(105,X'50454449475245'),
	(11,X'50524F4752414D'),
	(76,X'5245534541524348'),
	(104,X'534E49434B4552'),
	(125,X'D090D094D090D09FD0A2D098D0A0'),
	(46,X'D091D095D097D093D0A0D090D09DD098D0A7D09D'),
	(57,X'D091D098D097D09DD095D0A1'),
	(36,X'D091D098D097D09DD095D0A12DD097D090D094D090D0A7'),
	(163,X'D091D09BD090D093D09ED094D090D0A0'),
	(135,X'D091D09E'),
	(97,X'D091D0A0D095D09DD094'),
	(59,X'D092D090D0A1'),
	(6,X'D092D095D091D098D09DD090D0A0'),
	(151,X'D092D09DD098D09CD090D09D'),
	(15,X'D092D09ED097D09CD09ED096D09D'),
	(175,X'D092D09FD09BD095D0A2D090'),
	(19,X'D092D0A0D095D09C'),
	(31,X'D092D0ABD091D0A0D090'),
	(168,X'D093D098D093D090D09DD0A2'),
	(167,X'D093D098D093D090D09DD0A2D09ED092'),
	(146,X'D093D09BD09ED091D090D09BD0ACD09D'),
	(29,X'D093D09BD0A3D091D096'),
	(159,X'D093D09ED0A2D09ED092'),
	(87,X'D094D092D098D096D095D09D'),
	(179,X'D094D095D09B'),
	(170,X'D094D095D0A1D0AFD0A2D098D09BD095D0A2'),
	(58,X'D094D09BD098D0A2'),
	(60,X'D096D094D095D0A2'),
	(178,X'D096D098D092D0A3D0A9'),
	(176,X'D096D098D097D09D'),
	(113,X'D097D090D09AD0A3D09FD09A'),
	(124,X'D097D090D09AD0A3D09FD09ED09A'),
	(83,X'D097D090D09FD0A3D0A1D0A2'),
	(164,X'D097D090D0A5D092D090D0A2D0ABD092D090'),
	(103,X'D097D092D095D097D094'),
	(116,X'D097D09DD090D09B'),
	(21,X'D097D09DD090D09D'),
	(115,X'D097D09DD090D0A2'),
	(196,X'D098D09DD09DD09ED092D090D0A6'),
	(82,X'D098D09DD0A2D095D0A0D095D0A1'),
	(185,X'D098D0A0D09AD0A3D0A2D0A1D09A'),
	(180,X'D098D0A1D09AD0A3D0A1D0A1D0A2D092'),
	(148,X'D098D0A1D09FD09ED09BD0ACD097'),
	(16,X'D098D0A1D09FD0ABD0A2D090'),
	(158,X'D098D0A1D0A1D09BD095D094D09ED092D090D09D'),
	(117,X'D09AD09ED093'),
	(197,X'D09AD09ED09CD090D09D'),
	(26,X'D09AD09ED09CD090D09DD094'),
	(66,X'D09AD09ED09CD090D09DD094D098D0A0D09ED092D09A'),
	(94,X'D09AD09ED09CD09CD0A3D09DD098D09AD090D0A6'),
	(69,X'D09AD09ED09CD09FD090D09D'),
	(8,X'D09AD09ED09DD0A4D095D0A0D095D09DD0A6'),
	(121,X'D09AD09ED0A0D09FD09ED0A0D090D0A6'),
	(50,X'D09AD09ED0A2D09ED0A0'),
	(186,X'D09AD0A0D090D0A1D09DD09ED094D090D0A0'),
	(3,X'D09AD0A3D0A0D0A1'),
	(25,X'D09BD095D093D095D09DD094D090D0A0D09D'),
	(110,X'D09BD095D09AD0A6'),
	(44,X'D09BD095D0A2'),
	(56,X'D09BD098D094D095D0A0'),
	(165,X'D09BD098D094D095D0A0D0A1D0A2D092'),
	(127,X'D09BD09ED09AD090D09BD0ACD09D'),
	(130,X'D09BD0AED091'),
	(91,X'D09CD090D093D090D097D098D09D'),
	(90,X'D09CD090D093D090D097D098D09DD09ED092'),
	(80,X'D09CD090D0A0D09AD095D0A2D098D09DD093'),
	(38,X'D09CD090D0A1D0A1'),
	(1,X'D09CD090D0A1D0A2D095D0A02DD09AD09BD090D0A1D0A1'),
	(64,X'D09CD095D096D094D0A3D09DD090D0A0D09ED094D09D'),
	(150,X'D09CD09DD09ED093'),
	(183,X'D09CD09ED0A1D09AD092'),
	(42,X'D09DD090D092D0ABD09A'),
	(41,X'D09DD090D092D0ABD09AD09ED092'),
	(111,X'D09DD090D09FD0A0D090D092D09BD095D09D'),
	(55,X'D09DD090D0A1D0A2D09ED0AF'),
	(195,X'D09DD090D0A3D09A'),
	(153,X'D09DD090D0A3D0A7D09D'),
	(131,X'D09DD095D09DD090D092D098D094'),
	(84,X'D09DD09ED092'),
	(187,X'D09DD09ED092D09ED0A1D098D091D098D0A0D0A1D09A'),
	(161,X'D09DD0AED090D09DD0A1'),
	(79,X'D09ED091D095D0A1D09FD095D0A7D095D09D'),
	(67,X'D09ED091D0A9D095D09D'),
	(160,X'D09ED094D098D09D'),
	(43,X'D09ED094D09D'),
	(188,X'D09ED09CD0A1D09A'),
	(182,X'D09ED09DD09BD090D099D09D'),
	(62,X'D09ED09F'),
	(86,X'D09ED0A0D093D090D09DD098D097D09ED092D090'),
	(174,X'D09ED0A0D093D090D09DD098D0A7D09D'),
	(126,X'D09ED0A1D09ED091D095D09D'),
	(75,X'D09ED0A2D094D095D09B'),
	(141,X'D09FD095D0A0D092'),
	(101,X'D09FD09ED094D095D09B'),
	(109,X'D09FD09ED094D0A0D09ED091D09D'),
	(30,X'D09FD09ED097D09DD090D09AD09ED09C'),
	(39,X'D09FD09ED09BD095D097D09D'),
	(89,X'D09FD09ED09BD09ED09A'),
	(37,X'D09FD09ED09BD0A3D0A7'),
	(18,X'D09FD09ED09BD0A3D0A7D095D09D'),
	(51,X'D09FD09ED09CD09ED093D090'),
	(33,X'D09FD09ED09FD0A0D09ED091D09ED092D090'),
	(92,X'D09FD09ED0A1D0A2D0A0D09E'),
	(71,X'D09FD09ED0A2D095D09DD0A6D098D090'),
	(120,X'D09FD09ED0A2D09ED09A'),
	(95,X'D09FD09ED0A2D0A0D095D091D098D0A2D095D09B'),
	(149,X'D09FD09ED0A7'),
	(45,X'D09FD09ED0A7D0A2'),
	(93,X'D09FD0A0D090D092D098D09BD0ACD09D'),
	(17,X'D09FD0A0D090D09AD0A2D098D09A'),
	(40,X'D09FD0A0D090D09AD0A2D098D0A7D095D0A1D09A'),
	(48,X'D09FD0A0D09ED093D0A0D090D09CD09C'),
	(81,X'D09FD0A0D09ED094D090D096'),
	(85,X'D09FD0A0D09ED094D0A3D09AD0A2'),
	(65,X'D09FD0A0D09ED095D09AD0A2'),
	(144,X'D09FD0A0D09ED098D097D092D09ED094D0A1D0A2D092'),
	(172,X'D09FD0A0D09ED0A0D0ABD092D09D'),
	(14,X'D09FD0A0D09ED0A1D0A2'),
	(32,X'D09FD0A0D09ED0A4D095D0A1D0A1'),
	(28,X'D09FD0A0D09ED0A4D095D0A1D0A1D098D09ED09DD090D09B'),
	(27,X'D09FD0A0D09ED0A4D095D0A1D0A1D098D09ED09DD090D09BD09ED092'),
	(157,X'D09FD0A0D09ED0A6D095D0A1D0A1'),
	(63,X'D0A0D090D091D09ED0A2'),
	(102,X'D0A0D090D091D09ED0A2D090'),
	(49,X'D0A0D090D097D092D098D0A2'),
	(154,X'D0A0D090D097D0A0D090D091D09ED0A2D09A'),
	(181,X'D0A0D090D09CD09A'),
	(70,X'D0A0D090D0A1D09AD0A0D09ED099D0A2'),
	(35,X'D0A0D095D090D09BD0ACD09D'),
	(34,X'D0A0D095D0A8D095D09D'),
	(193,X'D0A0D09ED09B'),
	(189,X'D0A0D09ED0A1D0A2D09ED0922DD09DD0902DD094'),
	(142,X'D0A0D0A3D09A'),
	(73,X'D0A0D0A3D09AD09ED092D09ED094D098D0A2D095D09B'),
	(129,X'D0A0D0ABD09DD09A'),
	(128,X'D0A0D0ABD09DD09AD09ED092'),
	(190,X'D0A1D090D09CD090D0A0'),
	(184,X'D0A1D090D09DD09AD0A22DD09FD095D0A2D095D0A0D091D0A3D0A0D093'),
	(96,X'D0A1D094D095D09BD090'),
	(99,X'D0A1D095D09AD0A0D095D0A2'),
	(2,X'D0A1D095D09CD098D09DD090D0A0'),
	(98,X'D0A1D098D09BD0ACD09D'),
	(123,X'D0A1D098D0A1D0A2D095D09C'),
	(177,X'D0A1D09ED097D094D090'),
	(53,X'D0A1D09ED0A2D0A0D0A3D094D09DD098D09A'),
	(137,X'D0A1D09FD095D0A6D098D090D09BD098D0A1D0A2'),
	(136,X'D0A1D09FD095D0A6D098D090D09BD098D0A1D0A2D09ED092'),
	(118,X'D0A1D09FD0A0D09ED0A1'),
	(171,X'D0A1D0A2D090D092'),
	(74,X'D0A1D0A2D090D096D095D0A0'),
	(166,X'D0A1D0A2D090D09B'),
	(147,X'D0A1D0A2D090D09DD094D090D0A0D0A2'),
	(54,X'D0A1D0A2D090D09DD09ED092'),
	(72,X'D0A1D0A2D090D09DD0ACD0A2'),
	(23,X'D0A1D0A2D090D0A2'),
	(139,X'D0A1D0A2D09ED09BD09F'),
	(52,X'D0A2D090D09BD090D09DD0A2D09BD098D092'),
	(143,X'D0A2D095D0A5D09DD09ED09BD09ED093'),
	(156,X'D0A2D095D0A5D09DD09ED09BD09ED093D098D0A7D095D0A1D09A'),
	(100,X'D0A2D09ED091'),
	(78,X'D0A2D09ED092D090D0A0D09D'),
	(191,X'D0A2D09ED09CD0A1D09A'),
	(68,X'D0A2D09ED09F2DD09CD095D09DD095D094D096D095D0A0'),
	(5,X'D0A2D0A0D095D09DD098D09DD093'),
	(4,X'D0A2D0A0D095D09DD098D09DD093D09ED092'),
	(7,X'D0A2D0A0D095D0A2D098D09DD093'),
	(134,X'D0A3D092D090D096D090'),
	(138,X'D0A3D092D09BD095D09AD090D0A2D095D09BD0ACD09D'),
	(152,X'D0A3D094D095D09BD0AF'),
	(108,X'D0A3D097D09DD090'),
	(162,X'D0A3D09AD0A0D09ED095D0A2'),
	(77,X'D0A3D09BD0ACD0AFD09DD09ED092D0A1D09A'),
	(61,X'D0A3D09DD098D09AD090D09BD0ACD09D'),
	(107,X'D0A3D09FD0A3D0A1D0A2'),
	(122,X'D0A3D0A1D0A2D0A0D09E'),
	(20,X'D0A3D0A7D095D091'),
	(88,X'D0A4D090D091D0A0D098D09A'),
	(112,X'D0A4D098D09DD090D09DD0A1'),
	(133,X'D0A4D098D09DD090D09DD0A1D098D0A1D0A2'),
	(132,X'D0A4D098D09DD090D09DD0A1D098D0A1D0A2D09ED092'),
	(119,X'D0A4D098D09DD090D09DD0A1D09ED092'),
	(114,X'D0A5D09ED0A2D095D09B'),
	(173,X'D0A6D095D09B'),
	(24,X'D0A7D090D0A1D0A2'),
	(192,X'D0A7D095D09BD0AFD091D098D09DD0A1D09A'),
	(22,X'D0A8D090D09DD0A1'),
	(155,X'D0ADD0A2D090D09F'),
	(145,X'D0ADD0A4D0A4D095D09AD0A2D098D092D09D');

/*!40000 ALTER TABLE `b_search_stem` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table b_search_suggest
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_search_suggest`;

CREATE TABLE `b_search_suggest` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `FILTER_MD5` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `PHRASE` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `RATE` float NOT NULL,
  `TIMESTAMP_X` datetime NOT NULL,
  `RESULT_COUNT` int(11) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `IND_B_SEARCH_SUGGEST` (`FILTER_MD5`,`PHRASE`(50),`RATE`),
  KEY `IND_B_SEARCH_SUGGEST_PHRASE` (`PHRASE`(50),`RATE`),
  KEY `IND_B_SEARCH_SUGGEST_TIME` (`TIMESTAMP_X`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_search_tags
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_search_tags`;

CREATE TABLE `b_search_tags` (
  `SEARCH_CONTENT_ID` int(11) NOT NULL,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `NAME` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`SEARCH_CONTENT_ID`,`SITE_ID`,`NAME`),
  KEY `IX_B_SEARCH_TAGS_0` (`NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci DELAY_KEY_WRITE=1;



# Dump of table b_search_user_right
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_search_user_right`;

CREATE TABLE `b_search_user_right` (
  `USER_ID` int(11) NOT NULL,
  `GROUP_CODE` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  UNIQUE KEY `UX_B_SEARCH_USER_RIGHT` (`USER_ID`,`GROUP_CODE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_sec_filter_mask
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_sec_filter_mask`;

CREATE TABLE `b_sec_filter_mask` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `SORT` int(11) NOT NULL DEFAULT '10',
  `SITE_ID` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FILTER_MASK` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LIKE_MASK` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PREG_MASK` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_sec_frame_mask
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_sec_frame_mask`;

CREATE TABLE `b_sec_frame_mask` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `SORT` int(11) NOT NULL DEFAULT '10',
  `SITE_ID` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FRAME_MASK` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LIKE_MASK` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PREG_MASK` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_sec_iprule
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_sec_iprule`;

CREATE TABLE `b_sec_iprule` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `RULE_TYPE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'M',
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `ADMIN_SECTION` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `SITE_ID` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SORT` int(11) NOT NULL DEFAULT '500',
  `ACTIVE_FROM` datetime DEFAULT NULL,
  `ACTIVE_FROM_TIMESTAMP` int(11) DEFAULT NULL,
  `ACTIVE_TO` datetime DEFAULT NULL,
  `ACTIVE_TO_TIMESTAMP` int(11) DEFAULT NULL,
  `NAME` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ix_b_sec_iprule_active_to` (`ACTIVE_TO`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_sec_iprule_excl_ip
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_sec_iprule_excl_ip`;

CREATE TABLE `b_sec_iprule_excl_ip` (
  `IPRULE_ID` int(11) NOT NULL,
  `RULE_IP` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `SORT` int(11) NOT NULL DEFAULT '500',
  `IP_START` bigint(18) DEFAULT NULL,
  `IP_END` bigint(18) DEFAULT NULL,
  PRIMARY KEY (`IPRULE_ID`,`RULE_IP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_sec_iprule_excl_mask
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_sec_iprule_excl_mask`;

CREATE TABLE `b_sec_iprule_excl_mask` (
  `IPRULE_ID` int(11) NOT NULL,
  `RULE_MASK` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `SORT` int(11) NOT NULL DEFAULT '500',
  `LIKE_MASK` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PREG_MASK` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`IPRULE_ID`,`RULE_MASK`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_sec_iprule_incl_ip
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_sec_iprule_incl_ip`;

CREATE TABLE `b_sec_iprule_incl_ip` (
  `IPRULE_ID` int(11) NOT NULL,
  `RULE_IP` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `SORT` int(11) NOT NULL DEFAULT '500',
  `IP_START` bigint(18) DEFAULT NULL,
  `IP_END` bigint(18) DEFAULT NULL,
  PRIMARY KEY (`IPRULE_ID`,`RULE_IP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_sec_iprule_incl_mask
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_sec_iprule_incl_mask`;

CREATE TABLE `b_sec_iprule_incl_mask` (
  `IPRULE_ID` int(11) NOT NULL,
  `RULE_MASK` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `SORT` int(11) NOT NULL DEFAULT '500',
  `LIKE_MASK` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PREG_MASK` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`IPRULE_ID`,`RULE_MASK`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_sec_redirect_url
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_sec_redirect_url`;

CREATE TABLE `b_sec_redirect_url` (
  `IS_SYSTEM` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `SORT` int(11) NOT NULL DEFAULT '500',
  `URL` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `PARAMETER_NAME` varchar(250) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `b_sec_redirect_url` WRITE;
/*!40000 ALTER TABLE `b_sec_redirect_url` DISABLE KEYS */;

INSERT INTO `b_sec_redirect_url` (`IS_SYSTEM`, `SORT`, `URL`, `PARAMETER_NAME`)
VALUES
	('Y',10,'/bitrix/redirect.php','goto'),
	('Y',20,'/bitrix/rk.php','goto'),
	('Y',30,'/bitrix/click.php','goto');

/*!40000 ALTER TABLE `b_sec_redirect_url` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table b_sec_session
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_sec_session`;

CREATE TABLE `b_sec_session` (
  `SESSION_ID` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `SESSION_DATA` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`SESSION_ID`),
  KEY `ix_b_sec_session_time` (`TIMESTAMP_X`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_sec_user
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_sec_user`;

CREATE TABLE `b_sec_user` (
  `USER_ID` int(11) NOT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `SECRET` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `COUNTER` int(11) NOT NULL,
  PRIMARY KEY (`USER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_sec_virus
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_sec_virus`;

CREATE TABLE `b_sec_virus` (
  `ID` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `TIMESTAMP_X` datetime NOT NULL,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SENT` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `INFO` longtext COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_sec_white_list
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_sec_white_list`;

CREATE TABLE `b_sec_white_list` (
  `ID` int(11) NOT NULL,
  `WHITE_SUBSTR` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_security_sitecheck
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_security_sitecheck`;

CREATE TABLE `b_security_sitecheck` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `TEST_DATE` datetime DEFAULT NULL,
  `RESULTS` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_seo_keywords
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_seo_keywords`;

CREATE TABLE `b_seo_keywords` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `URL` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `KEYWORDS` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `ix_b_seo_keywords_url` (`URL`,`SITE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_seo_search_engine
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_seo_search_engine`;

CREATE TABLE `b_seo_search_engine` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `CODE` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci DEFAULT 'Y',
  `SORT` int(5) DEFAULT '100',
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `CLIENT_ID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CLIENT_SECRET` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `REDIRECT_URI` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SETTINGS` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ux_b_seo_search_engine_code` (`CODE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `b_seo_search_engine` WRITE;
/*!40000 ALTER TABLE `b_seo_search_engine` DISABLE KEYS */;

INSERT INTO `b_seo_search_engine` (`ID`, `CODE`, `ACTIVE`, `SORT`, `NAME`, `CLIENT_ID`, `CLIENT_SECRET`, `REDIRECT_URI`, `SETTINGS`)
VALUES
	(1,'google','Y',200,'Google','950140266760.apps.googleusercontent.com','IBktWJ_dS3rMKh43PSHO-zo5','urn:ietf:wg:oauth:2.0:oob',NULL),
	(2,'yandex','Y',300,'Yandex','f848c7bfc1d34a94ba6d05439f81bbd7','da0e73b2d9cc4e809f3170e49cb9df01','https://oauth.yandex.ru/verification_code',NULL);

/*!40000 ALTER TABLE `b_seo_search_engine` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table b_seo_sitemap
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_seo_sitemap`;

CREATE TABLE `b_seo_sitemap` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci DEFAULT 'Y',
  `NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `DATE_RUN` datetime DEFAULT NULL,
  `SETTINGS` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_seo_sitemap_entity
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_seo_sitemap_entity`;

CREATE TABLE `b_seo_sitemap_entity` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ENTITY_TYPE` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ENTITY_ID` int(11) NOT NULL,
  `SITEMAP_ID` int(11) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `ix_b_seo_sitemap_entity_1` (`ENTITY_TYPE`,`ENTITY_ID`),
  KEY `ix_b_seo_sitemap_entity_2` (`SITEMAP_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_seo_sitemap_iblock
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_seo_sitemap_iblock`;

CREATE TABLE `b_seo_sitemap_iblock` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `IBLOCK_ID` int(11) NOT NULL,
  `SITEMAP_ID` int(11) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `ix_b_seo_sitemap_iblock_1` (`IBLOCK_ID`),
  KEY `ix_b_seo_sitemap_iblock_2` (`SITEMAP_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_seo_sitemap_runtime
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_seo_sitemap_runtime`;

CREATE TABLE `b_seo_sitemap_runtime` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `PID` int(11) NOT NULL,
  `PROCESSED` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ITEM_PATH` varchar(700) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ITEM_ID` int(11) DEFAULT NULL,
  `ITEM_TYPE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'D',
  `ACTIVE` char(1) COLLATE utf8_unicode_ci DEFAULT 'Y',
  `ACTIVE_ELEMENT` char(1) COLLATE utf8_unicode_ci DEFAULT 'Y',
  PRIMARY KEY (`ID`),
  KEY `ix_seo_sitemap_runtime1` (`PID`,`PROCESSED`,`ITEM_TYPE`,`ITEM_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_short_uri
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_short_uri`;

CREATE TABLE `b_short_uri` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `URI` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `URI_CRC` int(18) NOT NULL,
  `SHORT_URI` varbinary(250) NOT NULL,
  `SHORT_URI_CRC` int(18) NOT NULL,
  `STATUS` int(18) NOT NULL DEFAULT '301',
  `MODIFIED` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `LAST_USED` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `NUMBER_USED` int(18) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `ux_b_short_uri_1` (`SHORT_URI_CRC`),
  KEY `ux_b_short_uri_2` (`URI_CRC`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_site_template
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_site_template`;

CREATE TABLE `b_site_template` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `CONDITION` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SORT` int(11) NOT NULL DEFAULT '500',
  `TEMPLATE` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UX_B_SITE_TEMPLATE` (`SITE_ID`,`CONDITION`,`TEMPLATE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `b_site_template` WRITE;
/*!40000 ALTER TABLE `b_site_template` DISABLE KEYS */;

INSERT INTO `b_site_template` (`ID`, `SITE_ID`, `CONDITION`, `SORT`, `TEMPLATE`)
VALUES
	(1,'s1','',1,'mars_graduates');

/*!40000 ALTER TABLE `b_site_template` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table b_smile
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_smile`;

CREATE TABLE `b_smile` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `TYPE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'S',
  `SET_ID` int(18) NOT NULL DEFAULT '0',
  `SORT` int(10) NOT NULL DEFAULT '150',
  `TYPING` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CLICKABLE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `IMAGE` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `IMAGE_HR` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `IMAGE_WIDTH` int(11) NOT NULL DEFAULT '0',
  `IMAGE_HEIGHT` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `b_smile` WRITE;
/*!40000 ALTER TABLE `b_smile` DISABLE KEYS */;

INSERT INTO `b_smile` (`ID`, `TYPE`, `SET_ID`, `SORT`, `TYPING`, `CLICKABLE`, `IMAGE`, `IMAGE_HR`, `IMAGE_WIDTH`, `IMAGE_HEIGHT`)
VALUES
	(1,'S',1,100,':) :-)','Y','smile_smile.png','Y',16,16),
	(2,'S',1,105,';) ;-)','Y','smile_wink.png','Y',16,16),
	(3,'S',1,110,':D :-D','Y','smile_biggrin.png','Y',16,16),
	(4,'S',1,115,'8) 8-)','Y','smile_cool.png','Y',16,16),
	(5,'S',1,120,':( :-(','Y','smile_sad.png','Y',16,16),
	(6,'S',1,125,':| :-|','Y','smile_neutral.png','Y',16,16),
	(7,'S',1,130,':oops:','Y','smile_redface.png','Y',16,16),
	(8,'S',1,135,':cry: :~(','Y','smile_cry.png','Y',16,16),
	(9,'S',1,140,':evil: >:-<','Y','smile_evil.png','Y',16,16),
	(10,'S',1,145,':o :-o :shock:','Y','smile_eek.png','Y',16,16),
	(11,'S',1,150,':/ :-/','Y','smile_confuse.png','Y',16,16),
	(12,'S',1,155,':{} :-{}','Y','smile_kiss.png','Y',16,16),
	(13,'S',1,160,':idea:','Y','smile_idea.png','Y',16,16),
	(14,'S',1,165,':?:','Y','smile_question.png','Y',16,16),
	(15,'S',1,170,':!:','Y','smile_exclaim.png','Y',16,16),
	(16,'I',1,175,'','Y','icon1.gif','N',15,15),
	(17,'I',1,180,'','Y','icon2.gif','N',15,15),
	(18,'I',1,185,'','Y','icon3.gif','N',15,15),
	(19,'I',1,190,'','Y','icon4.gif','N',15,15),
	(20,'I',1,195,'','Y','icon5.gif','N',15,15),
	(21,'I',1,200,'','Y','icon6.gif','N',15,15),
	(22,'I',1,205,NULL,'Y','icon7.gif','N',15,15);

/*!40000 ALTER TABLE `b_smile` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table b_smile_lang
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_smile_lang`;

CREATE TABLE `b_smile_lang` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `TYPE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'S',
  `SID` int(11) NOT NULL,
  `LID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UX_SMILE_SL` (`TYPE`,`SID`,`LID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `b_smile_lang` WRITE;
/*!40000 ALTER TABLE `b_smile_lang` DISABLE KEYS */;

INSERT INTO `b_smile_lang` (`ID`, `TYPE`, `SID`, `LID`, `NAME`)
VALUES
	(1,'G',1,'ru','Основной набор'),
	(2,'G',1,'en','Default set'),
	(3,'S',1,'ru','С улыбкой'),
	(4,'S',1,'en','Smile'),
	(5,'S',2,'ru','Шутливо'),
	(6,'S',2,'en','Wink'),
	(7,'S',3,'ru','Широкая улыбка'),
	(8,'S',3,'en','Big grin'),
	(9,'S',4,'ru','Здорово'),
	(10,'S',4,'en','Cool'),
	(11,'S',5,'ru','Печально'),
	(12,'S',5,'en','Sad'),
	(13,'S',6,'ru','Скептически'),
	(14,'S',6,'en','Skeptic'),
	(15,'S',7,'ru','Смущенный'),
	(16,'S',7,'en','Embarrassed'),
	(17,'S',8,'ru','Очень грустно'),
	(18,'S',8,'en','Crying'),
	(19,'S',9,'ru','Со злостью'),
	(20,'S',9,'en','Angry'),
	(21,'S',10,'ru','Удивленно'),
	(22,'S',10,'en','Surprised'),
	(23,'S',11,'ru','Смущенно'),
	(24,'S',11,'en','Confused'),
	(25,'S',12,'ru','Поцелуй'),
	(26,'S',12,'en','Kiss'),
	(27,'S',13,'ru','Идея'),
	(28,'S',13,'en','Idea'),
	(29,'S',14,'ru','Вопрос'),
	(30,'S',14,'en','Question'),
	(31,'S',15,'ru','Восклицание'),
	(32,'S',15,'en','Exclamation');

/*!40000 ALTER TABLE `b_smile_lang` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table b_smile_set
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_smile_set`;

CREATE TABLE `b_smile_set` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `STRING_ID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SORT` int(10) NOT NULL DEFAULT '150',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `b_smile_set` WRITE;
/*!40000 ALTER TABLE `b_smile_set` DISABLE KEYS */;

INSERT INTO `b_smile_set` (`ID`, `STRING_ID`, `SORT`)
VALUES
	(1,'main',150);

/*!40000 ALTER TABLE `b_smile_set` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table b_socialservices_message
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_socialservices_message`;

CREATE TABLE `b_socialservices_message` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `USER_ID` int(11) NOT NULL,
  `SOCSERV_USER_ID` int(11) NOT NULL,
  `PROVIDER` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `MESSAGE` varchar(1000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `INSERT_DATE` datetime DEFAULT NULL,
  `SUCCES_SENT` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_socialservices_user
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_socialservices_user`;

CREATE TABLE `b_socialservices_user` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `LOGIN` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `NAME` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LAST_NAME` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `EMAIL` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PERSONAL_PHOTO` int(11) DEFAULT NULL,
  `EXTERNAL_AUTH_ID` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `USER_ID` int(11) NOT NULL,
  `XML_ID` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `CAN_DELETE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `PERSONAL_WWW` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PERMISSIONS` varchar(555) COLLATE utf8_unicode_ci DEFAULT NULL,
  `OATOKEN` varchar(1000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `OATOKEN_EXPIRES` int(11) DEFAULT NULL,
  `OASECRET` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `REFRESH_TOKEN` varchar(1000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SEND_ACTIVITY` char(1) COLLATE utf8_unicode_ci DEFAULT 'Y',
  `SITE_ID` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `IX_B_SOCIALSERVICES_USER` (`XML_ID`,`EXTERNAL_AUTH_ID`),
  KEY `IX_B_SOCIALSERVICES_US_1` (`USER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_sticker
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_sticker`;

CREATE TABLE `b_sticker` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PAGE_URL` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `PAGE_TITLE` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `DATE_CREATE` datetime NOT NULL,
  `DATE_UPDATE` datetime NOT NULL,
  `MODIFIED_BY` int(18) NOT NULL,
  `CREATED_BY` int(18) NOT NULL,
  `PERSONAL` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `CONTENT` text COLLATE utf8_unicode_ci,
  `POS_TOP` int(11) DEFAULT NULL,
  `POS_LEFT` int(11) DEFAULT NULL,
  `WIDTH` int(11) DEFAULT NULL,
  `HEIGHT` int(11) DEFAULT NULL,
  `COLOR` int(11) DEFAULT NULL,
  `COLLAPSED` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `COMPLETED` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `CLOSED` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `DELETED` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `MARKER_TOP` int(11) DEFAULT NULL,
  `MARKER_LEFT` int(11) DEFAULT NULL,
  `MARKER_WIDTH` int(11) DEFAULT NULL,
  `MARKER_HEIGHT` int(11) DEFAULT NULL,
  `MARKER_ADJUST` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_sticker_group_task
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_sticker_group_task`;

CREATE TABLE `b_sticker_group_task` (
  `GROUP_ID` int(11) NOT NULL,
  `TASK_ID` int(11) NOT NULL,
  PRIMARY KEY (`GROUP_ID`,`TASK_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_subscription
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_subscription`;

CREATE TABLE `b_subscription` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `DATE_INSERT` datetime NOT NULL,
  `DATE_UPDATE` datetime DEFAULT NULL,
  `USER_ID` int(11) DEFAULT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `EMAIL` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `FORMAT` varchar(4) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'text',
  `CONFIRM_CODE` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CONFIRMED` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `DATE_CONFIRM` datetime NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UK_SUBSCRIPTION_EMAIL` (`EMAIL`,`USER_ID`),
  KEY `IX_DATE_CONFIRM` (`CONFIRMED`,`DATE_CONFIRM`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_subscription_rubric
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_subscription_rubric`;

CREATE TABLE `b_subscription_rubric` (
  `SUBSCRIPTION_ID` int(11) NOT NULL,
  `LIST_RUBRIC_ID` int(11) NOT NULL,
  UNIQUE KEY `UK_SUBSCRIPTION_RUBRIC` (`SUBSCRIPTION_ID`,`LIST_RUBRIC_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_task
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_task`;

CREATE TABLE `b_task` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `LETTER` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `MODULE_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `SYS` char(1) COLLATE utf8_unicode_ci NOT NULL,
  `DESCRIPTION` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `BINDING` varchar(50) COLLATE utf8_unicode_ci DEFAULT 'module',
  PRIMARY KEY (`ID`),
  KEY `ix_task` (`MODULE_ID`,`BINDING`,`LETTER`,`SYS`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `b_task` WRITE;
/*!40000 ALTER TABLE `b_task` DISABLE KEYS */;

INSERT INTO `b_task` (`ID`, `NAME`, `LETTER`, `MODULE_ID`, `SYS`, `DESCRIPTION`, `BINDING`)
VALUES
	(1,'main_denied','D','main','Y',NULL,'module'),
	(2,'main_change_profile','P','main','Y',NULL,'module'),
	(3,'main_view_all_settings','R','main','Y',NULL,'module'),
	(4,'main_view_all_settings_change_profile','T','main','Y',NULL,'module'),
	(5,'main_edit_subordinate_users','V','main','Y',NULL,'module'),
	(6,'main_full_access','W','main','Y',NULL,'module'),
	(7,'fm_folder_access_denied','D','main','Y',NULL,'file'),
	(8,'fm_folder_access_read','R','main','Y',NULL,'file'),
	(9,'fm_folder_access_write','W','main','Y',NULL,'file'),
	(10,'fm_folder_access_full','X','main','Y',NULL,'file'),
	(11,'fm_folder_access_workflow','U','main','Y',NULL,'file'),
	(12,'clouds_denied','D','clouds','Y',NULL,'module'),
	(13,'clouds_browse','F','clouds','Y',NULL,'module'),
	(14,'clouds_upload','U','clouds','Y',NULL,'module'),
	(15,'clouds_full_access','W','clouds','Y',NULL,'module'),
	(16,'fileman_denied','D','fileman','Y','','module'),
	(17,'fileman_allowed_folders','F','fileman','Y','','module'),
	(18,'fileman_full_access','W','fileman','Y','','module'),
	(19,'medialib_denied','D','fileman','Y','','medialib'),
	(20,'medialib_view','F','fileman','Y','','medialib'),
	(21,'medialib_only_new','R','fileman','Y','','medialib'),
	(22,'medialib_edit_items','V','fileman','Y','','medialib'),
	(23,'medialib_editor','W','fileman','Y','','medialib'),
	(24,'medialib_full','X','fileman','Y','','medialib'),
	(25,'stickers_denied','D','fileman','Y','','stickers'),
	(26,'stickers_read','R','fileman','Y','','stickers'),
	(27,'stickers_edit','W','fileman','Y','','stickers'),
	(28,'iblock_deny','D','iblock','Y',NULL,'iblock'),
	(29,'iblock_read','R','iblock','Y',NULL,'iblock'),
	(30,'iblock_element_add','E','iblock','Y',NULL,'iblock'),
	(31,'iblock_admin_read','S','iblock','Y',NULL,'iblock'),
	(32,'iblock_admin_add','T','iblock','Y',NULL,'iblock'),
	(33,'iblock_limited_edit','U','iblock','Y',NULL,'iblock'),
	(34,'iblock_full_edit','W','iblock','Y',NULL,'iblock'),
	(35,'iblock_full','X','iblock','Y',NULL,'iblock'),
	(36,'security_denied','D','security','Y',NULL,'module'),
	(37,'security_filter','F','security','Y',NULL,'module'),
	(38,'security_otp','S','security','Y',NULL,'module'),
	(39,'security_view_all_settings','T','security','Y',NULL,'module'),
	(40,'security_full_access','W','security','Y',NULL,'module'),
	(41,'seo_denied','D','seo','Y','','module'),
	(42,'seo_edit','F','seo','Y','','module'),
	(43,'seo_full_access','W','seo','Y','','module');

/*!40000 ALTER TABLE `b_task` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table b_task_operation
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_task_operation`;

CREATE TABLE `b_task_operation` (
  `TASK_ID` int(18) NOT NULL,
  `OPERATION_ID` int(18) NOT NULL,
  PRIMARY KEY (`TASK_ID`,`OPERATION_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `b_task_operation` WRITE;
/*!40000 ALTER TABLE `b_task_operation` DISABLE KEYS */;

INSERT INTO `b_task_operation` (`TASK_ID`, `OPERATION_ID`)
VALUES
	(2,2),
	(2,3),
	(3,2),
	(3,4),
	(3,5),
	(3,6),
	(3,7),
	(4,2),
	(4,3),
	(4,4),
	(4,5),
	(4,6),
	(4,7),
	(5,2),
	(5,3),
	(5,5),
	(5,6),
	(5,7),
	(5,8),
	(5,9),
	(6,2),
	(6,3),
	(6,4),
	(6,5),
	(6,6),
	(6,7),
	(6,10),
	(6,11),
	(6,12),
	(6,13),
	(6,14),
	(6,15),
	(6,16),
	(6,17),
	(6,18),
	(8,19),
	(8,20),
	(8,21),
	(9,19),
	(9,20),
	(9,21),
	(9,22),
	(9,23),
	(9,24),
	(9,25),
	(9,26),
	(9,27),
	(9,28),
	(9,29),
	(9,30),
	(9,31),
	(9,32),
	(9,33),
	(9,34),
	(10,19),
	(10,20),
	(10,21),
	(10,22),
	(10,23),
	(10,24),
	(10,25),
	(10,26),
	(10,27),
	(10,28),
	(10,29),
	(10,30),
	(10,31),
	(10,32),
	(10,33),
	(10,34),
	(10,35),
	(11,19),
	(11,20),
	(11,21),
	(11,24),
	(11,28),
	(13,36),
	(14,36),
	(14,37),
	(15,36),
	(15,37),
	(15,38),
	(17,41),
	(17,42),
	(17,43),
	(17,44),
	(17,45),
	(17,46),
	(17,47),
	(17,49),
	(17,50),
	(18,39),
	(18,40),
	(18,41),
	(18,42),
	(18,43),
	(18,44),
	(18,45),
	(18,46),
	(18,47),
	(18,48),
	(18,49),
	(18,50),
	(18,51),
	(20,52),
	(21,52),
	(21,53),
	(21,57),
	(22,52),
	(22,57),
	(22,58),
	(22,59),
	(23,52),
	(23,53),
	(23,54),
	(23,55),
	(23,57),
	(23,58),
	(23,59),
	(24,52),
	(24,53),
	(24,54),
	(24,55),
	(24,56),
	(24,57),
	(24,58),
	(24,59),
	(26,60),
	(27,60),
	(27,61),
	(27,62),
	(27,63),
	(29,64),
	(29,65),
	(30,66),
	(31,64),
	(31,65),
	(31,67),
	(32,64),
	(32,65),
	(32,66),
	(32,67),
	(33,64),
	(33,65),
	(33,66),
	(33,67),
	(33,68),
	(33,69),
	(33,70),
	(33,71),
	(34,64),
	(34,65),
	(34,66),
	(34,67),
	(34,68),
	(34,69),
	(34,70),
	(34,71),
	(34,72),
	(34,73),
	(34,74),
	(34,75),
	(35,64),
	(35,65),
	(35,66),
	(35,67),
	(35,68),
	(35,69),
	(35,70),
	(35,71),
	(35,72),
	(35,73),
	(35,74),
	(35,75),
	(35,76),
	(35,77),
	(35,78),
	(35,79),
	(35,80),
	(35,81),
	(37,82),
	(38,83),
	(39,84),
	(39,85),
	(39,86),
	(39,87),
	(39,88),
	(39,89),
	(39,90),
	(39,91),
	(39,92),
	(39,93),
	(39,94),
	(40,82),
	(40,83),
	(40,84),
	(40,85),
	(40,86),
	(40,87),
	(40,88),
	(40,89),
	(40,90),
	(40,91),
	(40,92),
	(40,93),
	(40,94),
	(40,95),
	(40,96),
	(40,97),
	(40,98),
	(40,99),
	(40,100),
	(40,101),
	(40,102),
	(40,103),
	(40,104),
	(40,105),
	(40,106),
	(40,107),
	(42,109),
	(43,108),
	(43,109);

/*!40000 ALTER TABLE `b_task_operation` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table b_undo
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_undo`;

CREATE TABLE `b_undo` (
  `ID` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `MODULE_ID` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `UNDO_TYPE` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `UNDO_HANDLER` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CONTENT` mediumtext COLLATE utf8_unicode_ci,
  `USER_ID` int(11) DEFAULT NULL,
  `TIMESTAMP_X` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `b_undo` WRITE;
/*!40000 ALTER TABLE `b_undo` DISABLE KEYS */;

INSERT INTO `b_undo` (`ID`, `MODULE_ID`, `UNDO_TYPE`, `UNDO_HANDLER`, `CONTENT`, `USER_ID`, `TIMESTAMP_X`)
VALUES
	('27dbf584aeaf9cd2e13760e230ae2fb29','main','autosave','CAutoSave::_Restore','a:13:{s:6:\"filter\";s:1:\"Y\";s:10:\"set_filter\";s:1:\"Y\";s:6:\"Update\";s:1:\"Y\";s:7:\"site_id\";s:2:\"s1\";s:13:\"CONDITION_OLD\";s:0:\"\";s:9:\"CONDITION\";s:22:\"#^/services/(.*)/(.*)#\";s:2:\"ID\";s:0:\"\";s:9:\"FILE_PATH\";s:0:\"\";s:4:\"RULE\";s:0:\"\";s:4:\"save\";s:0:\"\";s:5:\"apply\";s:0:\"\";s:6:\"cancel\";s:0:\"\";s:21:\"tabControl_active_tab\";s:5:\"edit1\";}',1,1405628528);

/*!40000 ALTER TABLE `b_undo` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table b_user
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_user`;

CREATE TABLE `b_user` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `LOGIN` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `PASSWORD` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `CHECKWORD` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `NAME` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LAST_NAME` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `EMAIL` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LAST_LOGIN` datetime DEFAULT NULL,
  `DATE_REGISTER` datetime NOT NULL,
  `LID` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PERSONAL_PROFESSION` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PERSONAL_WWW` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PERSONAL_ICQ` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PERSONAL_GENDER` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PERSONAL_BIRTHDATE` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PERSONAL_PHOTO` int(18) DEFAULT NULL,
  `PERSONAL_PHONE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PERSONAL_FAX` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PERSONAL_MOBILE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PERSONAL_PAGER` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PERSONAL_STREET` text COLLATE utf8_unicode_ci,
  `PERSONAL_MAILBOX` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PERSONAL_CITY` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PERSONAL_STATE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PERSONAL_ZIP` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PERSONAL_COUNTRY` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PERSONAL_NOTES` text COLLATE utf8_unicode_ci,
  `WORK_COMPANY` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `WORK_DEPARTMENT` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `WORK_POSITION` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `WORK_WWW` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `WORK_PHONE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `WORK_FAX` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `WORK_PAGER` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `WORK_STREET` text COLLATE utf8_unicode_ci,
  `WORK_MAILBOX` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `WORK_CITY` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `WORK_STATE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `WORK_ZIP` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `WORK_COUNTRY` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `WORK_PROFILE` text COLLATE utf8_unicode_ci,
  `WORK_LOGO` int(18) DEFAULT NULL,
  `WORK_NOTES` text COLLATE utf8_unicode_ci,
  `ADMIN_NOTES` text COLLATE utf8_unicode_ci,
  `STORED_HASH` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `XML_ID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PERSONAL_BIRTHDAY` date DEFAULT NULL,
  `EXTERNAL_AUTH_ID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CHECKWORD_TIME` datetime DEFAULT NULL,
  `SECOND_NAME` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CONFIRM_CODE` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LOGIN_ATTEMPTS` int(18) DEFAULT NULL,
  `LAST_ACTIVITY_DATE` datetime DEFAULT NULL,
  `AUTO_TIME_ZONE` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TIME_ZONE` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TIME_ZONE_OFFSET` int(18) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ix_login` (`LOGIN`,`EXTERNAL_AUTH_ID`),
  KEY `ix_b_user_email` (`EMAIL`),
  KEY `ix_b_user_activity_date` (`LAST_ACTIVITY_DATE`),
  KEY `IX_B_USER_XML_ID` (`XML_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `b_user` WRITE;
/*!40000 ALTER TABLE `b_user` DISABLE KEYS */;

INSERT INTO `b_user` (`ID`, `TIMESTAMP_X`, `LOGIN`, `PASSWORD`, `CHECKWORD`, `ACTIVE`, `NAME`, `LAST_NAME`, `EMAIL`, `LAST_LOGIN`, `DATE_REGISTER`, `LID`, `PERSONAL_PROFESSION`, `PERSONAL_WWW`, `PERSONAL_ICQ`, `PERSONAL_GENDER`, `PERSONAL_BIRTHDATE`, `PERSONAL_PHOTO`, `PERSONAL_PHONE`, `PERSONAL_FAX`, `PERSONAL_MOBILE`, `PERSONAL_PAGER`, `PERSONAL_STREET`, `PERSONAL_MAILBOX`, `PERSONAL_CITY`, `PERSONAL_STATE`, `PERSONAL_ZIP`, `PERSONAL_COUNTRY`, `PERSONAL_NOTES`, `WORK_COMPANY`, `WORK_DEPARTMENT`, `WORK_POSITION`, `WORK_WWW`, `WORK_PHONE`, `WORK_FAX`, `WORK_PAGER`, `WORK_STREET`, `WORK_MAILBOX`, `WORK_CITY`, `WORK_STATE`, `WORK_ZIP`, `WORK_COUNTRY`, `WORK_PROFILE`, `WORK_LOGO`, `WORK_NOTES`, `ADMIN_NOTES`, `STORED_HASH`, `XML_ID`, `PERSONAL_BIRTHDAY`, `EXTERNAL_AUTH_ID`, `CHECKWORD_TIME`, `SECOND_NAME`, `CONFIRM_CODE`, `LOGIN_ATTEMPTS`, `LAST_ACTIVITY_DATE`, `AUTO_TIME_ZONE`, `TIME_ZONE`, `TIME_ZONE_OFFSET`)
VALUES
	(1,'2014-07-03 23:57:36','MarsAdmin','MOs8c4oyb3a8adea82ffcd10aac39c78a0ffaffb','t3QTQVje66ad3c9f2dfbd534b958d100ab679f67','Y','','','andrey.slider@gmail.com','2014-07-18 16:05:19','2014-07-03 23:57:36',NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2014-07-03 23:57:36',NULL,NULL,0,NULL,NULL,NULL,NULL);

/*!40000 ALTER TABLE `b_user` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table b_user_access
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_user_access`;

CREATE TABLE `b_user_access` (
  `USER_ID` int(11) DEFAULT NULL,
  `PROVIDER_ID` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ACCESS_CODE` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  KEY `ix_ua_user_provider` (`USER_ID`,`PROVIDER_ID`),
  KEY `ix_ua_user_access` (`USER_ID`,`ACCESS_CODE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `b_user_access` WRITE;
/*!40000 ALTER TABLE `b_user_access` DISABLE KEYS */;

INSERT INTO `b_user_access` (`USER_ID`, `PROVIDER_ID`, `ACCESS_CODE`)
VALUES
	(0,'group','G2'),
	(1,'group','G1'),
	(1,'group','G3'),
	(1,'group','G4'),
	(1,'group','G2'),
	(1,'user','U1');

/*!40000 ALTER TABLE `b_user_access` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table b_user_access_check
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_user_access_check`;

CREATE TABLE `b_user_access_check` (
  `USER_ID` int(11) DEFAULT NULL,
  `PROVIDER_ID` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  KEY `ix_uac_user_provider` (`USER_ID`,`PROVIDER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `b_user_access_check` WRITE;
/*!40000 ALTER TABLE `b_user_access_check` DISABLE KEYS */;

INSERT INTO `b_user_access_check` (`USER_ID`, `PROVIDER_ID`)
VALUES
	(1,'group'),
	(1,'user');

/*!40000 ALTER TABLE `b_user_access_check` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table b_user_counter
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_user_counter`;

CREATE TABLE `b_user_counter` (
  `USER_ID` int(18) NOT NULL,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT '**',
  `CODE` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `CNT` int(18) NOT NULL DEFAULT '0',
  `LAST_DATE` datetime DEFAULT NULL,
  `TAG` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PARAMS` text COLLATE utf8_unicode_ci,
  `SENT` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`USER_ID`,`SITE_ID`,`CODE`),
  KEY `ix_buc_tag` (`TAG`),
  KEY `ix_buc_sent` (`SENT`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_user_digest
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_user_digest`;

CREATE TABLE `b_user_digest` (
  `USER_ID` int(11) NOT NULL,
  `DIGEST_HA1` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`USER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_user_field
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_user_field`;

CREATE TABLE `b_user_field` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ENTITY_ID` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FIELD_NAME` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `USER_TYPE_ID` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `XML_ID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SORT` int(11) DEFAULT NULL,
  `MULTIPLE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `MANDATORY` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `SHOW_FILTER` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `SHOW_IN_LIST` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `EDIT_IN_LIST` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `IS_SEARCHABLE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `SETTINGS` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ux_user_type_entity` (`ENTITY_ID`,`FIELD_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `b_user_field` WRITE;
/*!40000 ALTER TABLE `b_user_field` DISABLE KEYS */;

INSERT INTO `b_user_field` (`ID`, `ENTITY_ID`, `FIELD_NAME`, `USER_TYPE_ID`, `XML_ID`, `SORT`, `MULTIPLE`, `MANDATORY`, `SHOW_FILTER`, `SHOW_IN_LIST`, `EDIT_IN_LIST`, `IS_SEARCHABLE`, `SETTINGS`)
VALUES
	(3,'BLOG_POST','UF_GRATITUDE','integer','UF_GRATITUDE',100,'N','N','N','N','Y','N','a:0:{}'),
	(4,'BLOG_POST','UF_BLOG_POST_VOTE','vote','UF_BLOG_POST_VOTE',100,'N','N','N','Y','Y','N','a:4:{s:10:\"CHANNEL_ID\";i:1;s:6:\"UNIQUE\";i:13;s:15:\"UNIQUE_IP_DELAY\";a:2:{s:5:\"DELAY\";s:2:\"10\";s:10:\"DELAY_TYPE\";s:1:\"D\";}s:6:\"NOTIFY\";s:1:\"N\";}');

/*!40000 ALTER TABLE `b_user_field` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table b_user_field_enum
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_user_field_enum`;

CREATE TABLE `b_user_field_enum` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `USER_FIELD_ID` int(11) DEFAULT NULL,
  `VALUE` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `DEF` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `SORT` int(11) NOT NULL DEFAULT '500',
  `XML_ID` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ux_user_field_enum` (`USER_FIELD_ID`,`XML_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_user_field_lang
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_user_field_lang`;

CREATE TABLE `b_user_field_lang` (
  `USER_FIELD_ID` int(11) NOT NULL DEFAULT '0',
  `LANGUAGE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `EDIT_FORM_LABEL` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LIST_COLUMN_LABEL` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LIST_FILTER_LABEL` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ERROR_MESSAGE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `HELP_MESSAGE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`USER_FIELD_ID`,`LANGUAGE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_user_group
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_user_group`;

CREATE TABLE `b_user_group` (
  `USER_ID` int(18) NOT NULL,
  `GROUP_ID` int(18) NOT NULL,
  `DATE_ACTIVE_FROM` datetime DEFAULT NULL,
  `DATE_ACTIVE_TO` datetime DEFAULT NULL,
  UNIQUE KEY `ix_user_group` (`USER_ID`,`GROUP_ID`),
  KEY `ix_user_group_group` (`GROUP_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `b_user_group` WRITE;
/*!40000 ALTER TABLE `b_user_group` DISABLE KEYS */;

INSERT INTO `b_user_group` (`USER_ID`, `GROUP_ID`, `DATE_ACTIVE_FROM`, `DATE_ACTIVE_TO`)
VALUES
	(1,1,NULL,NULL),
	(1,3,NULL,NULL),
	(1,4,NULL,NULL);

/*!40000 ALTER TABLE `b_user_group` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table b_user_hit_auth
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_user_hit_auth`;

CREATE TABLE `b_user_hit_auth` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `USER_ID` int(18) NOT NULL,
  `HASH` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `URL` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TIMESTAMP_X` datetime NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_USER_HIT_AUTH_1` (`HASH`),
  KEY `IX_USER_HIT_AUTH_2` (`USER_ID`),
  KEY `IX_USER_HIT_AUTH_3` (`TIMESTAMP_X`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_user_option
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_user_option`;

CREATE TABLE `b_user_option` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `USER_ID` int(11) DEFAULT NULL,
  `CATEGORY` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `VALUE` text COLLATE utf8_unicode_ci,
  `COMMON` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`ID`),
  KEY `ix_user_option_user` (`USER_ID`,`CATEGORY`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `b_user_option` WRITE;
/*!40000 ALTER TABLE `b_user_option` DISABLE KEYS */;

INSERT INTO `b_user_option` (`ID`, `USER_ID`, `CATEGORY`, `NAME`, `VALUE`, `COMMON`)
VALUES
	(1,NULL,'intranet','~gadgets_admin_index','a:1:{i:0;a:1:{s:7:\"GADGETS\";a:11:{s:28:\"ADMIN_ORDERS_GRAPH@111111111\";a:3:{s:6:\"COLUMN\";i:0;s:3:\"ROW\";i:0;s:4:\"HIDE\";s:1:\"N\";}s:22:\"ADMIN_ORDERS@111111111\";a:3:{s:6:\"COLUMN\";i:0;s:3:\"ROW\";i:1;s:4:\"HIDE\";s:1:\"N\";}s:19:\"HTML_AREA@444444444\";a:5:{s:6:\"COLUMN\";i:1;s:3:\"ROW\";i:0;s:4:\"HIDE\";s:1:\"N\";s:8:\"USERDATA\";a:1:{s:7:\"content\";s:797:\"<table class=\"bx-gadgets-info-site-table\" cellspacing=\"0\"><tr>	<td class=\"bx-gadget-gray\">Создатель сайта:</td>	<td>Группа компаний &laquo;1С-Битрикс&raquo;.</td>	<td class=\"bx-gadgets-info-site-logo\" rowspan=\"5\"><img src=\"/bitrix/components/bitrix/desktop/templates/admin/images/site_logo.png\"></td></tr><tr>	<td class=\"bx-gadget-gray\">Адрес сайта:</td>	<td><a href=\"http://www.1c-bitrix.ru\">www.1c-bitrix.ru</a></td></tr><tr>	<td class=\"bx-gadget-gray\">Сайт сдан:</td>	<td>12 декабря 2010 г.</td></tr><tr>	<td class=\"bx-gadget-gray\">Ответственное лицо:</td>	<td>Иван Иванов</td></tr><tr>	<td class=\"bx-gadget-gray\">E-mail:</td>	<td><a href=\"mailto:info@1c-bitrix.ru\">info@1c-bitrix.ru</a></td></tr></table>\";}s:8:\"SETTINGS\";a:1:{s:9:\"TITLE_STD\";s:34:\"Информация о сайте\";}}s:24:\"ADMIN_SECURITY@555555555\";a:3:{s:6:\"COLUMN\";i:1;s:3:\"ROW\";i:1;s:4:\"HIDE\";s:1:\"N\";}s:23:\"ADMIN_PERFMON@666666666\";a:3:{s:6:\"COLUMN\";i:1;s:3:\"ROW\";i:2;s:4:\"HIDE\";s:1:\"N\";}s:24:\"ADMIN_PRODUCTS@111111111\";a:3:{s:6:\"COLUMN\";i:1;s:3:\"ROW\";i:5;s:4:\"HIDE\";s:1:\"N\";}s:20:\"ADMIN_INFO@333333333\";a:3:{s:6:\"COLUMN\";i:1;s:3:\"ROW\";i:6;s:4:\"HIDE\";s:1:\"N\";}s:25:\"ADMIN_CHECKLIST@777888999\";a:3:{s:6:\"COLUMN\";i:1;s:3:\"ROW\";i:7;s:4:\"HIDE\";s:1:\"N\";}s:19:\"RSSREADER@777777777\";a:4:{s:6:\"COLUMN\";i:1;s:3:\"ROW\";i:8;s:4:\"HIDE\";s:1:\"N\";s:8:\"SETTINGS\";a:3:{s:9:\"TITLE_STD\";s:33:\"Новости 1С-Битрикс\";s:3:\"CNT\";i:10;s:7:\"RSS_URL\";s:45:\"https://www.1c-bitrix.ru/about/life/news/rss/\";}}s:23:\"ADMIN_MARKETPALCE@22549\";a:3:{s:6:\"COLUMN\";i:1;s:3:\"ROW\";i:3;s:4:\"HIDE\";s:1:\"N\";}s:22:\"ADMIN_MOBILESHOP@13391\";a:3:{s:6:\"COLUMN\";i:1;s:3:\"ROW\";i:4;s:4:\"HIDE\";s:1:\"N\";}}}}','Y'),
	(2,1,'hot_keys','user_defined','b:1;','N'),
	(3,1,'favorite','favorite_menu','a:1:{s:5:\"stick\";s:1:\"N\";}','N'),
	(4,1,'admin_menu','pos','a:1:{s:8:\"sections\";s:233:\"menu_fileman,menu_iblock,menu_iblock_/content,menu_iblock_/content/7,menu_fileman_file_s1_,menu_iblock_/events,iblock_admin,menu_iblock_/content/8,menu_webforms_list,menu_iblock_/events/1,menu_util,menu_perfmon,menu_system,urlrewrite\";}','N'),
	(5,1,'form','form_element_2','a:1:{s:4:\"tabs\";s:208:\"edit1--#--Информация о спикере--,--ACTIVE--#--Активность--,--NAME--#--*Имя Фамилия--,--PREVIEW_PICTURE--#--Фотография--,--PREVIEW_TEXT--#--Описание--;--\";}','N'),
	(6,NULL,'form','form_element_2','a:1:{s:4:\"tabs\";s:208:\"edit1--#--Информация о спикере--,--ACTIVE--#--Активность--,--NAME--#--*Имя Фамилия--,--PREVIEW_PICTURE--#--Фотография--,--PREVIEW_TEXT--#--Описание--;--\";}','Y'),
	(7,1,'form','form_element_5','a:1:{s:4:\"tabs\";s:350:\"edit1--#--Информация о направлении--,--ACTIVE--#--Активность--,--NAME--#--*Название--,--CODE--#--*Символьный код--,--PROPERTY_7--#--Подзаголовок--,--PREVIEW_PICTURE--#--Изображение--,--PROPERTY_8--#--Цвет--,--PROPERTY_9--#--SVG--,--PREVIEW_TEXT--#--Описание--;--\";}','N'),
	(8,NULL,'form','form_element_5','a:1:{s:4:\"tabs\";s:350:\"edit1--#--Информация о направлении--,--ACTIVE--#--Активность--,--NAME--#--*Название--,--CODE--#--*Символьный код--,--PROPERTY_7--#--Подзаголовок--,--PREVIEW_PICTURE--#--Изображение--,--PROPERTY_8--#--Цвет--,--PROPERTY_9--#--SVG--,--PREVIEW_TEXT--#--Описание--;--\";}','Y'),
	(9,1,'form','form_element_3','a:1:{s:4:\"tabs\";s:204:\"edit1--#--Информация о городе--,--ACTIVE--#--Активность--,--NAME--#--*Название--,--CODE--#--*Символьный код--,--PROPERTY_1--#--Аббревиатура--;--\";}','N'),
	(10,NULL,'form','form_element_3','a:1:{s:4:\"tabs\";s:204:\"edit1--#--Информация о городе--,--ACTIVE--#--Активность--,--NAME--#--*Название--,--CODE--#--*Символьный код--,--PROPERTY_1--#--Аббревиатура--;--\";}','Y'),
	(11,1,'BX.WindowManager.9.5','size_/bitrix/admin/iblock_element_edit.php','a:2:{s:5:\"width\";s:3:\"569\";s:6:\"height\";s:3:\"588\";}','N'),
	(12,1,'form','form_element_4','a:1:{s:4:\"tabs\";s:179:\"edit1--#--Информация о типе мероприятия--,--ACTIVE--#--Активность--,--NAME--#--*Название--,--CODE--#--*Символьный код--;--\";}','N'),
	(13,NULL,'form','form_element_4','a:1:{s:4:\"tabs\";s:179:\"edit1--#--Информация о типе мероприятия--,--ACTIVE--#--Активность--,--NAME--#--*Название--,--CODE--#--*Символьный код--;--\";}','Y'),
	(14,1,'fileman','last_pathes','s:96:\"a:5:{i:0;s:7:\"/events\";i:1;s:7:\"/career\";i:2;s:8:\"/academy\";i:3;s:6:\"/about\";i:4;s:7:\"/bitrix\";}\";','N'),
	(15,1,'form','form_element_7','a:1:{s:4:\"tabs\";s:319:\"edit1--#--Информация о направлении--,--NAME--#--*Название--,--CODE--#--Символьный код--,--PROPERTY_3--#--Открыт набор?--,--PREVIEW_PICTURE--#--Картинка для анонса--,--PROPERTY_6--#--SVG--,--PREVIEW_TEXT--#--Описание для анонса--;--\";}','N'),
	(16,NULL,'form','form_element_7','a:1:{s:4:\"tabs\";s:319:\"edit1--#--Информация о направлении--,--NAME--#--*Название--,--CODE--#--Символьный код--,--PROPERTY_3--#--Открыт набор?--,--PREVIEW_PICTURE--#--Картинка для анонса--,--PROPERTY_6--#--SVG--,--PREVIEW_TEXT--#--Описание для анонса--;--\";}','Y'),
	(17,1,'fileman','code_editor','a:1:{s:5:\"theme\";s:5:\"light\";}','N'),
	(18,1,'admin_panel','settings','a:2:{s:4:\"edit\";s:3:\"off\";s:9:\"collapsed\";s:2:\"on\";}','N'),
	(19,1,'fileman','file_dialog_config','s:31:\"s1;/layout/images;list;type;asc\";','N'),
	(20,1,'form','form_element_8','a:1:{s:4:\"tabs\";s:258:\"edit1--#--Элемент--,--ACTIVE--#--Активность--,--NAME--#--*Название--,--SORT--#--Сортировка--,--PROPERTY_4--#--Отдел стажировки--,--PROPERTY_5--#--Ссылка на подробную информацию--;--\";}','N'),
	(21,NULL,'form','form_element_8','a:1:{s:4:\"tabs\";s:258:\"edit1--#--Элемент--,--ACTIVE--#--Активность--,--NAME--#--*Название--,--SORT--#--Сортировка--,--PROPERTY_4--#--Отдел стажировки--,--PROPERTY_5--#--Ссылка на подробную информацию--;--\";}','Y'),
	(22,1,'form','form_element_1','a:1:{s:4:\"tabs\";s:502:\"edit1--#--Элемент--,--ACTIVE--#--Активность--,--SORT--#--Сортировка--,--NAME--#--*Название--,--CODE--#--*Символьный код--,--PROPERTY_11--#--Дата мероприятия--,--PROPERTY_14--#--Тип мероприятия--,--PROPERTY_12--#--Направление--,--PROPERTY_10--#--Город--,--PROPERTY_13--#--Спикеры--,--PREVIEW_PICTURE--#--Картинка для анонса--,--PREVIEW_TEXT--#--Описание для анонса--;--\";}','N'),
	(23,NULL,'form','form_element_1','a:1:{s:4:\"tabs\";s:502:\"edit1--#--Элемент--,--ACTIVE--#--Активность--,--SORT--#--Сортировка--,--NAME--#--*Название--,--CODE--#--*Символьный код--,--PROPERTY_11--#--Дата мероприятия--,--PROPERTY_14--#--Тип мероприятия--,--PROPERTY_12--#--Направление--,--PROPERTY_10--#--Город--,--PROPERTY_13--#--Спикеры--,--PREVIEW_PICTURE--#--Картинка для анонса--,--PREVIEW_TEXT--#--Описание для анонса--;--\";}','Y');

/*!40000 ALTER TABLE `b_user_option` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table b_user_stored_auth
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_user_stored_auth`;

CREATE TABLE `b_user_stored_auth` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `USER_ID` int(18) NOT NULL,
  `DATE_REG` datetime NOT NULL,
  `LAST_AUTH` datetime NOT NULL,
  `STORED_HASH` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `TEMP_HASH` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `IP_ADDR` int(10) unsigned NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `ux_user_hash` (`USER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `b_user_stored_auth` WRITE;
/*!40000 ALTER TABLE `b_user_stored_auth` DISABLE KEYS */;

INSERT INTO `b_user_stored_auth` (`ID`, `USER_ID`, `DATE_REG`, `LAST_AUTH`, `STORED_HASH`, `TEMP_HASH`, `IP_ADDR`)
VALUES
	(1,1,'2014-07-03 23:57:36','2014-07-18 16:05:19','d8eb237fe61c62b288ab0fe1e99e858d','N',2130706433);

/*!40000 ALTER TABLE `b_user_stored_auth` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table b_utm_blog_post
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_utm_blog_post`;

CREATE TABLE `b_utm_blog_post` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `VALUE_ID` int(11) NOT NULL,
  `FIELD_ID` int(11) NOT NULL,
  `VALUE` text COLLATE utf8_unicode_ci,
  `VALUE_INT` int(11) DEFAULT NULL,
  `VALUE_DOUBLE` float DEFAULT NULL,
  `VALUE_DATE` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ix_utm_BLOG_POST_1` (`FIELD_ID`),
  KEY `ix_utm_BLOG_POST_2` (`VALUE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_uts_blog_post
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_uts_blog_post`;

CREATE TABLE `b_uts_blog_post` (
  `VALUE_ID` int(11) NOT NULL,
  `UF_GRATITUDE` int(18) DEFAULT NULL,
  `UF_BLOG_POST_VOTE` int(18) DEFAULT NULL,
  PRIMARY KEY (`VALUE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_vote
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_vote`;

CREATE TABLE `b_vote` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `CHANNEL_ID` int(18) NOT NULL DEFAULT '0',
  `C_SORT` int(18) DEFAULT '100',
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `NOTIFY` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `AUTHOR_ID` int(18) DEFAULT NULL,
  `TIMESTAMP_X` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `DATE_START` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `DATE_END` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `URL` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `COUNTER` int(11) NOT NULL DEFAULT '0',
  `TITLE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DESCRIPTION` text COLLATE utf8_unicode_ci,
  `DESCRIPTION_TYPE` varchar(4) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'html',
  `IMAGE_ID` int(18) DEFAULT NULL,
  `EVENT1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `EVENT2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `EVENT3` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `UNIQUE_TYPE` int(18) NOT NULL DEFAULT '2',
  `KEEP_IP_SEC` int(18) DEFAULT NULL,
  `DELAY` int(18) DEFAULT NULL,
  `DELAY_TYPE` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TEMPLATE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `RESULT_TEMPLATE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_CHANNEL_ID` (`CHANNEL_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_vote_answer
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_vote_answer`;

CREATE TABLE `b_vote_answer` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `TIMESTAMP_X` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `QUESTION_ID` int(18) NOT NULL DEFAULT '0',
  `C_SORT` int(18) DEFAULT '100',
  `MESSAGE` text COLLATE utf8_unicode_ci,
  `COUNTER` int(18) NOT NULL DEFAULT '0',
  `FIELD_TYPE` int(5) NOT NULL DEFAULT '0',
  `FIELD_WIDTH` int(18) DEFAULT NULL,
  `FIELD_HEIGHT` int(18) DEFAULT NULL,
  `FIELD_PARAM` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `COLOR` varchar(7) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_QUESTION_ID` (`QUESTION_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_vote_channel
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_vote_channel`;

CREATE TABLE `b_vote_channel` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `SYMBOLIC_NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `C_SORT` int(18) DEFAULT '100',
  `FIRST_SITE_ID` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `HIDDEN` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `TIMESTAMP_X` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `TITLE` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `VOTE_SINGLE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `USE_CAPTCHA` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `b_vote_channel` WRITE;
/*!40000 ALTER TABLE `b_vote_channel` DISABLE KEYS */;

INSERT INTO `b_vote_channel` (`ID`, `SYMBOLIC_NAME`, `C_SORT`, `FIRST_SITE_ID`, `ACTIVE`, `HIDDEN`, `TIMESTAMP_X`, `TITLE`, `VOTE_SINGLE`, `USE_CAPTCHA`)
VALUES
	(1,'UF_BLOG_POST_VOTE',100,NULL,'Y','Y','2014-07-03 23:56:30','UF_BLOG_POST_VOTE','N','N');

/*!40000 ALTER TABLE `b_vote_channel` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table b_vote_channel_2_group
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_vote_channel_2_group`;

CREATE TABLE `b_vote_channel_2_group` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `CHANNEL_ID` int(18) NOT NULL DEFAULT '0',
  `GROUP_ID` int(18) NOT NULL DEFAULT '0',
  `PERMISSION` int(18) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `b_vote_channel_2_group` WRITE;
/*!40000 ALTER TABLE `b_vote_channel_2_group` DISABLE KEYS */;

INSERT INTO `b_vote_channel_2_group` (`ID`, `CHANNEL_ID`, `GROUP_ID`, `PERMISSION`)
VALUES
	(1,1,2,1),
	(2,1,3,4),
	(3,1,4,4);

/*!40000 ALTER TABLE `b_vote_channel_2_group` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table b_vote_channel_2_site
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_vote_channel_2_site`;

CREATE TABLE `b_vote_channel_2_site` (
  `CHANNEL_ID` int(18) NOT NULL DEFAULT '0',
  `SITE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`CHANNEL_ID`,`SITE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `b_vote_channel_2_site` WRITE;
/*!40000 ALTER TABLE `b_vote_channel_2_site` DISABLE KEYS */;

INSERT INTO `b_vote_channel_2_site` (`CHANNEL_ID`, `SITE_ID`)
VALUES
	(1,'s1');

/*!40000 ALTER TABLE `b_vote_channel_2_site` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table b_vote_event
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_vote_event`;

CREATE TABLE `b_vote_event` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `VOTE_ID` int(18) NOT NULL DEFAULT '0',
  `VOTE_USER_ID` int(18) NOT NULL DEFAULT '0',
  `DATE_VOTE` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `STAT_SESSION_ID` int(18) DEFAULT NULL,
  `IP` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `VALID` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`ID`),
  KEY `IX_USER_ID` (`VOTE_USER_ID`),
  KEY `IX_B_VOTE_EVENT_2` (`VOTE_ID`,`IP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_vote_event_answer
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_vote_event_answer`;

CREATE TABLE `b_vote_event_answer` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `EVENT_QUESTION_ID` int(18) NOT NULL DEFAULT '0',
  `ANSWER_ID` int(18) NOT NULL DEFAULT '0',
  `MESSAGE` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  KEY `IX_EVENT_QUESTION_ID` (`EVENT_QUESTION_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_vote_event_question
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_vote_event_question`;

CREATE TABLE `b_vote_event_question` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `EVENT_ID` int(18) NOT NULL DEFAULT '0',
  `QUESTION_ID` int(18) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `IX_EVENT_ID` (`EVENT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_vote_question
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_vote_question`;

CREATE TABLE `b_vote_question` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `TIMESTAMP_X` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `VOTE_ID` int(18) NOT NULL DEFAULT '0',
  `C_SORT` int(18) DEFAULT '100',
  `COUNTER` int(11) NOT NULL DEFAULT '0',
  `QUESTION` text COLLATE utf8_unicode_ci NOT NULL,
  `QUESTION_TYPE` varchar(4) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'html',
  `IMAGE_ID` int(18) DEFAULT NULL,
  `DIAGRAM` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `REQUIRED` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `DIAGRAM_TYPE` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'histogram',
  `TEMPLATE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TEMPLATE_NEW` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IX_VOTE_ID` (`VOTE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table b_vote_user
# ------------------------------------------------------------

DROP TABLE IF EXISTS `b_vote_user`;

CREATE TABLE `b_vote_user` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `STAT_GUEST_ID` int(18) DEFAULT NULL,
  `AUTH_USER_ID` int(18) DEFAULT NULL,
  `COUNTER` int(18) NOT NULL DEFAULT '0',
  `DATE_FIRST` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `DATE_LAST` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `LAST_IP` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;




/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
